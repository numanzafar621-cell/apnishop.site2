<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

$error = '';
$success = '';

$token = $_GET['token'] ?? '';
$email = $_GET['email'] ?? '';
$type = $_GET['type'] ?? 'seller';

if(empty($token) || empty($email)) {
    die("Invalid request.");
}

// Verify token
$reset = db_get_row("SELECT * FROM password_resets WHERE email = ? AND token = ? AND type = ? AND expires_at > NOW()", [$email, $token, $type]);
if(!$reset) {
    die("Invalid or expired reset link. Please request a new one.");
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    
    if(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $hashed = hashPassword($password);
        if($type == 'seller') {
            db_update("users", ['password' => $hashed], "email = ?", [$email]);
        } else {
            // For customer password reset (type = 'customer')
            db_update("customers", ['password' => $hashed], "email = ?", [$email]);
        }
        // Delete used token
        db_delete("password_resets", "email = ? AND token = ?", [$email, $token]);
        $success = "Your password has been reset successfully. You can now login.";
        header("refresh:2;url=login.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password - ApniShop</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Reset Password</h2>
            <?php if($error): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div>
            <?php endif; ?>
            <?php if($success): ?>
                <div class="bg-green-100 text-green-700 p-3 rounded mb-4"><?= $success ?> Redirecting...</div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-4"><label>New Password</label><input type="password" name="password" required minlength="6" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-6"><label>Confirm Password</label><input type="password" name="confirm_password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded">Reset Password</button>
            </form>
        </div>
    </div>
</body>
</html>