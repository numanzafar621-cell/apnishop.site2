<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ApniShop - Create Your Online Store</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .hero-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div class="text-2xl font-bold text-indigo-600">ApniShop</div>
            <div>
                <a href="login.php" class="text-gray-600 hover:text-indigo-600 mr-4">Login</a>
                <a href="register.php" class="bg-indigo-600 text-white px-4 py-2 rounded-full hover:bg-indigo-700">Sign Up Free</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-gradient text-white py-20 text-center">
        <div class="container mx-auto px-4">
            <h1 class="text-5xl font-bold mb-4">Create Your Online Store</h1>
            <p class="text-xl mb-8">Start selling today with a professional ecommerce website. No coding required.</p>
            <a href="register.php" class="bg-yellow-500 text-gray-900 px-8 py-3 rounded-full text-lg font-semibold hover:bg-yellow-400">Get Started Now</a>
        </div>
    </section>

    <!-- Features -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12">Why Choose ApniShop?</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center p-6 bg-white rounded-lg shadow">
                    <div class="text-4xl mb-4">🛒</div>
                    <h3 class="text-xl font-bold mb-2">Complete Ecommerce</h3>
                    <p>Products, cart, checkout, and order management</p>
                </div>
                <div class="text-center p-6 bg-white rounded-lg shadow">
                    <div class="text-4xl mb-4">🎨</div>
                    <h3 class="text-xl font-bold mb-2">Customizable Design</h3>
                    <p>Change colors, logo, slider, banners, and more</p>
                </div>
                <div class="text-center p-6 bg-white rounded-lg shadow">
                    <div class="text-4xl mb-4">📱</div>
                    <h3 class="text-xl font-bold mb-2">Mobile Friendly</h3>
                    <p>Looks beautiful on every device</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-6 text-center">
        <p>&copy; 2025 ApniShop - All rights reserved</p>
    </footer>
</body>
</html>