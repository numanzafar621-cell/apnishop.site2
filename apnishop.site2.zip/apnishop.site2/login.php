<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

$error = '';

if(isUserLoggedIn()) {
    header('Location: /tenant/dashboard/index.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if(empty($email) || empty($password)) {
        $error = 'Please enter email and password.';
    } else {
        $loginResult = userLogin($email, $password);
        if($loginResult === true) {
            header('Location: /tenant/dashboard/index.php');
            exit;
        } elseif($loginResult === 'inactive') {
            $error = 'Your account is not activated yet. Please complete CNIC verification and wait for admin approval.';
        } elseif($loginResult === 'plan_expired') {
            $error = 'Your plan has expired. Please renew your plan.';
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - ApniShop</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Login to Your Store</h2>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'verify'): ?>
                <div class="bg-green-100 text-green-700 p-3 rounded mb-4">Account created! Please login and complete CNIC verification.</div>
            <?php endif; ?>
            <?php if($error): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-4"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-4"><label>Password</label><input type="password" name="password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded-full hover:bg-indigo-700">Login</button>
            </form>
            <p class="text-center text-gray-600 mt-4">Don't have an account? <a href="register.php" class="text-indigo-600">Sign Up</a></p>
            <p class="text-center text-gray-600 mt-2"><a href="forgot-password.php" class="text-indigo-600">Forgot Password?</a></p>
            <p class="text-center text-gray-500 text-sm mt-4"><a href="admin/login.php">Admin Login</a></p>
        </div>
    </div>
</body>
</html>