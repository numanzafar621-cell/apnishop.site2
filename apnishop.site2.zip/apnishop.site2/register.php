<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $business_name = trim($_POST['business_name']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $subdomain = trim($_POST['subdomain']);
    
    // Validation
    if(empty($business_name) || empty($first_name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'Please fill all required fields.';
    } elseif($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif(!preg_match('/^[a-z0-9-]+$/', $subdomain)) {
        $error = 'Subdomain can only contain lowercase letters, numbers, and hyphens.';
    } else {
        // Check if email exists
        $existing = db_get_row("SELECT id FROM users WHERE email = ?", [$email]);
        if($existing) {
            $error = 'Email already registered.';
        } else {
            // Check if subdomain exists
            $existingSub = db_get_row("SELECT id FROM users WHERE subdomain = ?", [$subdomain]);
            if($existingSub) {
                $error = 'Subdomain already taken.';
            } else {
                // Create user (inactive by default, no CNIC yet)
                $hashedPassword = hashPassword($password);
                $user_id = db_insert('users', [
                    'business_name' => $business_name,
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'email' => $email,
                    'phone' => $phone,
                    'password' => $hashedPassword,
                    'subdomain' => $subdomain,
                    'is_active' => 0,
                    'plan_id' => 1,
                    'plan_expiry' => date('Y-m-d', strtotime('+30 days'))
                ]);
                
                if($user_id) {
                    // Redirect to loading page, then to verification
                    header('Location: loading.php?email=' . urlencode($email));
                    exit;
                } else {
                    $error = 'Failed to create account. Please try again.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - ApniShop</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Create Your Store</h2>
            <?php if($error): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3"><label>Business Name *</label><input type="text" name="business_name" required class="w-full border rounded px-3 py-2"></div>
                <div class="grid grid-cols-2 gap-3 mb-3">
                    <div><label>First Name *</label><input type="text" name="first_name" required class="w-full border rounded px-3 py-2"></div>
                    <div><label>Last Name</label><input type="text" name="last_name" class="w-full border rounded px-3 py-2"></div>
                </div>
                <div class="mb-3"><label>Email *</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Phone *</label><input type="tel" name="phone" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3">
                    <label>Subdomain *</label>
                    <div class="flex"><input type="text" name="subdomain" required pattern="[a-z0-9-]+" class="flex-1 border rounded-l px-3 py-2"><span class="bg-gray-200 border border-l-0 rounded-r px-3 py-2">.apnishop.site</span></div>
                    <p class="text-sm text-gray-500">Only lowercase letters, numbers, and hyphens.</p>
                </div>
                <div class="mb-3"><label>Password *</label><input type="password" name="password" required minlength="6" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-4"><label>Confirm Password *</label><input type="password" name="confirm_password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded-full hover:bg-indigo-700">Sign Up</button>
            </form>
            <p class="text-center text-gray-600 mt-4">Already have an account? <a href="login.php" class="text-indigo-600">Login</a></p>
        </div>
    </div>
</body>
</html>