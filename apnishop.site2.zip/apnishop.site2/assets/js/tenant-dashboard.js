// Tenant Dashboard JavaScript - Complete File

// ==================== IMAGE UPLOAD PREVIEW ====================

// Preview image before upload
function previewImage(input, previewId) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = document.getElementById(previewId);
            if (preview) preview.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Preview slider image
function previewSliderImage(input, previewId) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = document.getElementById(previewId);
            if (img) img.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Preview banner image
function previewBannerImage(input, previewId) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = document.getElementById(previewId);
            if (preview) preview.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// ==================== CONFIRMATION DIALOGS ====================

// Confirm delete product
function confirmDelete(productId, productName) {
    if (confirm(`Are you sure you want to delete "${productName}"? This action cannot be undone.`)) {
        window.location.href = `?delete=${productId}`;
    }
}

// Confirm delete banner
function confirmBannerDelete(bannerId, bannerTitle) {
    if (confirm(`Delete banner "${bannerTitle}"?`)) {
        window.location.href = `?delete=${bannerId}`;
    }
}

// Confirm delete popup
function confirmPopupDelete(popupId, popupTitle) {
    if (confirm(`Delete popup "${popupTitle}"?`)) {
        window.location.href = `?delete=${popupId}`;
    }
}

// Confirm delete slider
function confirmSliderDelete(sliderId, sliderTitle) {
    if (confirm(`Delete slider "${sliderTitle}"?`)) {
        window.location.href = `?delete=${sliderId}`;
    }
}

// ==================== COLOR PREVIEW ====================

// Live color preview for theme settings
function previewColor(colorPicker, targetElementId) {
    const color = colorPicker.value;
    const target = document.getElementById(targetElementId);
    if (target) target.style.backgroundColor = color;
}

// Preview primary color on demo element
function previewPrimaryColor(colorPicker) {
    const color = colorPicker.value;
    const demoBtn = document.getElementById('demoPrimaryBtn');
    if (demoBtn) demoBtn.style.backgroundColor = color;
}

// ==================== ORDER MANAGEMENT ====================

// Update order status via AJAX
function updateOrderStatus(orderId, status) {
    fetch('/tenant/dashboard/ajax-update-order.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `order_id=${orderId}&status=${status}`
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Order status updated successfully', 'success');
            location.reload();
        } else {
            showToast('Error updating order status', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Server error occurred', 'error');
    });
}

// Print order invoice
function printInvoice() {
    window.print();
}

// ==================== BANNER SORTING (DRAG & DROP) ====================

// Initialize banner drag and drop sorting
function initBannerSorting() {
    const container = document.querySelector('.banners-sortable');
    if (!container) return;
    
    let dragSrc = null;
    container.querySelectorAll('.banner-item').forEach(item => {
        item.setAttribute('draggable', 'true');
        
        item.addEventListener('dragstart', (e) => {
            dragSrc = item;
            e.dataTransfer.effectAllowed = 'move';
            item.style.opacity = '0.5';
        });
        
        item.addEventListener('dragend', (e) => {
            item.style.opacity = '';
        });
        
        item.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
        });
        
        item.addEventListener('drop', (e) => {
            e.preventDefault();
            if (dragSrc && dragSrc !== item) {
                container.insertBefore(dragSrc, item.nextSibling);
                saveBannerOrder();
            }
        });
    });
}

// Save banner order to server
function saveBannerOrder() {
    const items = document.querySelectorAll('.banner-item');
    const orders = [];
    items.forEach((item, index) => {
        orders.push({ id: item.dataset.id, order: index });
    });
    
    fetch('/tenant/dashboard/ajax-save-banner-order.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orders)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Banner order saved', 'success');
        }
    });
}

// ==================== TINYMCE EDITOR ====================

// Initialize TinyMCE editor
function initTinyMCE() {
    if (typeof tinymce !== 'undefined') {
        tinymce.init({
            selector: '.editor',
            height: 400,
            menubar: false,
            plugins: 'image code link lists',
            toolbar: 'undo redo | formatselect | bold italic underline | alignleft aligncenter alignright | bullist numlist | image code link',
            images_upload_url: '/tenant/dashboard/ajax-upload-image.php',
            automatic_uploads: true,
            file_picker_types: 'image',
            setup: function(editor) {
                editor.on('change', function() {
                    editor.save();
                });
            }
        });
    }
}

// ==================== DASHBOARD CHARTS ====================

// Initialize dashboard charts
function initDashboardCharts() {
    // Revenue chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx && typeof Chart !== 'undefined') {
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Revenue (Rs.)',
                    data: JSON.parse(revenueCtx.dataset.revenue || '[0,0,0,0,0,0]'),
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79, 70, 229, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
    
    // Orders chart
    const ordersCtx = document.getElementById('ordersChart');
    if (ordersCtx && typeof Chart !== 'undefined') {
        new Chart(ordersCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Orders',
                    data: JSON.parse(ordersCtx.dataset.orders || '[0,0,0,0,0,0]'),
                    backgroundColor: '#f59e0b',
                    borderRadius: 8
                }]
            }
        });
    }
}

// ==================== POPUP DELAY PREVIEW ====================

// Preview popup delay
function previewPopupDelay(delayInput) {
    const val = delayInput.value;
    const preview = document.getElementById('popupPreviewDelay');
    if (preview) {
        preview.innerText = `${val} seconds delay`;
    }
}

// ==================== FORM VALIDATION ====================

// Validate product form
function validateProductForm() {
    const name = document.getElementById('product_name')?.value;
    const price = document.getElementById('product_price')?.value;
    const stock = document.getElementById('product_stock')?.value;
    
    if (!name) {
        alert('Product name is required');
        return false;
    }
    if (price && parseFloat(price) <= 0) {
        alert('Price must be greater than 0');
        return false;
    }
    if (stock && parseInt(stock) < 0) {
        alert('Stock cannot be negative');
        return false;
    }
    return true;
}

// ==================== INITIALIZATION ====================

// Initialize everything on page load
document.addEventListener('DOMContentLoaded', () => {
    // Initialize TinyMCE
    initTinyMCE();
    
    // Initialize banner sorting
    initBannerSorting();
    
    // Initialize charts
    initDashboardCharts();
    
    // Image preview listeners
    document.querySelectorAll('.image-input').forEach(input => {
        const previewId = input.dataset.preview;
        if (previewId) {
            input.addEventListener('change', () => previewImage(input, previewId));
        }
    });
    
    // Slider image preview listeners
    document.querySelectorAll('.slider-image-input').forEach(input => {
        const previewId = input.dataset.preview;
        if (previewId) {
            input.addEventListener('change', () => previewSliderImage(input, previewId));
        }
    });
    
    // Banner image preview listeners
    document.querySelectorAll('.banner-image-input').forEach(input => {
        const previewId = input.dataset.preview;
        if (previewId) {
            input.addEventListener('change', () => previewBannerImage(input, previewId));
        }
    });
    
    // Color picker preview
    const colorPicker = document.getElementById('primary_color');
    if (colorPicker) {
        colorPicker.addEventListener('input', () => previewColor(colorPicker, 'primaryColorPreview'));
    }
    
    // Product form validation
    const productForm = document.getElementById('productForm');
    if (productForm) {
        productForm.addEventListener('submit', validateProductForm);
    }
    
    // Auto hide flash messages
    document.querySelectorAll('.flash-message').forEach(msg => {
        setTimeout(() => {
            msg.style.opacity = '0';
            setTimeout(() => msg.remove(), 300);
        }, 5000);
    });
});