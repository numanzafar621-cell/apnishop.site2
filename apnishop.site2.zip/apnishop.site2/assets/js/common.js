// Common JavaScript Functions - Complete File
// Shared across all panels (Admin, Tenant Front, Tenant Dashboard)

// ==================== TOAST NOTIFICATIONS ====================

// Show toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerText = message;
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    }, 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(20px)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ==================== AJAX HELPERS ====================

// Generic AJAX request function
function ajaxRequest(url, method, data, callback) {
    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(data)
    })
    .then(response => response.json())
    .then(callback)
    .catch(error => {
        console.error('AJAX Error:', error);
        showToast('Network error occurred', 'error');
    });
}

// GET request
function ajaxGet(url, callback) {
    fetch(url)
        .then(response => response.json())
        .then(callback)
        .catch(error => console.error('AJAX Error:', error));
}

// POST request
function ajaxPost(url, data, callback) {
    ajaxRequest(url, 'POST', data, callback);
}

// ==================== CONFIRMATION DIALOG ====================

// Generic confirmation dialog
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// ==================== FORMATTING FUNCTIONS ====================

// Format price (Rs. 1,234.56)
function formatPrice(price) {
    return 'Rs. ' + parseFloat(price).toLocaleString('en-PK', { 
        minimumFractionDigits: 2,
        maximumFractionDigits: 2 
    });
}

// Format date (DD-MM-YYYY)
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-PK', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

// Format datetime (DD-MM-YYYY HH:MM AM/PM)
function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-PK', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// ==================== URL HELPERS ====================

// Get URL parameter by name
function getUrlParam(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

// Set URL parameter without reload
function setUrlParam(name, value) {
    const url = new URL(window.location.href);
    url.searchParams.set(name, value);
    window.history.pushState({}, '', url);
}

// Remove URL parameter
function removeUrlParam(name) {
    const url = new URL(window.location.href);
    url.searchParams.delete(name);
    window.history.pushState({}, '', url);
}

// ==================== FORM HELPERS ====================

// Serialize form data to object
function serializeForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return {};
    
    const formData = new FormData(form);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });
    return data;
}

// Clear form fields
function clearForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    form.querySelectorAll('input, textarea, select').forEach(field => {
        if (field.type !== 'submit' && field.type !== 'button') {
            field.value = '';
        }
    });
}

// ==================== VALIDATION HELPERS ====================

// Validate email
function isValidEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// Validate phone number (Pakistan format)
function isValidPhone(phone) {
    const regex = /^03[0-9]{9}$/;
    return regex.test(phone);
}

// Validate password strength
function isStrongPassword(password) {
    return password.length >= 6;
}

// ==================== LOADING INDICATOR ====================

// Show loading overlay
function showLoading() {
    let loader = document.getElementById('globalLoader');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'globalLoader';
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }
    loader.classList.remove('hidden');
}

// Hide loading overlay
function hideLoading() {
    const loader = document.getElementById('globalLoader');
    if (loader) {
        loader.classList.add('hidden');
    }
}

// ==================== SCROLL TO TOP ====================

// Scroll to top of page
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Show/hide scroll to top button
function initScrollToTop() {
    const btn = document.getElementById('scrollToTopBtn');
    if (!btn) return;
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            btn.classList.remove('hidden');
        } else {
            btn.classList.add('hidden');
        }
    });
    
    btn.addEventListener('click', scrollToTop);
}

// ==================== AUTO HIDE FLASH MESSAGES ====================

// Auto hide flash messages after 5 seconds
function initAutoHideMessages() {
    document.querySelectorAll('.flash-message, .alert').forEach(msg => {
        setTimeout(() => {
            msg.style.opacity = '0';
            msg.style.transition = 'opacity 0.3s';
            setTimeout(() => msg.remove(), 300);
        }, 5000);
    });
}

// ==================== RESPONSIVE TABLES ====================

// Make tables responsive on mobile
function initResponsiveTables() {
    document.querySelectorAll('table').forEach(table => {
        if (!table.parentElement.classList.contains('table-responsive')) {
            const wrapper = document.createElement('div');
            wrapper.className = 'table-responsive overflow-x-auto';
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        }
    });
}

// ==================== INITIALIZATION ====================

// Initialize all common functionality
document.addEventListener('DOMContentLoaded', () => {
    initAutoHideMessages();
    initResponsiveTables();
    initScrollToTop();
});

// ==================== ADD CSS FOR TOAST ====================
const toastStyles = document.createElement('style');
toastStyles.textContent = `
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 8px;
        color: white;
        font-size: 14px;
        font-weight: 500;
        z-index: 9999;
        opacity: 0;
        transform: translateY(20px);
        transition: all 0.3s ease;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .toast-success { background-color: #10b981; }
    .toast-error { background-color: #ef4444; }
    .toast-warning { background-color: #f59e0b; }
    .toast-info { background-color: #3b82f6; }
    
    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
    }
    .loading-spinner {
        width: 40px;
        height: 40px;
        border: 4px solid #f3f3f3;
        border-top: 4px solid #4f46e5;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    #scrollToTopBtn {
        position: fixed;
        bottom: 30px;
        right: 30px;
        background: #4f46e5;
        color: white;
        width: 45px;
        height: 45px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        z-index: 99;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        transition: all 0.2s;
        border: none;
    }
    #scrollToTopBtn:hover {
        background: #4338ca;
        transform: scale(1.05);
    }
    .hidden {
        display: none !important;
    }
`;
document.head.appendChild(toastStyles);