// Super Admin Panel JavaScript - Complete File

// ==================== USER MANAGEMENT ====================

// Toggle user active status
function toggleUserStatus(userId, currentStatus) {
    if (confirm(`Are you sure you want to ${currentStatus ? 'deactivate' : 'activate'} this user?`)) {
        fetch('/admin/ajax-toggle-user.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `user_id=${userId}&status=${currentStatus ? 0 : 1}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(`User ${currentStatus ? 'deactivated' : 'activated'} successfully`, 'success');
                location.reload();
            } else {
                showToast('Error occurred. Please try again.', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Server error occurred.', 'error');
        });
    }
}

// Delete user
function deleteUser(userId, userName) {
    if (confirm(`Are you sure you want to permanently delete "${userName}"? All data will be lost!`)) {
        window.location.href = `?delete=${userId}`;
    }
}

// ==================== CNIC VERIFICATION ====================

// Show CNIC images in modal
function showCnicImages(frontUrl, backUrl) {
    const modal = document.getElementById('cnicModal');
    if (modal) {
        document.getElementById('cnicFront').src = '/assets/uploads/cnic/' + frontUrl;
        document.getElementById('cnicBack').src = '/assets/uploads/cnic/' + backUrl;
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

// Close CNIC modal
function closeCnicModal() {
    const modal = document.getElementById('cnicModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

// Approve CNIC verification
function approveCnic(userId) {
    if (confirm('Approve this user\'s CNIC verification?')) {
        window.location.href = `?approve=${userId}`;
    }
}

// Reject CNIC verification
function rejectCnic(userId) {
    if (confirm('Reject this user\'s CNIC verification?')) {
        window.location.href = `?reject=${userId}`;
    }
}

// ==================== PRODUCT APPROVAL ====================

// Approve product
function approveProduct(productId, productName) {
    if (confirm(`Approve product "${productName}"?`)) {
        window.location.href = `?approve=${productId}`;
    }
}

// Disapprove product
function disapproveProduct(productId, productName) {
    if (confirm(`Disapprove product "${productName}"?`)) {
        window.location.href = `?disapprove=${productId}`;
    }
}

// View product preview
function viewProduct(productId) {
    window.open(`/tenant/product.php?id=${productId}&preview=1`, '_blank');
}

// ==================== PLAN MANAGEMENT ====================

// Edit plan modal
function editPlan(plan) {
    document.getElementById('edit_id').value = plan.id;
    document.getElementById('edit_name').value = plan.name;
    document.getElementById('edit_price').value = plan.price;
    document.getElementById('edit_duration').value = plan.duration_days;
    document.getElementById('edit_features').value = plan.features;
    document.getElementById('edit_active').checked = plan.is_active == 1;
    
    const modal = document.getElementById('editModal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

// Close edit plan modal
function closeEditModal() {
    const modal = document.getElementById('editModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

// Delete plan
function deletePlan(planId, planName) {
    if (confirm(`Delete plan "${planName}"? This may affect users on this plan.`)) {
        window.location.href = `?delete=${planId}`;
    }
}

// ==================== LIVE CHAT ====================

// Scroll chat to bottom
function scrollChatToBottom() {
    const chatContainer = document.getElementById('chatMessages');
    if (chatContainer) {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
}

// Send chat message via AJAX (optional, without page reload)
function sendChatMessage(userId, message) {
    if (!message.trim()) return false;
    
    fetch('/admin/ajax-send-chat.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `user_id=${userId}&message=${encodeURIComponent(message)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showToast('Failed to send message', 'error');
        }
    });
    return false;
}

// Auto refresh chat every 5 seconds
let chatRefreshInterval = null;
function startChatAutoRefresh() {
    if (chatRefreshInterval) clearInterval(chatRefreshInterval);
    chatRefreshInterval = setInterval(() => {
        const chatContainer = document.getElementById('chatMessages');
        if (chatContainer && window.location.pathname.includes('live-chat.php')) {
            location.reload();
        }
    }, 5000);
}

// ==================== DASHBOARD CHARTS ====================

// Initialize dashboard charts
function initAdminCharts() {
    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx && typeof Chart !== 'undefined') {
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Revenue (Rs.)',
                    data: [0, 0, 0, 0, 0, 0],
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79, 70, 229, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' }
                }
            }
        });
    }
    
    // Orders Chart
    const ordersCtx = document.getElementById('ordersChart');
    if (ordersCtx && typeof Chart !== 'undefined') {
        new Chart(ordersCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Orders',
                    data: [0, 0, 0, 0, 0, 0],
                    backgroundColor: '#f59e0b',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' }
                }
            }
        });
    }
    
    // Users Chart
    const usersCtx = document.getElementById('usersChart');
    if (usersCtx && typeof Chart !== 'undefined') {
        new Chart(usersCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'New Users',
                    data: [0, 0, 0, 0, 0, 0],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    fill: true
                }]
            }
        });
    }
}

// ==================== FILTERS & SEARCH ====================

// Filter users table
function filterUsers() {
    const searchTerm = document.getElementById('userSearch')?.value.toLowerCase();
    const rows = document.querySelectorAll('.user-row');
    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

// Filter products table
function filterProducts() {
    const searchTerm = document.getElementById('productSearch')?.value.toLowerCase();
    const status = document.getElementById('productStatus')?.value;
    const rows = document.querySelectorAll('.product-row');
    
    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        const productStatus = row.dataset.status;
        let show = text.includes(searchTerm);
        if (status && status !== 'all') {
            show = show && (productStatus === status);
        }
        row.style.display = show ? '' : 'none';
    });
}

// ==================== BULK ACTIONS ====================

// Select all checkboxes
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.select-item');
    checkboxes.forEach(cb => {
        cb.checked = selectAll.checked;
    });
    updateBulkActionButton();
}

function updateBulkActionButton() {
    const selected = document.querySelectorAll('.select-item:checked').length;
    const btn = document.getElementById('bulkActionBtn');
    if (btn) {
        btn.disabled = selected === 0;
        btn.innerText = `Bulk Action (${selected} selected)`;
    }
}

// Execute bulk action
function executeBulkAction() {
    const selected = document.querySelectorAll('.select-item:checked');
    const action = document.getElementById('bulkActionSelect')?.value;
    
    if (selected.length === 0) {
        showToast('No items selected', 'warning');
        return;
    }
    
    if (!action) {
        showToast('Select an action first', 'warning');
        return;
    }
    
    if (confirm(`Are you sure you want to ${action} ${selected.length} item(s)?`)) {
        const ids = Array.from(selected).map(cb => cb.value);
        // Send AJAX request for bulk action
        fetch('/admin/ajax-bulk-action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: action, ids: ids })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(`Bulk action completed`, 'success');
                location.reload();
            } else {
                showToast('Error performing bulk action', 'error');
            }
        });
    }
}

// ==================== EXPORT FUNCTIONS ====================

// Export users to CSV
function exportUsers() {
    window.location.href = '/admin/export-users.php';
}

// Export orders to CSV
function exportOrders() {
    window.location.href = '/admin/export-orders.php';
}

// ==================== NOTIFICATIONS ====================

// Check for new notifications
function checkNotifications() {
    fetch('/admin/ajax-notifications.php')
        .then(response => response.json())
        .then(data => {
            const badge = document.getElementById('notificationBadge');
            if (badge && data.count > 0) {
                badge.innerText = data.count;
                badge.classList.remove('hidden');
            } else if (badge) {
                badge.classList.add('hidden');
            }
        });
}

// ==================== IMAGE UPLOAD PREVIEW ====================

// Preview image before upload
function previewAdminImage(input, previewId) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById(previewId);
            if (preview) {
                preview.src = e.target.result;
                preview.classList.remove('hidden');
            }
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// ==================== TOOLTIPS ====================

// Initialize tooltips
function initTooltips() {
    document.querySelectorAll('[data-tooltip]').forEach(el => {
        el.addEventListener('mouseenter', (e) => {
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.innerText = el.dataset.tooltip;
            document.body.appendChild(tooltip);
            const rect = el.getBoundingClientRect();
            tooltip.style.top = rect.top - 30 + 'px';
            tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
            el.addEventListener('mouseleave', () => tooltip.remove(), { once: true });
        });
    });
}

// ==================== SIDEBAR TOGGLE (Mobile) ====================

function toggleSidebar() {
    const sidebar = document.querySelector('.admin-sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

// Close sidebar on click outside (mobile)
document.addEventListener('click', function(event) {
    const sidebar = document.querySelector('.admin-sidebar');
    const toggleBtn = document.querySelector('.sidebar-toggle');
    if (window.innerWidth <= 768 && sidebar && sidebar.classList.contains('open')) {
        if (!sidebar.contains(event.target) && !toggleBtn?.contains(event.target)) {
            sidebar.classList.remove('open');
        }
    }
});

// ==================== INITIALIZATION ====================

// Initialize everything on page load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    initAdminCharts();
    
    // Scroll chat to bottom
    scrollChatToBottom();
    
    // Start chat auto refresh
    if (document.getElementById('chatMessages')) {
        startChatAutoRefresh();
    }
    
    // Check notifications every 30 seconds
    if (document.getElementById('notificationBadge')) {
        checkNotifications();
        setInterval(checkNotifications, 30000);
    }
    
    // Initialize tooltips
    initTooltips();
    
    // Image preview listeners
    document.querySelectorAll('.image-input').forEach(input => {
        const previewId = input.dataset.preview;
        if (previewId) {
            input.addEventListener('change', () => previewAdminImage(input, previewId));
        }
    });
    
    // Search input listener
    const userSearch = document.getElementById('userSearch');
    if (userSearch) {
        userSearch.addEventListener('keyup', filterUsers);
    }
    
    const productSearch = document.getElementById('productSearch');
    if (productSearch) {
        productSearch.addEventListener('keyup', filterProducts);
    }
    
    // Select all checkbox
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('change', toggleSelectAll);
    }
    
    // Auto hide flash messages
    document.querySelectorAll('.flash-message').forEach(msg => {
        setTimeout(() => {
            msg.style.opacity = '0';
            setTimeout(() => msg.remove(), 300);
        }, 5000);
    });
});

// ==================== TOAST STYLES (if not already present) ====================
const style = document.createElement('style');
style.textContent = `
    .tooltip {
        position: fixed;
        background: #333;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 9999;
        white-space: nowrap;
    }
`;
document.head.appendChild(style);