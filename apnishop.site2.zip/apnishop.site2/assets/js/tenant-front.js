// Tenant Frontend JavaScript - Complete File
// This file loads on every public storefront

// ==================== CART FUNCTIONS ====================

// Add to cart function
function addToCart(productId) {
    const subdomain = window.location.hostname.split('.')[0];
    fetch('/includes/cart-ajax.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=add&product_id=${productId}&subdomain=${subdomain}`
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Product added to cart', 'success');
            updateCartCount();
        } else {
            showToast('Error adding product', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Network error. Please try again.', 'error');
    });
}

// Update cart count badge
function updateCartCount() {
    const subdomain = window.location.hostname.split('.')[0];
    fetch('/includes/cart-ajax.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=get_count&subdomain=${subdomain}`
    })
    .then(res => res.json())
    .then(data => {
        const cartBadge = document.querySelector('.cart-count');
        if (cartBadge && data.count !== undefined) {
            cartBadge.innerText = data.count;
        }
    })
    .catch(error => console.error('Error updating cart count:', error));
}

// Remove from cart
function removeFromCart(cartId) {
    if (confirm('Remove this item from cart?')) {
        const subdomain = window.location.hostname.split('.')[0];
        fetch('/includes/cart-ajax.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=remove&product_id=${cartId}&subdomain=${subdomain}`
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showToast('Error removing item', 'error');
            }
        });
    }
}

// ==================== POPUP FUNCTIONS ====================

// Load popups from server
function loadPopups() {
    const subdomain = window.location.hostname.split('.')[0];
    fetch(`/includes/get-popups.php?subdomain=${subdomain}`)
    .then(res => res.json())
    .then(popups => {
        popups.forEach(popup => {
            if (popup.show_on_load) {
                setTimeout(() => showPopup(popup), popup.delay_seconds * 1000);
            }
        });
        // Exit popup (when mouse leaves the page)
        if (popups.some(p => p.show_on_exit)) {
            let exitShown = false;
            document.addEventListener('mouseleave', (e) => {
                if (!exitShown && e.clientY <= 0) {
                    exitShown = true;
                    popups.forEach(popup => {
                        if (popup.show_on_exit) showPopup(popup);
                    });
                }
            });
        }
    })
    .catch(error => console.error('Error loading popups:', error));
}

// Show popup modal
function showPopup(popup) {
    const modal = document.getElementById('popupModal');
    if (!modal) return;
    
    document.getElementById('popupTitle').innerText = popup.title;
    document.getElementById('popupMessage').innerText = popup.message;
    
    if (popup.image) {
        const img = document.getElementById('popupImage');
        img.src = `/assets/uploads/popups/${popup.image}`;
        img.style.display = 'block';
    } else {
        document.getElementById('popupImage').style.display = 'none';
    }
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

// Close popup modal
function closePopup() {
    const modal = document.getElementById('popupModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

// ==================== SLIDER FUNCTIONS ====================

// Initialize slider
function initSlider() {
    const slider = document.querySelector('.slider-wrapper');
    if (!slider) return;
    
    const slides = document.querySelectorAll('.slide');
    if (slides.length <= 1) return;
    
    let currentIndex = 0;
    const prevBtn = document.querySelector('.slider-prev');
    const nextBtn = document.querySelector('.slider-next');
    
    function showSlide(index) {
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;
        slider.style.transform = `translateX(-${index * 100}%)`;
        currentIndex = index;
    }
    
    if (prevBtn) {
        prevBtn.addEventListener('click', () => showSlide(currentIndex - 1));
    }
    if (nextBtn) {
        nextBtn.addEventListener('click', () => showSlide(currentIndex + 1));
    }
    
    // Auto slide every 5 seconds
    let autoSlide = setInterval(() => showSlide(currentIndex + 1), 5000);
    
    // Pause auto slide on hover
    const sliderContainer = document.querySelector('.slider-container');
    if (sliderContainer) {
        sliderContainer.addEventListener('mouseenter', () => clearInterval(autoSlide));
        sliderContainer.addEventListener('mouseleave', () => {
            autoSlide = setInterval(() => showSlide(currentIndex + 1), 5000);
        });
    }
}

// Keyboard navigation for slider
function initSliderKeyboard() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            const prevBtn = document.querySelector('.slider-prev');
            if (prevBtn) prevBtn.click();
        } else if (e.key === 'ArrowRight') {
            const nextBtn = document.querySelector('.slider-next');
            if (nextBtn) nextBtn.click();
        }
    });
}

// ==================== PRODUCT REVIEWS ====================

// Star rating preview for reviews
function initStarRating() {
    const stars = document.querySelectorAll('.rating-star');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = this.dataset.value;
            document.getElementById('rating_value').value = rating;
            stars.forEach((s, i) => {
                if (i < rating) {
                    s.classList.add('text-yellow-400');
                    s.classList.remove('text-gray-300');
                } else {
                    s.classList.remove('text-yellow-400');
                    s.classList.add('text-gray-300');
                }
            });
        });
    });
}

// Submit review via AJAX (optional)
function submitReview(productId) {
    const rating = document.getElementById('rating_value')?.value;
    const comment = document.getElementById('review_comment')?.value;
    const name = document.getElementById('reviewer_name')?.value;
    
    if (!rating || !comment || !name) {
        showToast('Please fill all fields', 'error');
        return;
    }
    
    fetch('/includes/submit-review.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `product_id=${productId}&rating=${rating}&comment=${encodeURIComponent(comment)}&name=${encodeURIComponent(name)}`
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Review submitted successfully', 'success');
            location.reload();
        } else {
            showToast('Error submitting review', 'error');
        }
    });
}

// ==================== COUNTDOWN TIMER ====================

// Initialize countdown timers for products
function initCountdownTimers() {
    document.querySelectorAll('.countdown-timer').forEach(timer => {
        const endTime = new Date(timer.dataset.end).getTime();
        if (isNaN(endTime)) return;
        
        const interval = setInterval(() => {
            const now = new Date().getTime();
            const distance = endTime - now;
            
            if (distance < 0) {
                clearInterval(interval);
                timer.innerHTML = "Expired";
                timer.classList.add('text-red-600');
                return;
            }
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (86400000)) / (3600000));
            const minutes = Math.floor((distance % 3600000) / 60000);
            const seconds = Math.floor((distance % 60000) / 1000);
            
            let display = '';
            if (days > 0) display += `${days}d `;
            display += `${hours}h ${minutes}m ${seconds}s`;
            timer.innerHTML = display;
        }, 1000);
    });
}

// ==================== FILTER & SEARCH ====================

// Price range filter
function filterByPrice() {
    const minPrice = document.getElementById('min_price')?.value;
    const maxPrice = document.getElementById('max_price')?.value;
    const url = new URL(window.location.href);
    if (minPrice) url.searchParams.set('min_price', minPrice);
    if (maxPrice) url.searchParams.set('max_price', maxPrice);
    window.location.href = url.toString();
}

// Category filter
function filterByCategory(category) {
    const url = new URL(window.location.href);
    if (category) {
        url.searchParams.set('category', category);
    } else {
        url.searchParams.delete('category');
    }
    window.location.href = url.toString();
}

// ==================== WHATSAPP BUTTON ====================

// Initialize WhatsApp floating button
function initWhatsAppButton(position, number, text) {
    const btnContainer = document.createElement('div');
    btnContainer.className = `whatsapp-float ${position === 'bottom-left' ? 'whatsapp-float-left' : ''}`;
    btnContainer.innerHTML = `<a href="https://wa.me/${number}" target="_blank">💬 ${text}</a>`;
    document.body.appendChild(btnContainer);
}

// ==================== INITIALIZATION ====================

// Initialize everything on page load
document.addEventListener('DOMContentLoaded', () => {
    // Update cart count on every page
    updateCartCount();
    
    // Load popups
    loadPopups();
    
    // Initialize slider
    initSlider();
    initSliderKeyboard();
    
    // Initialize star rating
    initStarRating();
    
    // Initialize countdown timers
    initCountdownTimers();
    
    // Add to cart buttons
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const productId = btn.dataset.productId;
            if (productId) addToCart(productId);
        });
    });
    
    // Price filter submit
    const priceFilterBtn = document.getElementById('priceFilterBtn');
    if (priceFilterBtn) {
        priceFilterBtn.addEventListener('click', filterByPrice);
    }
});