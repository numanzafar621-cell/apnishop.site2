<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = $_GET['subdomain'] ?? getCurrentSubdomain();
if(!$subdomain) die("Invalid request.");
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$min_price = $_GET['min_price'] ?? '';
$max_price = $_GET['max_price'] ?? '';

$sql = "SELECT * FROM products WHERE user_id = ? AND is_active = 1";
$params = [$userId];
if($search) { $sql .= " AND (name LIKE ? OR description LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
if($category) { $sql .= " AND category = ?"; $params[] = $category; }
if($min_price !== '') { $sql .= " AND price >= ?"; $params[] = $min_price; }
if($max_price !== '') { $sql .= " AND price <= ?"; $params[] = $max_price; }
$sql .= " ORDER BY id DESC";
$products = db_get_all($sql, $params);
$categories = db_get_all("SELECT DISTINCT category FROM products WHERE user_id = ? AND is_active = 1 AND category IS NOT NULL AND category != ''", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Shop - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <style>:root{--primary:<?= $theme['primary_color'] ?>;}</style>
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Shop</h1>
        <div class="flex flex-col md:flex-row gap-6">
            <div class="w-full md:w-64 bg-white p-4 rounded shadow h-fit">
                <h3 class="font-bold text-lg mb-3">Filter</h3>
                <form method="GET">
                    <div class="mb-3"><label class="block text-sm">Search</label><input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="w-full border rounded px-2 py-1"></div>
                    <div class="mb-3"><label class="block text-sm">Category</label><select name="category" class="w-full border rounded px-2 py-1"><option value="">All</option><?php foreach($categories as $c): ?><option value="<?= htmlspecialchars($c['category']) ?>" <?= $category==$c['category']?'selected':'' ?>><?= $c['category'] ?></option><?php endforeach; ?></select></div>
                    <div class="mb-3 grid grid-cols-2 gap-2"><div><label>Min Price</label><input type="number" name="min_price" value="<?= $min_price ?>" class="w-full border rounded px-2 py-1"></div><div><label>Max Price</label><input type="number" name="max_price" value="<?= $max_price ?>" class="w-full border rounded px-2 py-1"></div></div>
                    <button type="submit" class="bg-indigo-600 text-white px-3 py-1 rounded w-full">Filter</button>
                    <a href="shop.php" class="block text-center text-sm text-gray-500 mt-2">Clear</a>
                </form>
            </div>
            <div class="flex-1">
                <?php if(empty($products)): ?><div class="bg-white p-8 rounded text-center">No products found.</div><?php else: ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach($products as $p): ?>
                    <div class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition"><a href="product.php?id=<?= $p['id'] ?>"><img src="/assets/uploads/products/<?= $p['image'] ?>" class="h-48 w-full object-cover"></a><div class="p-4"><h3 class="font-bold text-lg"><?= htmlspecialchars($p['name']) ?></h3><p><?= formatPrice($p['price']) ?></p><div class="flex items-center my-2"><?php $r=getAverageRating($p['id']); for($i=1;$i<=5;$i++) echo '<span class="text-yellow-400">'.($i<=$r?'★':'☆').'</span>'; ?></div><button onclick="addToCart(<?= $p['id'] ?>)" class="bg-indigo-600 text-white px-4 py-2 rounded-full w-full">Add to Cart</button></div></div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
    <script>function addToCart(id){fetch('/includes/cart-ajax.php',{method:'POST',body:'action=add&product_id='+id+'&subdomain=<?= $subdomain ?>',headers:{'Content-Type':'application/x-www-form-urlencoded'}}).then(()=>location.reload());}</script>
</body>
</html>