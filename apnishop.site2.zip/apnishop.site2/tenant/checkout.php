<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);
$session_id = session_id();

$cartItems = db_get_all("SELECT c.*, p.name, p.price FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ? AND c.session_id = ?", [$userId, $session_id]);
if(empty($cartItems)) { header('Location: cart.php'); exit; }
$total = 0;
foreach($cartItems as $item) $total += $item['price'] * $item['quantity'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_name = trim($_POST['customer_name']);
    $customer_email = trim($_POST['customer_email']);
    $customer_phone = trim($_POST['customer_phone']);
    $customer_address = trim($_POST['customer_address']);
    $payment_method = $_POST['payment_method'];
    
    $order_number = generateOrderNumber();
    $order_id = db_insert('orders', [
        'user_id' => $userId,
        'order_number' => $order_number,
        'customer_name' => $customer_name,
        'customer_email' => $customer_email,
        'customer_phone' => $customer_phone,
        'customer_address' => $customer_address,
        'total_amount' => $total,
        'status' => 'pending',
        'payment_method' => $payment_method,
        'payment_status' => 'unpaid'
    ]);
    foreach($cartItems as $item) {
        db_insert('order_items', ['order_id'=>$order_id, 'product_id'=>$item['product_id'], 'quantity'=>$item['quantity'], 'price'=>$item['price']]);
        $prod = db_get_row("SELECT stock FROM products WHERE id = ?", [$item['product_id']]);
        if($prod && $prod['stock'] > 0) db_update("products", ['stock' => $prod['stock'] - $item['quantity']], "id = ?", [$item['product_id']]);
    }
    db_delete("cart", "session_id = ? AND user_id = ?", [$session_id, $userId]);
    header("Location: checkout-success.php?order=$order_number");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Checkout</h1>
        <div class="grid md:grid-cols-2 gap-8">
            <div class="bg-white p-6 rounded shadow"><h2 class="text-xl font-bold mb-4">Billing Details</h2>
                <form method="POST"><div class="mb-3"><label>Full Name *</label><input type="text" name="customer_name" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Email *</label><input type="email" name="customer_email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Phone *</label><input type="tel" name="customer_phone" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Address *</label><textarea name="customer_address" required class="w-full border rounded px-3 py-2"></textarea></div>
                <div class="mb-3"><label>Payment Method *</label><select name="payment_method" required class="w-full border rounded px-3 py-2"><option value="cod">Cash on Delivery</option><option value="bank">Bank Transfer</option><option value="easypaisa">Easypaisa</option><option value="jazzcash">JazzCash</option></select></div>
                <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded w-full">Place Order</button></form>
            </div>
            <div class="bg-white p-6 rounded shadow h-fit"><h2 class="text-xl font-bold mb-4">Your Order</h2>
                <?php foreach($cartItems as $item): ?><div class="flex justify-between py-2 border-b"><?= htmlspecialchars($item['name']) ?> x <?= $item['quantity'] ?> <span><?= formatPrice($item['price'] * $item['quantity']) ?></span></div><?php endforeach; ?>
                <div class="flex justify-between font-bold pt-2">Total <span><?= formatPrice($total) ?></span></div>
            </div>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
</body>
</html>