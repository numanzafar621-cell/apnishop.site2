<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
if(!$subdomain) die("Invalid request.");
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';

$sql = "SELECT * FROM blogs WHERE user_id = ? AND is_published = 1";
$params = [$userId];
if($category) { $sql .= " AND category = ?"; $params[] = $category; }
if($search) { $sql .= " AND (title LIKE ? OR content LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= " ORDER BY id DESC";
$blogs = db_get_all($sql, $params);
$categories = db_get_all("SELECT DISTINCT category FROM blogs WHERE user_id = ? AND is_published = 1 AND category IS NOT NULL", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Blog - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Our Blog</h1>
        <div class="flex flex-col md:flex-row gap-6">
            <div class="w-full md:w-64 bg-white p-4 rounded shadow h-fit">
                <h3 class="font-bold mb-2">Filter</h3>
                <form method="GET">
                    <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>" class="w-full border rounded px-2 py-1 mb-2">
                    <select name="category" class="w-full border rounded px-2 py-1 mb-2">
                        <option value="">All Categories</option>
                        <?php foreach($categories as $c): ?>
                            <option value="<?= htmlspecialchars($c['category']) ?>" <?= $category==$c['category']?'selected':'' ?>><?= $c['category'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="bg-indigo-600 text-white px-3 py-1 rounded w-full">Filter</button>
                    <a href="blog.php" class="block text-center text-sm mt-2">Clear</a>
                </form>
            </div>
            <div class="flex-1">
                <?php if(empty($blogs)): ?><div class="bg-white p-8 rounded text-center">No blog posts found.</div><?php else: ?>
                <div class="grid gap-6">
                    <?php foreach($blogs as $b): ?>
                    <div class="bg-white rounded shadow overflow-hidden flex flex-col md:flex-row">
                        <?php if($b['featured_image']): ?><img src="/assets/uploads/blogs/<?= $b['featured_image'] ?>" class="h-48 w-full md:w-48 object-cover"><?php endif; ?>
                        <div class="p-4 flex-1">
                            <h2 class="text-xl font-bold"><a href="single-blog.php?slug=<?= $b['slug'] ?>" class="hover:text-indigo-600"><?= htmlspecialchars($b['title']) ?></a></h2>
                            <p class="text-gray-500 text-sm"><?= date('d-m-Y', strtotime($b['created_at'])) ?> | <?= $b['category'] ?: 'Uncategorized' ?></p>
                            <p class="mt-2"><?= excerpt(strip_tags($b['content']), 150) ?></p>
                            <a href="single-blog.php?slug=<?= $b['slug'] ?>" class="text-indigo-600 mt-2 inline-block">Read More →</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
</body>
</html>