<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

$subdomain = getCurrentSubdomain();
$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $business_name = trim($_POST['business_name']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    
    if(empty($business_name) || empty($first_name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'Please fill all required fields.';
    } elseif($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $existing = db_get_row("SELECT id FROM users WHERE email = ?", [$email]);
        if($existing) {
            $error = 'Email already registered.';
        } else {
            $existingSub = db_get_row("SELECT id FROM users WHERE subdomain = ?", [$subdomain]);
            if($existingSub) {
                $error = 'This subdomain is already taken.';
            } else {
                $hashed = hashPassword($password);
                db_insert('users', [
                    'business_name' => $business_name,
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'email' => $email,
                    'phone' => $phone,
                    'password' => $hashed,
                    'subdomain' => $subdomain,
                    'is_active' => 0,
                    'plan_id' => 1,
                    'plan_expiry' => date('Y-m-d', strtotime('+30 days'))
                ]);
                $success = 'Account created successfully. Please login.';
                header('refresh:2;url=login.php');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Store - <?= htmlspecialchars($subdomain) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Create Your Store</h2>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3"><label>Business Name</label><input type="text" name="business_name" required class="w-full border rounded px-3 py-2"></div>
                <div class="grid grid-cols-2 gap-3 mb-3"><div><label>First Name</label><input type="text" name="first_name" required class="w-full border rounded px-3 py-2"></div><div><label>Last Name</label><input type="text" name="last_name" class="w-full border rounded px-3 py-2"></div></div>
                <div class="mb-3"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Phone</label><input type="tel" name="phone" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Password</label><input type="password" name="password" required minlength="6" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-4"><label>Confirm Password</label><input type="password" name="confirm_password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded">Create Store</button>
            </form>
        </div>
    </div>
</body>
</html>