<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

userLogout();
header('Location: login.php');
exit;
?>