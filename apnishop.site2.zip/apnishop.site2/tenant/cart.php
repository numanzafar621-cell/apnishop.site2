<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);
$session_id = session_id();

if(isset($_POST['update_cart'])) {
    foreach($_POST['quantity'] as $cartId => $qty) {
        if($qty <= 0) db_delete("cart", "id = ?", [$cartId]);
        else db_update("cart", ['quantity' => $qty], "id = ?", [$cartId]);
    }
    header('Location: cart.php');
    exit;
}
if(isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    db_delete("cart", "id = ? AND session_id = ?", [$_GET['remove'], $session_id]);
    header('Location: cart.php');
    exit;
}
$cartItems = db_get_all("SELECT c.*, p.name, p.price, p.image FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ? AND c.session_id = ?", [$userId, $session_id]);
$total = 0;
foreach($cartItems as $item) $total += $item['price'] * $item['quantity'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Cart - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Shopping Cart</h1>
        <?php if(empty($cartItems)): ?>
            <div class="bg-white p-8 rounded shadow text-center">Your cart is empty. <a href="shop.php" class="text-indigo-600">Continue shopping</a></div>
        <?php else: ?>
            <form method="POST">
                <div class="bg-white rounded shadow overflow-hidden">
                    <table class="min-w-full"><thead class="bg-gray-800 text-white"><tr><th class="p-3">Product</th><th>Price</th><th>Quantity</th><th>Total</th><th></th></tr></thead>
                    <tbody><?php foreach($cartItems as $item): ?><tr class="border-t"><td class="p-3 flex items-center"><img src="/assets/uploads/products/<?= $item['image'] ?>" class="h-12 w-12 object-cover mr-3"><?= htmlspecialchars($item['name']) ?></td><td class="p-3"><?= formatPrice($item['price']) ?></td><td class="p-3"><input type="number" name="quantity[<?= $item['id'] ?>]" value="<?= $item['quantity'] ?>" min="1" class="w-16 border rounded px-2 py-1"></td><td class="p-3"><?= formatPrice($item['price'] * $item['quantity']) ?></td><td class="p-3"><a href="?remove=<?= $item['id'] ?>" class="text-red-600" onclick="return confirm('Remove item?')">Remove</a></td></tr><?php endforeach; ?>
                    <tr class="border-t font-bold"><td colspan="3" class="p-3 text-right">Total:</td><td class="p-3"><?= formatPrice($total) ?></td><td></td></tr></tbody>
                    </table>
                </div>
                <div class="mt-4 flex justify-between"><button type="submit" name="update_cart" class="bg-gray-600 text-white px-4 py-2 rounded">Update Cart</button><a href="checkout.php" class="bg-indigo-600 text-white px-6 py-2 rounded">Proceed to Checkout</a></div>
            </form>
        <?php endif; ?>
    </div>
    <?php getTenantFooter($userId); ?>
</body>
</html>