<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$banner = db_get_row("SELECT * FROM small_banners WHERE id = ? AND user_id = ?", [$id, $userId]);
if(!$banner) { header('Location: banners.php'); exit; }

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $link = trim($_POST['link']);
    $order_position = intval($_POST['order_position']);
    if($order_position < 0) $order_position = 0;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    $updateData = [
        'title' => $title,
        'link' => $link,
        'order_position' => $order_position,
        'is_active' => $is_active
    ];
    
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','webp'];
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $uploadDir = '../../assets/uploads/banners/';
            ensureDirectory($uploadDir);
            if($banner['image'] && file_exists($uploadDir . $banner['image'])) {
                unlink($uploadDir . $banner['image']);
            }
            $newName = time() . '_banner_' . uniqid() . '.' . $ext;
            if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newName)) {
                $updateData['image'] = $newName;
            } else {
                $error = 'Failed to upload new image.';
            }
        } else {
            $error = 'Only JPG, PNG, WEBP images allowed.';
        }
    }
    
    if(!$error) {
        db_update("small_banners", $updateData, "id = ?", [$id]);
        header('Location: banners.php?msg=updated');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Small Banner</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Edit Banner</h1>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="mb-3"><label>Title</label><input type="text" name="title" value="<?= htmlspecialchars($banner['title']) ?>" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Link</label><input type="url" name="link" value="<?= htmlspecialchars($banner['link']) ?>" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Order Position</label><input type="number" name="order_position" value="<?= $banner['order_position'] ?>" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3">
                    <label>Current Image</label><br>
                    <img src="/assets/uploads/banners/<?= $banner['image'] ?>" class="h-20 mb-2">
                    <input type="file" name="image" accept="image/*" class="w-full border rounded px-3 py-2">
                </div>
                <div class="mb-3">
                    <label><input type="checkbox" name="is_active" value="1" <?= $banner['is_active'] ? 'checked' : '' ?>> Active</label>
                </div>
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Save Changes</button>
                <a href="banners.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>