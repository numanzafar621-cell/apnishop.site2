<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);
    if($message) {
        db_insert('live_chat', [
            'from_user_id' => $userId,
            'to_user_id' => $userId,
            'from_admin' => 0,
            'message' => $message,
            'is_read' => 0
        ]);
        header('Location: live-chat.php');
        exit;
    }
}

$messages = db_get_all("SELECT * FROM live_chat WHERE (from_user_id = ? AND from_admin = 0) OR (to_user_id = ? AND from_admin = 1) ORDER BY created_at ASC", [$userId, $userId]);
db_update("live_chat", ['is_read' => 1], "to_user_id = ? AND from_admin = 1", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Live Chat with Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <meta http-equiv="refresh" content="5">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 flex flex-col">
            <div class="bg-white p-3 border-b font-bold">Live Chat - Admin Support</div>
            <div class="flex-1 overflow-y-auto p-4 space-y-2" id="chatMessages">
                <?php foreach($messages as $msg): ?>
                <div class="<?= $msg['from_admin'] ? 'text-left' : 'text-right' ?>">
                    <div class="inline-block p-2 rounded max-w-md <?= $msg['from_admin'] ? 'bg-gray-200 text-gray-800' : 'bg-indigo-600 text-white' ?>">
                        <?= nl2br(htmlspecialchars($msg['message'])) ?>
                    </div>
                    <div class="text-xs text-gray-400 mt-1"><?= date('h:i A, d-m-Y', strtotime($msg['created_at'])) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <form method="POST" class="bg-white p-3 border-t flex gap-2">
                <input type="text" name="message" required class="flex-1 border rounded px-3 py-2" placeholder="Type your message...">
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Send</button>
            </form>
        </div>
    </div>
    <script>
        let chatDiv = document.getElementById('chatMessages');
        if(chatDiv) chatDiv.scrollTop = chatDiv.scrollHeight;
        setTimeout(() => location.reload(), 5000);
    </script>
</body>
</html>