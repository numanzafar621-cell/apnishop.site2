<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

// Delete blog post
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = $_GET['delete'];
    $blog = db_get_row("SELECT featured_image FROM blogs WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($blog && $blog['featured_image']) {
        $filePath = '../../assets/uploads/blogs/' . $blog['featured_image'];
        if(file_exists($filePath)) unlink($filePath);
    }
    db_delete("blogs", "id = ? AND user_id = ?", [$id, $userId]);
    header('Location: blog.php?msg=deleted');
    exit;
}

// Toggle publish status
if(isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $blog = db_get_row("SELECT is_published FROM blogs WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($blog) {
        $new = $blog['is_published'] ? 0 : 1;
        db_update("blogs", ['is_published' => $new], "id = ?", [$id]);
    }
    header('Location: blog.php');
    exit;
}

$blogs = db_get_all("SELECT * FROM blogs WHERE user_id = ? ORDER BY id DESC", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Blog Management - Seller Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold">My Store</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700">📊 Dashboard</a></li>
                <li><a href="products.php" class="block py-2 px-4 hover:bg-indigo-700">🛍️ Products</a></li>
                <li><a href="orders.php" class="block py-2 px-4 hover:bg-indigo-700">📦 Orders</a></li>
                <li><a href="pages.php" class="block py-2 px-4 hover:bg-indigo-700">📄 Pages</a></li>
                <li><a href="blog.php" class="block py-2 px-4 bg-indigo-900">📝 Blog</a></li>
                <li><a href="theme.php" class="block py-2 px-4 hover:bg-indigo-700">🎨 Theme</a></li>
                <li><a href="slider.php" class="block py-2 px-4 hover:bg-indigo-700">🖼️ Slider</a></li>
                <li><a href="banners.php" class="block py-2 px-4 hover:bg-indigo-700">🏷️ Banners</a></li>
                <li><a href="popups.php" class="block py-2 px-4 hover:bg-indigo-700">🪟 Popups</a></li>
                <li><a href="whatsapp.php" class="block py-2 px-4 hover:bg-indigo-700">💬 WhatsApp</a></li>
                <li><a href="payment-gateway.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateway</a></li>
                <li><a href="plan.php" class="block py-2 px-4 hover:bg-indigo-700">📅 Plan</a></li>
                <li><a href="verification.php" class="block py-2 px-4 hover:bg-yellow-700">✅ CNIC</a></li>
                <li><a href="profile.php" class="block py-2 px-4 hover:bg-indigo-700">👤 Profile</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 hover:bg-indigo-700">💬 Live Chat</a></li>
                <li><a href="timer.php" class="block py-2 px-4 hover:bg-indigo-700">⏱️ Timer</a></li>
                <li><a href="settings.php" class="block py-2 px-4 hover:bg-indigo-700">⚙️ Settings</a></li>
                <li><a href="../logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        <div class="flex-1 p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold">Blog Posts</h1>
                <a href="add-blog.php" class="bg-indigo-600 text-white px-4 py-2 rounded">+ Add New Post</a>
            </div>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>
                <div class="bg-green-100 p-3 rounded mb-4">Blog post deleted.</div>
            <?php endif; ?>
            <?php if(empty($blogs)): ?>
                <div class="bg-white p-8 rounded shadow text-center">No blog posts yet. <a href="add-blog.php" class="text-indigo-600">Write your first post</a></div>
            <?php else: ?>
            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full">
                    <thead class="bg-gray-800 text-white">
                        <tr><th class="p-3">Image</th><th>Title</th><th>Category</th><th>Published</th><th>Date</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($blogs as $b): ?>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="p-3"><?php if($b['featured_image']): ?><img src="/assets/uploads/blogs/<?= $b['featured_image'] ?>" class="h-12 w-12 object-cover rounded"><?php else: ?>📷<?php endif; ?></td>
                            <td class="p-3"><?= htmlspecialchars($b['title']) ?></td>
                            <td class="p-3"><?= htmlspecialchars($b['category']) ?: '-' ?></td>
                            <td class="p-3"><?= $b['is_published'] ? '<span class="bg-green-100 text-green-800 px-2 py-1 rounded">Published</span>' : '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Draft</span>' ?></td>
                            <td class="p-3"><?= date('d-m-Y', strtotime($b['created_at'])) ?></td>
                            <td class="p-3">
                                <a href="edit-blog.php?id=<?= $b['id'] ?>" class="text-blue-600 mr-2">✏️ Edit</a>
                                <a href="?toggle=<?= $b['id'] ?>" class="text-green-600 mr-2">🔄 Toggle</a>
                                <a href="?delete=<?= $b['id'] ?>" class="text-red-600" onclick="return confirm('Delete this post?')">🗑️ Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>