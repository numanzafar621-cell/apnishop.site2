<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $title = trim($_POST['title']);
    $subtitle = trim($_POST['subtitle']);
    $button_text = trim($_POST['button_text']);
    $button_link = trim($_POST['button_link']);
    $order_position = intval($_POST['order_position']);
    if($order_position < 0) $order_position = 0;
    
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp'])) {
            $uploadDir = '../../assets/uploads/sliders/';
            ensureDirectory($uploadDir);
            $image = time() . '_slider_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $image);
            db_insert('sliders', [
                'user_id' => $userId,
                'title' => $title,
                'subtitle' => $subtitle,
                'image' => $image,
                'button_text' => $button_text,
                'button_link' => $button_link,
                'order_position' => $order_position,
                'is_active' => 1
            ]);
            header('Location: slider.php?msg=added');
            exit;
        }
    }
}

if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = $_GET['delete'];
    $slider = db_get_row("SELECT image FROM sliders WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($slider && $slider['image']) {
        $filePath = '../../assets/uploads/sliders/' . $slider['image'];
        if(file_exists($filePath)) unlink($filePath);
    }
    db_delete("sliders", "id = ? AND user_id = ?", [$id, $userId]);
    header('Location: slider.php?msg=deleted');
    exit;
}

if(isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $slider = db_get_row("SELECT is_active FROM sliders WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($slider) {
        $new = $slider['is_active'] ? 0 : 1;
        db_update("sliders", ['is_active' => $new], "id = ?", [$id]);
    }
    header('Location: slider.php');
    exit;
}

$sliders = db_get_all("SELECT * FROM sliders WHERE user_id = ? ORDER BY order_position ASC", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Slider Management</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Slider Management</h1>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'added'): ?><div class="bg-green-100 p-3 rounded mb-4">Slider added.</div><?php endif; ?>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?><div class="bg-red-100 p-3 rounded mb-4">Slider deleted.</div><?php endif; ?>
            <div class="bg-white p-6 rounded shadow mb-8">
                <h2 class="text-xl font-bold mb-4">Add New Slider</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="add">
                    <div class="grid grid-cols-2 gap-4">
                        <div><label>Title</label><input type="text" name="title" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Subtitle</label><input type="text" name="subtitle" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Button Text</label><input type="text" name="button_text" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Button Link</label><input type="url" name="button_link" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Order Position</label><input type="number" name="order_position" value="0" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Image *</label><input type="file" name="image" accept="image/*" required class="w-full border rounded px-3 py-2"></div>
                    </div>
                    <div class="mt-4"><button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Add Slider</button></div>
                </form>
            </div>
            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full">
                    <thead class="bg-gray-800 text-white">
                        <tr><th>Image</th><th>Title</th><th>Order</th><th>Status</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($sliders as $s): ?>
                        <tr class="border-t">
                            <td class="p-3"><img src="/assets/uploads/sliders/<?= $s['image'] ?>" class="h-12 w-auto"></td>
                            <td class="p-3"><?= htmlspecialchars($s['title']) ?></td>
                            <td class="p-3"><?= $s['order_position'] ?></td>
                            <td class="p-3"><?= $s['is_active'] ? 'Active' : 'Inactive' ?></td>
                            <td class="p-3"><a href="?toggle=<?= $s['id'] ?>" class="text-blue-600 mr-2">Toggle</a><a href="?delete=<?= $s['id'] ?>" class="text-red-600" onclick="return confirm('Delete slider?')">Delete</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>