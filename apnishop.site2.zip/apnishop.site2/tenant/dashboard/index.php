<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$totalProducts = db_get_value("SELECT COUNT(*) FROM products WHERE user_id = ?", [$userId]);
$activeProducts = db_get_value("SELECT COUNT(*) FROM products WHERE user_id = ? AND is_active = 1", [$userId]);
$totalOrders = db_get_value("SELECT COUNT(*) FROM orders WHERE user_id = ?", [$userId]);
$pendingOrders = db_get_value("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'pending'", [$userId]);
$recentOrders = db_get_all("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 5", [$userId]);
$plan = db_get_row("SELECT * FROM plans WHERE id = ?", [$user['plan_id']]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Seller Dashboard - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/tenant-dashboard.css">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold border-b border-indigo-700">My Store</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700 bg-indigo-900">📊 Dashboard</a></li>
                <li><a href="products.php" class="block py-2 px-4 hover:bg-indigo-700">🛍️ Products</a></li>
                <li><a href="orders.php" class="block py-2 px-4 hover:bg-indigo-700">📦 Orders</a></li>
                <li><a href="pages.php" class="block py-2 px-4 hover:bg-indigo-700">📄 Pages</a></li>
                <li><a href="blog.php" class="block py-2 px-4 hover:bg-indigo-700">📝 Blog</a></li>
                <li><a href="theme.php" class="block py-2 px-4 hover:bg-indigo-700">🎨 Theme</a></li>
                <li><a href="slider.php" class="block py-2 px-4 hover:bg-indigo-700">🖼️ Slider</a></li>
                <li><a href="banners.php" class="block py-2 px-4 hover:bg-indigo-700">🏷️ Small Banners</a></li>
                <li><a href="popups.php" class="block py-2 px-4 hover:bg-indigo-700">🪟 Popups</a></li>
                <li><a href="whatsapp.php" class="block py-2 px-4 hover:bg-indigo-700">💬 WhatsApp</a></li>
                <li><a href="payment-gateway.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateway</a></li>
                <li><a href="plan.php" class="block py-2 px-4 hover:bg-indigo-700">📅 Plan</a></li>
                <li><a href="verification.php" class="block py-2 px-4 hover:bg-yellow-700">✅ CNIC Verification</a></li>
                <li><a href="profile.php" class="block py-2 px-4 hover:bg-indigo-700">👤 Profile</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 hover:bg-indigo-700">💬 Live Chat</a></li>
                <li><a href="timer.php" class="block py-2 px-4 hover:bg-indigo-700">⏱️ Timer</a></li>
                <li><a href="settings.php" class="block py-2 px-4 hover:bg-indigo-700">⚙️ Settings</a></li>
                <li><a href="logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        <div class="flex-1 overflow-y-auto p-6">
            <div class="flex justify-between items-center mb-6"><h1 class="text-3xl font-bold">Welcome, <?= htmlspecialchars($user['first_name']) ?>!</h1><a href="http://<?= $user['subdomain'] ?>.apnishop.site" target="_blank" class="bg-green-600 text-white px-4 py-2 rounded">🌐 View My Website</a></div>
            <?php if(!$user['cnic_front'] || !$user['cnic_back']): ?><div class="bg-yellow-100 p-4 rounded mb-4">⚠️ CNIC verification pending. <a href="verification.php" class="font-bold underline">Click here to complete</a>.</div><?php endif; ?>
            <div class="grid grid-cols-4 gap-6 mb-8">
                <div class="bg-white p-4 rounded shadow"><div>Total Products</div><div class="text-3xl font-bold"><?= $totalProducts ?></div></div>
                <div class="bg-white p-4 rounded shadow"><div>Active Products</div><div class="text-3xl font-bold text-green-600"><?= $activeProducts ?></div></div>
                <div class="bg-white p-4 rounded shadow"><div>Total Orders</div><div class="text-3xl font-bold"><?= $totalOrders ?></div></div>
                <div class="bg-white p-4 rounded shadow"><div>Pending Orders</div><div class="text-3xl font-bold text-yellow-600"><?= $pendingOrders ?></div></div>
            </div>
            <div class="bg-white p-4 rounded shadow mb-8"><h2 class="text-xl font-bold mb-2">Your Plan</h2><p><strong>Plan:</strong> <?= $plan ? $plan['name'] : 'Free' ?></p><p><strong>Expires:</strong> <?= $user['plan_expiry'] ? date('d-m-Y', strtotime($user['plan_expiry'])) : 'Lifetime' ?></p></div>
            <div class="bg-white rounded shadow overflow-hidden"><div class="px-6 py-4 border-b font-bold text-lg">Recent Orders</div><table class="min-w-full"><thead class="bg-gray-50"><tr><th class="px-6 py-3">Order #</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr></thead><tbody><?php foreach($recentOrders as $o): ?><tr class="border-t"><td class="px-6 py-3"><?= $o['order_number'] ?></td><td><?= htmlspecialchars($o['customer_name']) ?></td><td><?= formatPrice($o['total_amount']) ?></td><td><?= $o['status'] ?></td><td><?= date('d-m-Y', strtotime($o['created_at'])) ?></td></tr><?php endforeach; ?></tbody></table></div>
        </div>
    </div>
</body>
</html>