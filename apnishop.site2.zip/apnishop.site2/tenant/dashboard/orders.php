<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

if(isset($_POST['update_status']) && isset($_POST['order_id'])) {
    $orderId = intval($_POST['order_id']);
    $status = $_POST['status'];
    db_update("orders", ['status' => $status], "id = ? AND user_id = ?", [$orderId, $userId]);
    header('Location: orders.php?msg=updated');
    exit;
}

$orders = db_get_all("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Orders - Seller Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Orders</h1>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'updated'): ?><div class="bg-green-100 p-3 rounded mb-4">Order status updated.</div><?php endif; ?>
            <?php if(empty($orders)): ?><div class="bg-white p-8 rounded shadow text-center">No orders yet.</div><?php else: ?>
            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full">
                    <thead class="bg-gray-800 text-white">
                        <tr><th class="p-3">Order #</th><th>Customer</th><th>Phone</th><th>Total</th><th>Status</th><th>Payment</th><th>Date</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($orders as $o): ?>
                        <tr class="border-t">
                            <td class="p-3"><?= $o['order_number'] ?></td>
                            <td class="p-3"><?= htmlspecialchars($o['customer_name']) ?></td>
                            <td class="p-3"><?= $o['customer_phone'] ?></td>
                            <td class="p-3"><?= formatPrice($o['total_amount']) ?></td>
                            <td class="p-3">
                                <form method="POST" class="inline"><input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <select name="status" onchange="this.form.submit()" class="border rounded px-2 py-1 text-sm">
                                    <option value="pending" <?= $o['status']=='pending'?'selected':'' ?>>Pending</option>
                                    <option value="processing" <?= $o['status']=='processing'?'selected':'' ?>>Processing</option>
                                    <option value="delivered" <?= $o['status']=='delivered'?'selected':'' ?>>Delivered</option>
                                    <option value="cancelled" <?= $o['status']=='cancelled'?'selected':'' ?>>Cancelled</option>
                                </select></form>
                            </td>
                            <td class="p-3"><span class="px-2 py-1 rounded text-xs <?= $o['payment_status']=='paid'?'bg-green-100 text-green-800':'bg-red-100 text-red-800' ?>"><?= ucfirst($o['payment_status']) ?></span></td>
                            <td class="p-3"><?= date('d-m-Y', strtotime($o['created_at'])) ?></td>
                            <td class="p-3"><a href="order-details.php?id=<?= $o['id'] ?>" class="text-blue-600">View</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>