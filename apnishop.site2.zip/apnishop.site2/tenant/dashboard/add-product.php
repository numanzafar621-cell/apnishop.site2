<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $compare_price = !empty($_POST['compare_price']) ? floatval($_POST['compare_price']) : null;
    $stock = intval($_POST['stock']);
    $category = trim($_POST['category']);
    $banner_link = trim($_POST['banner_link']);
    
    // Main image
    $image = null;
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','webp'];
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $uploadDir = '../../assets/uploads/products/';
            ensureDirectory($uploadDir);
            $image = time() . '_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $image);
        } else {
            $error = 'Only JPG, PNG, WEBP images allowed.';
        }
    } else {
        $error = 'Product image is required.';
    }
    
    // Banner image (optional)
    $banner_image = null;
    if(isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','webp'];
        $ext = strtolower(pathinfo($_FILES['banner_image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $uploadDir = '../../assets/uploads/products/banners/';
            ensureDirectory($uploadDir);
            $banner_image = time() . '_banner_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['banner_image']['tmp_name'], $uploadDir . $banner_image);
        }
    }
    
    if(!$error && $image) {
        $slug = createSlug($name);
        $existing = db_get_value("SELECT id FROM products WHERE user_id = ? AND slug = ?", [$userId, $slug]);
        if($existing) $slug = $slug . '-' . time();
        
        db_insert('products', [
            'user_id' => $userId,
            'name' => $name,
            'slug' => $slug,
            'description' => $description,
            'price' => $price,
            'compare_price' => $compare_price,
            'stock' => $stock,
            'category' => $category,
            'image' => $image,
            'banner_image' => $banner_image,
            'banner_link' => $banner_link,
            'is_active' => 0
        ]);
        header('Location: products.php?msg=added');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Product</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Add New Product</h1>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="grid grid-cols-2 gap-4">
                    <div><label>Product Name *</label><input type="text" name="name" required class="w-full border rounded px-3 py-2"></div>
                    <div><label>Price (Rs.) *</label><input type="number" step="0.01" name="price" required class="w-full border rounded px-3 py-2"></div>
                    <div><label>Compare Price</label><input type="number" step="0.01" name="compare_price" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Stock</label><input type="number" name="stock" value="0" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Category</label><input type="text" name="category" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Product Image *</label><input type="file" name="image" accept="image/*" required class="w-full border rounded px-3 py-2"></div>
                    <div class="col-span-2"><label>Description</label><textarea name="description" rows="5" class="w-full border rounded px-3 py-2"></textarea></div>
                    <div class="col-span-2 border-t pt-4"><h3 class="font-bold">Product Bottom Banner (Optional)</h3></div>
                    <div><label>Banner Image</label><input type="file" name="banner_image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Banner Link</label><input type="url" name="banner_link" class="w-full border rounded px-3 py-2"></div>
                </div>
                <div class="mt-6"><button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Add Product</button><a href="products.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a></div>
            </form>
        </div>
    </div>
</body>
</html>