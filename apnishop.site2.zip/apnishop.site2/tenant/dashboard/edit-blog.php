<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$blogId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$blog = db_get_row("SELECT * FROM blogs WHERE id = ? AND user_id = ?", [$blogId, $userId]);
if(!$blog) {
    header('Location: blog.php');
    exit;
}

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $content = $_POST['content'];
    $category = trim($_POST['category']);
    $tags = trim($_POST['tags']);
    $is_published = isset($_POST['is_published']) ? 1 : 0;
    
    $updateData = [
        'title' => $title,
        'content' => $content,
        'category' => $category,
        'tags' => $tags,
        'is_published' => $is_published
    ];
    
    if(isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['featured_image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            $uploadDir = '../../assets/uploads/blogs/';
            ensureDirectory($uploadDir);
            // Delete old image
            if($blog['featured_image'] && file_exists($uploadDir . $blog['featured_image'])) {
                unlink($uploadDir . $blog['featured_image']);
            }
            $newName = time() . '_blog_' . uniqid() . '.' . $ext;
            if(move_uploaded_file($_FILES['featured_image']['tmp_name'], $uploadDir . $newName)) {
                $updateData['featured_image'] = $newName;
            } else {
                $error = 'Failed to upload new featured image.';
            }
        } else {
            $error = 'Only JPG, PNG, WEBP images allowed.';
        }
    }
    
    if(!$error) {
        db_update("blogs", $updateData, "id = ? AND user_id = ?", [$blogId, $userId]);
        header('Location: blog.php?msg=updated');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Blog Post</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: '.editor',
            height: 350,
            menubar: false,
            plugins: 'image code link lists',
            toolbar: 'undo redo | formatselect | bold italic underline | alignleft aligncenter alignright | bullist numlist | image code link'
        });
    </script>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold border-b border-indigo-700">My Store</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700">📊 Dashboard</a></li>
                <li><a href="products.php" class="block py-2 px-4 hover:bg-indigo-700">🛍️ Products</a></li>
                <li><a href="orders.php" class="block py-2 px-4 hover:bg-indigo-700">📦 Orders</a></li>
                <li><a href="pages.php" class="block py-2 px-4 hover:bg-indigo-700">📄 Pages</a></li>
                <li><a href="blog.php" class="block py-2 px-4 hover:bg-indigo-700 bg-indigo-900">📝 Blog</a></li>
                <li><a href="theme.php" class="block py-2 px-4 hover:bg-indigo-700">🎨 Theme</a></li>
                <li><a href="slider.php" class="block py-2 px-4 hover:bg-indigo-700">🖼️ Slider</a></li>
                <li><a href="banners.php" class="block py-2 px-4 hover:bg-indigo-700">🏷️ Small Banners</a></li>
                <li><a href="popups.php" class="block py-2 px-4 hover:bg-indigo-700">🪟 Popups</a></li>
                <li><a href="whatsapp.php" class="block py-2 px-4 hover:bg-indigo-700">💬 WhatsApp</a></li>
                <li><a href="payment-gateway.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateway</a></li>
                <li><a href="plan.php" class="block py-2 px-4 hover:bg-indigo-700">📅 Plan</a></li>
                <li><a href="verification.php" class="block py-2 px-4 hover:bg-yellow-700">✅ CNIC</a></li>
                <li><a href="profile.php" class="block py-2 px-4 hover:bg-indigo-700">👤 Profile</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 hover:bg-indigo-700">💬 Live Chat</a></li>
                <li><a href="timer.php" class="block py-2 px-4 hover:bg-indigo-700">⏱️ Timer</a></li>
                <li><a href="settings.php" class="block py-2 px-4 hover:bg-indigo-700">⚙️ Settings</a></li>
                <li><a href="logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold">Edit Blog Post</h1>
                <a href="blog.php" class="bg-gray-600 text-white px-4 py-2 rounded">← Back to Blog</a>
            </div>
            
            <?php if($error): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="mb-3">
                    <label class="block text-gray-700 mb-1">Post Title *</label>
                    <input type="text" name="title" required value="<?= htmlspecialchars($blog['title']) ?>" class="w-full border rounded px-3 py-2">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                    <div>
                        <label class="block text-gray-700 mb-1">Category</label>
                        <input type="text" name="category" value="<?= htmlspecialchars($blog['category']) ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-gray-700 mb-1">Tags (comma separated)</label>
                        <input type="text" name="tags" value="<?= htmlspecialchars($blog['tags']) ?>" class="w-full border rounded px-3 py-2">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="block text-gray-700 mb-1">Featured Image</label>
                    <?php if($blog['featured_image']): ?>
                        <div class="mb-2">
                            <img src="/assets/uploads/blogs/<?= $blog['featured_image'] ?>" class="h-32 w-auto border rounded">
                            <p class="text-xs text-gray-500 mt-1">Current image</p>
                        </div>
                    <?php endif; ?>
                    <input type="file" name="featured_image" accept="image/*" class="w-full border rounded px-3 py-2">
                    <p class="text-xs text-gray-500 mt-1">Leave empty to keep current image. Recommended size: 800x500px</p>
                </div>
                <div class="mb-3">
                    <label class="block text-gray-700 mb-1">Content *</label>
                    <textarea name="content" class="editor w-full"><?= htmlspecialchars($blog['content']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="inline-flex items-center">
                        <input type="checkbox" name="is_published" value="1" <?= $blog['is_published'] ? 'checked' : '' ?> class="mr-2">
                        <span class="text-gray-700">Publish this post (visible to public)</span>
                    </label>
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700">Update Post</button>
                    <a href="blog.php" class="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>