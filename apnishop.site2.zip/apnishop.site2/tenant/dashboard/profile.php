<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    $updateData = [
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $email,
        'phone' => $phone
    ];
    
    if(isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp'])) {
            $uploadDir = '../../assets/uploads/profiles/';
            ensureDirectory($uploadDir);
            $newName = time() . '_profile_' . $userId . '.' . $ext;
            move_uploaded_file($_FILES['profile_image']['tmp_name'], $uploadDir . $newName);
            if($user['profile_image'] && file_exists($uploadDir . $user['profile_image'])) unlink($uploadDir . $user['profile_image']);
            $updateData['profile_image'] = $newName;
        }
    }
    
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if(!empty($new_password)) {
        if(!verifyPassword($current_password, $user['password'])) {
            $error = 'Current password is incorrect.';
        } elseif(strlen($new_password) < 6) {
            $error = 'New password must be at least 6 characters.';
        } elseif($new_password !== $confirm_password) {
            $error = 'New passwords do not match.';
        } else {
            $updateData['password'] = hashPassword($new_password);
        }
    }
    
    if(!$error) {
        db_update("users", $updateData, "id = ?", [$userId]);
        $success = 'Profile updated successfully.';
        $user = getCurrentUser();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">My Profile</h1>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <div class="bg-white p-6 rounded shadow">
                <form method="POST" enctype="multipart/form-data">
                    <div class="grid grid-cols-2 gap-4">
                        <div><label>First Name *</label><input type="text" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Last Name</label><input type="text" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Business Name</label><input type="text" value="<?= htmlspecialchars($user['business_name']) ?>" disabled class="w-full border rounded px-3 py-2 bg-gray-100"></div>
                        <div><label>Subdomain</label><input type="text" value="<?= $user['subdomain'] ?>.apnishop.site" disabled class="w-full border rounded px-3 py-2 bg-gray-100"></div>
                        <div><label>Email *</label><input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Phone *</label><input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Profile Image</label><?php if($user['profile_image']): ?><img src="/assets/uploads/profiles/<?= $user['profile_image'] ?>" class="h-16 w-16 rounded-full object-cover mb-2"><?php endif; ?><input type="file" name="profile_image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                    </div>
                    <div class="border-t mt-6 pt-6"><h3 class="text-xl font-bold mb-4">Change Password</h3>
                        <div class="grid grid-cols-3 gap-4">
                            <div><label>Current Password</label><input type="password" name="current_password" class="w-full border rounded px-3 py-2"></div>
                            <div><label>New Password</label><input type="password" name="new_password" class="w-full border rounded px-3 py-2"></div>
                            <div><label>Confirm New Password</label><input type="password" name="confirm_password" class="w-full border rounded px-3 py-2"></div>
                        </div>
                    </div>
                    <button type="submit" class="mt-6 bg-indigo-600 text-white px-4 py-2 rounded">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>