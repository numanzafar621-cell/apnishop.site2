<?<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$pageId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$page = db_get_row("SELECT * FROM pages WHERE id = ? AND user_id = ?", [$pageId, $userId]);
if(!$page) { header('Location: pages.php'); exit; }

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $content = $_POST['content'];
    $show_in_menu = isset($_POST['show_in_menu']) ? 1 : 0;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    db_update("pages", [
        'title' => $title,
        'content' => $content,
        'show_in_menu' => $show_in_menu,
        'is_active' => $is_active
    ], "id = ? AND user_id = ?", [$pageId, $userId]);
    
    header('Location: pages.php?msg=updated');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Page</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js"></script>
    <script>tinymce.init({selector:'.editor', height:300, plugins:'image code', toolbar:'undo redo | formatselect | bold italic | image code'});</script>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Edit Page</h1>
            <form method="POST" class="bg-white p-6 rounded shadow">
                <div class="mb-3"><label>Page Title</label><input type="text" name="title" value="<?= htmlspecialchars($page['title']) ?>" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Content</label><textarea name="content" class="editor w-full"><?= htmlspecialchars($page['content']) ?></textarea></div>
                <div class="mb-3"><label><input type="checkbox" name="show_in_menu" value="1" <?= $page['show_in_menu'] ? 'checked' : '' ?>> Show in main menu</label></div>
                <div class="mb-3"><label><input type="checkbox" name="is_active" value="1" <?= $page['is_active'] ? 'checked' : '' ?>> Active</label></div>
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Update Page</button>
                <a href="pages.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>