<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];
$settings = getThemeSettings($userId);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $primary_color = trim($_POST['primary_color']);
    $secondary_color = trim($_POST['secondary_color']);
    $font_family = trim($_POST['font_family']);
    $footer_text = trim($_POST['footer_text']);
    $whatsapp_number = trim($_POST['whatsapp_number']);
    $whatsapp_position = trim($_POST['whatsapp_position']);
    $whatsapp_text = trim($_POST['whatsapp_text']);
    $ticker_text = trim($_POST['ticker_text']);
    $facebook_link = trim($_POST['facebook_link']);
    $instagram_link = trim($_POST['instagram_link']);
    $twitter_link = trim($_POST['twitter_link']);
    
    $logo = $settings['logo'];
    if(isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp','svg'])) {
            $uploadDir = '../../assets/uploads/';
            ensureDirectory($uploadDir);
            $newLogo = time() . '_logo.' . $ext;
            move_uploaded_file($_FILES['logo']['tmp_name'], $uploadDir . $newLogo);
            if($logo && file_exists($uploadDir . $logo)) unlink($uploadDir . $logo);
            $logo = $newLogo;
        }
    }
    
    $favicon = $settings['favicon'];
    if(isset($_FILES['favicon']) && $_FILES['favicon']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['favicon']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['ico','png','jpg'])) {
            $uploadDir = '../../assets/uploads/';
            ensureDirectory($uploadDir);
            $newFav = time() . '_favicon.' . $ext;
            move_uploaded_file($_FILES['favicon']['tmp_name'], $uploadDir . $newFav);
            if($favicon && file_exists($uploadDir . $favicon)) unlink($uploadDir . $favicon);
            $favicon = $newFav;
        }
    }
    
    db_update("theme_settings", [
        'primary_color' => $primary_color,
        'secondary_color' => $secondary_color,
        'font_family' => $font_family,
        'logo' => $logo,
        'favicon' => $favicon,
        'footer_text' => $footer_text,
        'whatsapp_number' => $whatsapp_number,
        'whatsapp_position' => $whatsapp_position,
        'whatsapp_text' => $whatsapp_text,
        'ticker_text' => $ticker_text,
        'facebook_link' => $facebook_link,
        'instagram_link' => $instagram_link,
        'twitter_link' => $twitter_link
    ], "user_id = ?", [$userId]);
    
    $success = "Theme settings saved.";
    $settings = getThemeSettings($userId);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Theme Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <style>.color-preview{width:40px;height:40px;border-radius:4px;}</style>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Theme & Color Settings</h1>
            <?php if(isset($success)) echo '<div class="bg-green-100 p-3 rounded mb-4">'.$success.'</div>'; ?>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="grid grid-cols-2 gap-4">
                    <div><label>Primary Color</label><input type="color" name="primary_color" value="<?= $settings['primary_color'] ?>" class="w-full"></div>
                    <div><label>Secondary Color</label><input type="color" name="secondary_color" value="<?= $settings['secondary_color'] ?>" class="w-full"></div>
                    <div><label>Font Family</label><select name="font_family" class="w-full border rounded px-3 py-2"><option <?= $settings['font_family']=='Poppins'?'selected':'' ?>>Poppins</option><option <?= $settings['font_family']=='Roboto'?'selected':'' ?>>Roboto</option><option <?= $settings['font_family']=='Open Sans'?'selected':'' ?>>Open Sans</option></select></div>
                    <div><label>Logo</label><?php if($settings['logo']): ?><img src="/assets/uploads/<?= $settings['logo'] ?>" class="h-12 mb-2"><?php endif; ?><input type="file" name="logo" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Favicon</label><?php if($settings['favicon']): ?><img src="/assets/uploads/<?= $settings['favicon'] ?>" class="h-8 mb-2"><?php endif; ?><input type="file" name="favicon" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                    <div><label>WhatsApp Number</label><input type="text" name="whatsapp_number" value="<?= htmlspecialchars($settings['whatsapp_number']) ?>" placeholder="923001234567" class="w-full border rounded px-3 py-2"></div>
                    <div><label>WhatsApp Button Text</label><input type="text" name="whatsapp_text" value="<?= htmlspecialchars($settings['whatsapp_text'] ?? 'Chat on WhatsApp') ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>WhatsApp Position</label><select name="whatsapp_position" class="w-full border rounded px-3 py-2"><option <?= $settings['whatsapp_position']=='bottom-right'?'selected':'' ?>>bottom-right</option><option <?= $settings['whatsapp_position']=='bottom-left'?'selected':'' ?>>bottom-left</option></select></div>
                    <div class="col-span-2"><label>Ticker Text (Marquee)</label><input type="text" name="ticker_text" value="<?= htmlspecialchars($settings['ticker_text']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div class="col-span-2"><label>Footer Copyright Text</label><textarea name="footer_text" rows="2" class="w-full border rounded px-3 py-2"><?= htmlspecialchars($settings['footer_text']) ?></textarea></div>
                    <div><label>Facebook Link</label><input type="url" name="facebook_link" value="<?= htmlspecialchars($settings['facebook_link']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Instagram Link</label><input type="url" name="instagram_link" value="<?= htmlspecialchars($settings['instagram_link']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Twitter Link</label><input type="url" name="twitter_link" value="<?= htmlspecialchars($settings['twitter_link']) ?>" class="w-full border rounded px-3 py-2"></div>
                </div>
                <div class="mt-6"><button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Save Settings</button></div>
            </form>
        </div>
    </div>
</body>
</html>