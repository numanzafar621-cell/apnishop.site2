<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cnic_number = trim($_POST['cnic_number']);
    $address = trim($_POST['address']);
    
    $cnic_front = $user['cnic_front'];
    if(isset($_FILES['cnic_front']) && $_FILES['cnic_front']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['cnic_front']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','pdf'])) {
            $uploadDir = '../../assets/uploads/cnic/';
            ensureDirectory($uploadDir);
            $newName = time() . '_cnic_front_' . $userId . '.' . $ext;
            move_uploaded_file($_FILES['cnic_front']['tmp_name'], $uploadDir . $newName);
            if($cnic_front && file_exists($uploadDir . $cnic_front)) unlink($uploadDir . $cnic_front);
            $cnic_front = $newName;
        } else {
            $error = 'CNIC front must be JPG, PNG or PDF.';
        }
    }
    
    $cnic_back = $user['cnic_back'];
    if(isset($_FILES['cnic_back']) && $_FILES['cnic_back']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['cnic_back']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','pdf'])) {
            $uploadDir = '../../assets/uploads/cnic/';
            ensureDirectory($uploadDir);
            $newName = time() . '_cnic_back_' . $userId . '.' . $ext;
            move_uploaded_file($_FILES['cnic_back']['tmp_name'], $uploadDir . $newName);
            if($cnic_back && file_exists($uploadDir . $cnic_back)) unlink($uploadDir . $cnic_back);
            $cnic_back = $newName;
        } else {
            $error = 'CNIC back must be JPG, PNG or PDF.';
        }
    }
    
    if(!$error) {
        db_update("users", [
            'cnic_number' => $cnic_number,
            'address' => $address,
            'cnic_front' => $cnic_front,
            'cnic_back' => $cnic_back
        ], "id = ?", [$userId]);
        $success = "Your CNIC information has been submitted. Admin will review and activate your account.";
        $user = getCurrentUser();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>CNIC Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">CNIC Verification</h1>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <?php if($user['is_active'] == 1): ?>
                <div class="bg-green-100 p-3 rounded mb-4">Your account is active. You can now use all features.</div>
            <?php elseif($user['cnic_front'] && $user['cnic_back'] && $user['is_active'] == 0): ?>
                <div class="bg-yellow-100 p-3 rounded mb-4">Your CNIC is submitted. Waiting for admin approval.</div>
            <?php endif; ?>
            <div class="bg-white p-6 rounded shadow">
                <p class="mb-4">Please upload clear images of your CNIC (front and back). Admin will verify and activate your account.</p>
                <form method="POST" enctype="multipart/form-data">
                    <div class="grid grid-cols-2 gap-4">
                        <div><label>CNIC Number</label><input type="text" name="cnic_number" value="<?= htmlspecialchars($user['cnic_number']) ?>" placeholder="12345-6789012-3" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Full Address</label><textarea name="address" rows="2" class="w-full border rounded px-3 py-2"><?= htmlspecialchars($user['address']) ?></textarea></div>
                        <div><label>CNIC Front</label><?php if($user['cnic_front']): ?><img src="/assets/uploads/cnic/<?= $user['cnic_front'] ?>" class="h-24 mb-2"><?php endif; ?><input type="file" name="cnic_front" accept="image/*,application/pdf" class="w-full border rounded px-3 py-2"></div>
                        <div><label>CNIC Back</label><?php if($user['cnic_back']): ?><img src="/assets/uploads/cnic/<?= $user['cnic_back'] ?>" class="h-24 mb-2"><?php endif; ?><input type="file" name="cnic_back" accept="image/*,application/pdf" class="w-full border rounded px-3 py-2"></div>
                    </div>
                    <button type="submit" class="mt-4 bg-indigo-600 text-white px-4 py-2 rounded">Submit Verification</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>