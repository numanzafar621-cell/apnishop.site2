<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$orderId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$order = db_get_row("SELECT * FROM orders WHERE id = ? AND user_id = ?", [$orderId, $userId]);
if(!$order) { header('Location: orders.php'); exit; }

$items = db_get_all("SELECT oi.*, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?", [$orderId]);
$total = 0;
foreach($items as $item) $total += $item['price'] * $item['quantity'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order Details #<?= $order['order_number'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Order #<?= $order['order_number'] ?></h1>
            <div class="bg-white p-6 rounded shadow mb-6">
                <h2 class="text-xl font-bold mb-3">Customer Information</h2>
                <p><strong>Name:</strong> <?= htmlspecialchars($order['customer_name']) ?></p>
                <p><strong>Email:</strong> <?= $order['customer_email'] ?></p>
                <p><strong>Phone:</strong> <?= $order['customer_phone'] ?></p>
                <p><strong>Address:</strong> <?= nl2br(htmlspecialchars($order['customer_address'])) ?></p>
                <p><strong>Payment Method:</strong> <?= $order['payment_method'] ?></p>
                <p><strong>Payment Status:</strong> <?= ucfirst($order['payment_status']) ?></p>
                <p><strong>Order Status:</strong> <?= ucfirst($order['status']) ?></p>
                <p><strong>Date:</strong> <?= date('d-m-Y h:i A', strtotime($order['created_at'])) ?></p>
            </div>
            <div class="bg-white p-6 rounded shadow">
                <h2 class="text-xl font-bold mb-3">Products</h2>
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr><th>Product</th><th>Quantity</th><th>Price</th><th>Subtotal</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($items as $item): $sub = $item['price'] * $item['quantity']; ?>
                        <tr class="border-t">
                            <td class="p-2"><?= htmlspecialchars($item['name']) ?></td>
                            <td class="p-2"><?= $item['quantity'] ?></td>
                            <td class="p-2"><?= formatPrice($item['price']) ?></td>
                            <td class="p-2"><?= formatPrice($sub) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr class="border-t font-bold"><td colspan="3" class="p-2 text-right">Total:</td><td class="p-2"><?= formatPrice($total) ?></td></tr>
                    </tbody>
                </table>
                <div class="mt-4">
                    <button onclick="window.print()" class="bg-gray-600 text-white px-4 py-2 rounded">Print Invoice</button>
                    <a href="orders.php" class="bg-indigo-600 text-white px-4 py-2 rounded ml-2">Back to Orders</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>