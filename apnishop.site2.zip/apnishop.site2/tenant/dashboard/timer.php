<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$products = db_get_all("SELECT id, name, has_timer, timer_end FROM products WHERE user_id = ? AND is_active = 1 ORDER BY id DESC", [$userId]);

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id'])) {
    $productId = intval($_POST['product_id']);
    $has_timer = isset($_POST['has_timer']) ? 1 : 0;
    $timer_end = null;
    if($has_timer && !empty($_POST['timer_end'])) {
        $timer_end = date('Y-m-d H:i:s', strtotime($_POST['timer_end']));
    }
    db_update("products", ['has_timer' => $has_timer, 'timer_end' => $timer_end], "id = ? AND user_id = ?", [$productId, $userId]);
    header('Location: timer.php?msg=updated');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Product Timer Management</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Product Countdown Timer</h1>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'updated'): ?>
                <div class="bg-green-100 p-3 rounded mb-4">Timer updated successfully.</div>
            <?php endif; ?>
            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full">
                    <thead class="bg-gray-800 text-white">
                        <tr><th class="p-3">Product Name</th><th>Enable Timer</th><th>End Date/Time</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($products as $p): ?>
                        <form method="POST">
                            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                            <tr class="border-t">
                                <td class="p-3"><?= htmlspecialchars($p['name']) ?></td>
                                <td class="p-3"><input type="checkbox" name="has_timer" value="1" <?= $p['has_timer'] ? 'checked' : '' ?>></td>
                                <td class="p-3"><input type="datetime-local" name="timer_end" value="<?= $p['timer_end'] ? date('Y-m-d\TH:i', strtotime($p['timer_end'])) : '' ?>" class="border rounded px-2 py-1"></td>
                                <td class="p-3"><button type="submit" class="bg-indigo-600 text-white px-3 py-1 rounded">Save</button></td>
                            </tr>
                        </form>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-6 bg-yellow-50 p-4 rounded">
                <p class="text-sm"><strong>Note:</strong> Timer will automatically display on the product page. The product will show countdown until the specified end time.</p>
            </div>
        </div>
    </div>
</body>
</html>