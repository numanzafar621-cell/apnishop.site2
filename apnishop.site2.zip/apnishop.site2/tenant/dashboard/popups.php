<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

// Add popup
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);
    $show_on_load = isset($_POST['show_on_load']) ? 1 : 0;
    $show_on_exit = isset($_POST['show_on_exit']) ? 1 : 0;
    $delay_seconds = intval($_POST['delay_seconds']);
    if($delay_seconds < 0) $delay_seconds = 0;
    
    $image = null;
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp'])) {
            $uploadDir = '../../assets/uploads/popups/';
            ensureDirectory($uploadDir);
            $image = time() . '_popup_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $image);
        }
    }
    
    db_insert('popups', [
        'user_id' => $userId,
        'title' => $title,
        'message' => $message,
        'image' => $image,
        'show_on_load' => $show_on_load,
        'show_on_exit' => $show_on_exit,
        'delay_seconds' => $delay_seconds,
        'is_active' => 1
    ]);
    header('Location: popups.php?msg=added');
    exit;
}

// Edit popup
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'edit') {
    $id = intval($_POST['id']);
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);
    $show_on_load = isset($_POST['show_on_load']) ? 1 : 0;
    $show_on_exit = isset($_POST['show_on_exit']) ? 1 : 0;
    $delay_seconds = intval($_POST['delay_seconds']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    $updateData = [
        'title' => $title,
        'message' => $message,
        'show_on_load' => $show_on_load,
        'show_on_exit' => $show_on_exit,
        'delay_seconds' => $delay_seconds,
        'is_active' => $is_active
    ];
    
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp'])) {
            $uploadDir = '../../assets/uploads/popups/';
            ensureDirectory($uploadDir);
            $old = db_get_row("SELECT image FROM popups WHERE id = ? AND user_id = ?", [$id, $userId]);
            if($old && $old['image'] && file_exists($uploadDir . $old['image'])) unlink($uploadDir . $old['image']);
            $newName = time() . '_popup_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newName);
            $updateData['image'] = $newName;
        }
    }
    
    db_update("popups", $updateData, "id = ? AND user_id = ?", [$id, $userId]);
    header('Location: popups.php?msg=updated');
    exit;
}

// Delete popup
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = $_GET['delete'];
    $popup = db_get_row("SELECT image FROM popups WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($popup && $popup['image']) {
        $filePath = '../../assets/uploads/popups/' . $popup['image'];
        if(file_exists($filePath)) unlink($filePath);
    }
    db_delete("popups", "id = ? AND user_id = ?", [$id, $userId]);
    header('Location: popups.php?msg=deleted');
    exit;
}

// Toggle active
if(isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $popup = db_get_row("SELECT is_active FROM popups WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($popup) {
        $new = $popup['is_active'] ? 0 : 1;
        db_update("popups", ['is_active' => $new], "id = ?", [$id]);
    }
    header('Location: popups.php');
    exit;
}

$popups = db_get_all("SELECT * FROM popups WHERE user_id = ? ORDER BY id DESC", [$userId]);
$editPopup = null;
if(isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $editId = $_GET['edit'];
    $editPopup = db_get_row("SELECT * FROM popups WHERE id = ? AND user_id = ?", [$editId, $userId]);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Popups Management</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Popups Management</h1>
            <?php if(isset($_GET['msg'])): ?>
                <div class="bg-green-100 p-3 rounded mb-4">Popup <?= $_GET['msg'] ?>.</div>
            <?php endif; ?>
            <div class="bg-white p-6 rounded shadow mb-8">
                <h2 class="text-xl font-bold mb-4">Add New Popup</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="add">
                    <div class="grid grid-cols-2 gap-4">
                        <div><label>Title *</label><input type="text" name="title" required class="w-full border rounded px-3 py-2"></div>
                        <div><label>Delay (seconds)</label><input type="number" name="delay_seconds" value="0" class="w-full border rounded px-3 py-2"></div>
                        <div class="col-span-2"><label>Message *</label><textarea name="message" rows="3" required class="w-full border rounded px-3 py-2"></textarea></div>
                        <div><label>Image (optional)</label><input type="file" name="image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Display Conditions</label><label class="inline-flex items-center mr-4"><input type="checkbox" name="show_on_load" value="1" checked> On page load</label><label class="inline-flex items-center"><input type="checkbox" name="show_on_exit" value="1"> On exit</label></div>
                    </div>
                    <button type="submit" class="mt-4 bg-indigo-600 text-white px-4 py-2 rounded">Add Popup</button>
                </form>
            </div>
            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full"><thead class="bg-gray-800 text-white"><tr><th class="p-3">Title</th><th>Message</th><th>Conditions</th><th>Status</th><th>Action</th></tr></thead>
                <tbody><?php foreach($popups as $p): ?><tr class="border-t"><td class="p-3"><?= htmlspecialchars($p['title']) ?></td><td class="p-3"><?= htmlspecialchars(substr($p['message'],0,50)) ?>...</td><td class="p-3"><?= $p['show_on_load']?'Load ':'' ?><?= $p['show_on_exit']?'Exit ':'' ?>(<?= $p['delay_seconds'] ?>s)</td><td class="p-3"><?= $p['is_active']?'Active':'Inactive' ?></td><td class="p-3"><a href="?edit=<?= $p['id'] ?>" class="text-blue-600 mr-2">Edit</a><a href="?toggle=<?= $p['id'] ?>" class="text-green-600 mr-2">Toggle</a><a href="?delete=<?= $p['id'] ?>" class="text-red-600" onclick="return confirm('Delete popup?')">Delete</a></td></tr><?php endforeach; ?></tbody>
                </table>
            </div>
        </div>
    </div>
    <?php if($editPopup): ?>
    <div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"><div class="bg-white p-6 rounded max-w-lg w-full"><h3 class="text-xl font-bold mb-4">Edit Popup</h3><form method="POST" enctype="multipart/form-data"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?= $editPopup['id'] ?>"><div class="mb-2"><label>Title</label><input type="text" name="title" value="<?= htmlspecialchars($editPopup['title']) ?>" class="w-full border rounded px-3 py-2"></div><div class="mb-2"><label>Message</label><textarea name="message" rows="3" class="w-full border rounded px-3 py-2"><?= htmlspecialchars($editPopup['message']) ?></textarea></div><div class="mb-2"><label>Delay (seconds)</label><input type="number" name="delay_seconds" value="<?= $editPopup['delay_seconds'] ?>" class="w-full border rounded px-3 py-2"></div><div class="mb-2"><?php if($editPopup['image']): ?><img src="/assets/uploads/popups/<?= $editPopup['image'] ?>" class="h-20 mb-2"><?php endif; ?><input type="file" name="image" accept="image/*" class="w-full border rounded px-3 py-2"></div><div><label><input type="checkbox" name="show_on_load" value="1" <?= $editPopup['show_on_load']?'checked':'' ?>> On load</label><label class="ml-4"><input type="checkbox" name="show_on_exit" value="1" <?= $editPopup['show_on_exit']?'checked':'' ?>> On exit</label></div><div class="mt-2"><label><input type="checkbox" name="is_active" value="1" <?= $editPopup['is_active']?'checked':'' ?>> Active</label></div><div class="flex gap-2 mt-4"><button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Save</button><a href="popups.php" class="bg-gray-500 text-white px-4 py-2 rounded">Cancel</a></div></form></div></div>
    <?php endif; ?>
</body>
</html>