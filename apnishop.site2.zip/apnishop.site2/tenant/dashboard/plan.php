<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$currentPlan = db_get_row("SELECT * FROM plans WHERE id = ?", [$user['plan_id']]);
$allPlans = db_get_all("SELECT * FROM plans WHERE is_active = 1 ORDER BY price ASC");
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['plan_id'])) {
    $planId = intval($_POST['plan_id']);
    $plan = db_get_row("SELECT * FROM plans WHERE id = ?", [$planId]);
    if($plan && isset($_FILES['screenshot']) && $_FILES['screenshot']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['screenshot']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png'])) {
            $uploadDir = '../../assets/uploads/payments/';
            ensureDirectory($uploadDir);
            $screenshot = time() . '_payment_' . $userId . '.' . $ext;
            move_uploaded_file($_FILES['screenshot']['tmp_name'], $uploadDir . $screenshot);
            db_insert('payment_requests', [
                'user_id' => $userId,
                'plan_id' => $planId,
                'screenshot' => $screenshot,
                'status' => 'pending'
            ]);
            $success = "Payment request submitted. Admin will activate your plan soon.";
        } else {
            $error = "Only JPG, PNG images allowed.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Plan - Seller Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">My Plan</h1>
            <div class="bg-white p-6 rounded shadow mb-8">
                <h2 class="text-xl font-bold mb-3">Current Plan</h2>
                <p><strong>Plan:</strong> <?= $currentPlan ? $currentPlan['name'] : 'Free' ?></p>
                <p><strong>Expires:</strong> <?= $user['plan_expiry'] ? date('d-m-Y', strtotime($user['plan_expiry'])) : 'Lifetime' ?></p>
                <?php if($user['plan_expiry'] && strtotime($user['plan_expiry']) < time()): ?>
                    <p class="text-red-600 font-bold">Your plan has expired. Please renew.</p>
                <?php elseif($user['plan_expiry'] && strtotime($user['plan_expiry']) < strtotime('+7 days')): ?>
                    <p class="text-yellow-600">Your plan expires soon. Renew now.</p>
                <?php endif; ?>
            </div>
            <h2 class="text-2xl font-bold mb-4">Available Plans</h2>
            <div class="grid md:grid-cols-3 gap-6">
                <?php foreach($allPlans as $plan): ?>
                <div class="bg-white p-6 rounded shadow">
                    <h3 class="text-xl font-bold"><?= $plan['name'] ?></h3>
                    <p class="text-2xl text-indigo-600"><?= formatPrice($plan['price']) ?></p>
                    <p class="text-gray-600">Duration: <?= $plan['duration_days'] ?> days</p>
                    <p class="text-sm mt-2"><?= nl2br($plan['features']) ?></p>
                    <form method="POST" enctype="multipart/form-data" class="mt-4">
                        <input type="hidden" name="plan_id" value="<?= $plan['id'] ?>">
                        <div class="mb-2">
                            <label class="block text-sm">Payment Screenshot (Bank/Easypaisa/JazzCash)</label>
                            <input type="file" name="screenshot" accept="image/*" required class="w-full border rounded px-2 py-1 text-sm">
                        </div>
                        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded w-full">Buy This Plan</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if(isset($success)): ?><div class="mt-6 bg-green-100 p-3 rounded"><?= $success ?></div><?php endif; ?>
        </div>
    </div>
</body>
</html>