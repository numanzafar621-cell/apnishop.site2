<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

// Delete banner
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = $_GET['delete'];
    $banner = db_get_row("SELECT image FROM small_banners WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($banner && $banner['image']) {
        $filePath = '../../assets/uploads/banners/' . $banner['image'];
        if(file_exists($filePath)) unlink($filePath);
    }
    db_delete("small_banners", "id = ? AND user_id = ?", [$id, $userId]);
    header('Location: banners.php?msg=deleted');
    exit;
}

// Toggle active status
if(isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $banner = db_get_row("SELECT is_active FROM small_banners WHERE id = ? AND user_id = ?", [$id, $userId]);
    if($banner) {
        $new = $banner['is_active'] ? 0 : 1;
        db_update("small_banners", ['is_active' => $new], "id = ?", [$id]);
    }
    header('Location: banners.php');
    exit;
}

$banners = db_get_all("SELECT * FROM small_banners WHERE user_id = ? ORDER BY order_position ASC", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Small Banners - Seller Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold">Small Banners</h1>
                <a href="add-banner.php" class="bg-indigo-600 text-white px-4 py-2 rounded">+ Add New Banner</a>
            </div>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>
                <div class="bg-green-100 p-3 rounded mb-4">Banner deleted.</div>
            <?php endif; ?>
            <?php if(empty($banners)): ?>
                <div class="bg-white p-8 rounded shadow text-center">No banners yet. <a href="add-banner.php" class="text-indigo-600">Add your first banner</a></div>
            <?php else: ?>
            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full">
                    <thead class="bg-gray-800 text-white">
                        <tr><th class="p-3">Image</th><th>Title</th><th>Link</th><th>Order</th><th>Status</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($banners as $b): ?>
                        <tr class="border-t">
                            <td class="p-3"><img src="/assets/uploads/banners/<?= $b['image'] ?>" class="h-12 w-auto"></td>
                            <td class="p-3"><?= htmlspecialchars($b['title']) ?></td>
                            <td class="p-3"><a href="<?= $b['link'] ?>" target="_blank" class="text-blue-600">Link</a></td>
                            <td class="p-3"><?= $b['order_position'] ?></td>
                            <td class="p-3"><?= $b['is_active'] ? '✅ Active' : '❌ Inactive' ?></td>
                            <td class="p-3">
                                <a href="edit-banner.php?id=<?= $b['id'] ?>" class="text-blue-600 mr-2">✏️ Edit</a>
                                <a href="?toggle=<?= $b['id'] ?>" class="text-green-600 mr-2">🔄 Toggle</a>
                                <a href="?delete=<?= $b['id'] ?>" class="text-red-600" onclick="return confirm('Delete this banner?')">🗑️ Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>