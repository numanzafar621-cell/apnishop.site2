<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $content = $_POST['content'];
    $show_in_menu = isset($_POST['show_in_menu']) ? 1 : 0;
    $slug = createSlug($title);
    
    $existing = db_get_value("SELECT id FROM pages WHERE user_id = ? AND slug = ?", [$userId, $slug]);
    if($existing) $slug = $slug . '-' . time();
    
    db_insert('pages', [
        'user_id' => $userId,
        'title' => $title,
        'slug' => $slug,
        'content' => $content,
        'show_in_menu' => $show_in_menu,
        'is_active' => 1
    ]);
    header('Location: pages.php?msg=added');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Page</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js"></script>
    <script>tinymce.init({selector:'.editor', height:300, plugins:'image code', toolbar:'undo redo | formatselect | bold italic | image code'});</script>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Add New Page</h1>
            <form method="POST" class="bg-white p-6 rounded shadow">
                <div class="mb-3"><label>Page Title *</label><input type="text" name="title" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Content (HTML)</label><textarea name="content" class="editor w-full"></textarea></div>
                <div class="mb-3"><label><input type="checkbox" name="show_in_menu" value="1"> Show in main menu</label></div>
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Add Page</button>
                <a href="pages.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>