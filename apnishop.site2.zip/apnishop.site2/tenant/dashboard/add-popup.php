<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);
    $show_on_load = isset($_POST['show_on_load']) ? 1 : 0;
    $show_on_exit = isset($_POST['show_on_exit']) ? 1 : 0;
    $delay_seconds = intval($_POST['delay_seconds']);
    if($delay_seconds < 0) $delay_seconds = 0;
    
    $image = null;
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp'])) {
            $uploadDir = '../../assets/uploads/popups/';
            ensureDirectory($uploadDir);
            $image = time() . '_popup_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $image);
        }
    }
    
    db_insert('popups', [
        'user_id' => $userId,
        'title' => $title,
        'message' => $message,
        'image' => $image,
        'show_on_load' => $show_on_load,
        'show_on_exit' => $show_on_exit,
        'delay_seconds' => $delay_seconds,
        'is_active' => 1
    ]);
    header('Location: popups.php?msg=added');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Popup</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Add New Popup</h1>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="mb-3"><label>Title *</label><input type="text" name="title" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Message *</label><textarea name="message" rows="3" required class="w-full border rounded px-3 py-2"></textarea></div>
                <div class="grid grid-cols-2 gap-4 mb-3">
                    <div><label>Delay (seconds)</label><input type="number" name="delay_seconds" value="0" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Image (optional)</label><input type="file" name="image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                </div>
                <div class="mb-3">
                    <label><input type="checkbox" name="show_on_load" value="1" checked> Show on page load</label><br>
                    <label><input type="checkbox" name="show_on_exit" value="1"> Show on exit</label>
                </div>
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Add Popup</button>
                <a href="popups.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>