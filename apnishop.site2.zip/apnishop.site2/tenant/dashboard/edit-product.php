<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$productId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$product = db_get_row("SELECT * FROM products WHERE id = ? AND user_id = ?", [$productId, $userId]);
if(!$product) { header('Location: products.php'); exit; }

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $compare_price = !empty($_POST['compare_price']) ? floatval($_POST['compare_price']) : null;
    $stock = intval($_POST['stock']);
    $category = trim($_POST['category']);
    $banner_link = trim($_POST['banner_link']);
    
    $updateData = [
        'name' => $name,
        'description' => $description,
        'price' => $price,
        'compare_price' => $compare_price,
        'stock' => $stock,
        'category' => $category,
        'banner_link' => $banner_link
    ];
    
    // Update main image
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','webp'];
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $uploadDir = '../../assets/uploads/products/';
            ensureDirectory($uploadDir);
            $newImage = time() . '_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newImage);
            if($product['image'] && file_exists($uploadDir . $product['image'])) unlink($uploadDir . $product['image']);
            $updateData['image'] = $newImage;
        }
    }
    
    // Update banner image
    if(isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','webp'];
        $ext = strtolower(pathinfo($_FILES['banner_image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $uploadDir = '../../assets/uploads/products/banners/';
            ensureDirectory($uploadDir);
            $newBanner = time() . '_banner_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['banner_image']['tmp_name'], $uploadDir . $newBanner);
            if($product['banner_image'] && file_exists($uploadDir . $product['banner_image'])) unlink($uploadDir . $product['banner_image']);
            $updateData['banner_image'] = $newBanner;
        }
    }
    
    db_update("products", $updateData, "id = ?", [$productId]);
    header('Location: products.php?msg=updated');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Edit Product</h1>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="grid grid-cols-2 gap-4">
                    <div><label>Product Name</label><input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Price (Rs.)</label><input type="number" step="0.01" name="price" value="<?= $product['price'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Compare Price</label><input type="number" step="0.01" name="compare_price" value="<?= $product['compare_price'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Stock</label><input type="number" name="stock" value="<?= $product['stock'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Category</label><input type="text" name="category" value="<?= htmlspecialchars($product['category']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Current Image</label><img src="/assets/uploads/products/<?= $product['image'] ?>" class="h-20"><input type="file" name="image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                    <div class="col-span-2"><label>Description</label><textarea name="description" rows="5" class="w-full border rounded px-3 py-2"><?= htmlspecialchars($product['description']) ?></textarea></div>
                    <div class="col-span-2 border-t pt-4"><h3 class="font-bold">Product Bottom Banner</h3></div>
                    <div><?php if($product['banner_image']): ?><img src="/assets/uploads/products/banners/<?= $product['banner_image'] ?>" class="h-20"><?php endif; ?><input type="file" name="banner_image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Banner Link</label><input type="url" name="banner_link" value="<?= htmlspecialchars($product['banner_link']) ?>" class="w-full border rounded px-3 py-2"></div>
                </div>
                <div class="mt-6"><button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Update Product</button><a href="products.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a></div>
            </form>
        </div>
    </div>
</body>
</html>