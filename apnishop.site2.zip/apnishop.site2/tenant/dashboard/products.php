<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

// Delete product
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $productId = $_GET['delete'];
    $product = db_get_row("SELECT image, banner_image FROM products WHERE id = ? AND user_id = ?", [$productId, $userId]);
    if($product) {
        // Delete main image
        if($product['image'] && file_exists('../../assets/uploads/products/' . $product['image'])) {
            unlink('../../assets/uploads/products/' . $product['image']);
        }
        // Delete banner image
        if($product['banner_image'] && file_exists('../../assets/uploads/products/banners/' . $product['banner_image'])) {
            unlink('../../assets/uploads/products/banners/' . $product['banner_image']);
        }
    }
    db_delete("products", "id = ? AND user_id = ?", [$productId, $userId]);
    header('Location: products.php?msg=deleted');
    exit;
}

// Toggle product active status (if admin approved, seller can toggle? Usually admin controls this)
// But for seller, they can only see status, not change it. Admin controls is_active.

// Get all products for this seller
$products = db_get_all("SELECT * FROM products WHERE user_id = ? ORDER BY id DESC", [$userId]);

// Get counts
$totalProducts = count($products);
$activeProducts = db_get_value("SELECT COUNT(*) FROM products WHERE user_id = ? AND is_active = 1", [$userId]);
$pendingProducts = db_get_value("SELECT COUNT(*) FROM products WHERE user_id = ? AND is_active = 0", [$userId]);
$outOfStock = db_get_value("SELECT COUNT(*) FROM products WHERE user_id = ? AND stock <= 0", [$userId]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Products - Seller Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/tenant-dashboard.css">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold border-b border-indigo-700">My Store</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700">📊 Dashboard</a></li>
                <li><a href="products.php" class="block py-2 px-4 hover:bg-indigo-700 bg-indigo-900">🛍️ Products</a></li>
                <li><a href="orders.php" class="block py-2 px-4 hover:bg-indigo-700">📦 Orders</a></li>
                <li><a href="pages.php" class="block py-2 px-4 hover:bg-indigo-700">📄 Pages</a></li>
                <li><a href="blog.php" class="block py-2 px-4 hover:bg-indigo-700">📝 Blog</a></li>
                <li><a href="theme.php" class="block py-2 px-4 hover:bg-indigo-700">🎨 Theme</a></li>
                <li><a href="slider.php" class="block py-2 px-4 hover:bg-indigo-700">🖼️ Slider</a></li>
                <li><a href="banners.php" class="block py-2 px-4 hover:bg-indigo-700">🏷️ Small Banners</a></li>
                <li><a href="popups.php" class="block py-2 px-4 hover:bg-indigo-700">🪟 Popups</a></li>
                <li><a href="whatsapp.php" class="block py-2 px-4 hover:bg-indigo-700">💬 WhatsApp</a></li>
                <li><a href="payment-gateway.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateway</a></li>
                <li><a href="plan.php" class="block py-2 px-4 hover:bg-indigo-700">📅 Plan</a></li>
                <li><a href="verification.php" class="block py-2 px-4 hover:bg-yellow-700">✅ CNIC</a></li>
                <li><a href="profile.php" class="block py-2 px-4 hover:bg-indigo-700">👤 Profile</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 hover:bg-indigo-700">💬 Live Chat</a></li>
                <li><a href="timer.php" class="block py-2 px-4 hover:bg-indigo-700">⏱️ Timer</a></li>
                <li><a href="settings.php" class="block py-2 px-4 hover:bg-indigo-700">⚙️ Settings</a></li>
                <li><a href="logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 overflow-y-auto p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold">My Products</h1>
                <a href="add-product.php" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">+ Add New Product</a>
            </div>
            
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div class="bg-white p-4 rounded shadow text-center">
                    <div class="text-gray-500 text-sm">Total Products</div>
                    <div class="text-2xl font-bold"><?= $totalProducts ?></div>
                </div>
                <div class="bg-white p-4 rounded shadow text-center">
                    <div class="text-gray-500 text-sm">Active Products</div>
                    <div class="text-2xl font-bold text-green-600"><?= $activeProducts ?></div>
                </div>
                <div class="bg-white p-4 rounded shadow text-center">
                    <div class="text-gray-500 text-sm">Pending Approval</div>
                    <div class="text-2xl font-bold text-yellow-600"><?= $pendingProducts ?></div>
                </div>
                <div class="bg-white p-4 rounded shadow text-center">
                    <div class="text-gray-500 text-sm">Out of Stock</div>
                    <div class="text-2xl font-bold text-red-600"><?= $outOfStock ?></div>
                </div>
            </div>
            
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'added'): ?>
                <div class="bg-green-100 text-green-700 p-3 rounded mb-4">Product added successfully! It will appear after admin approval.</div>
            <?php endif; ?>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'updated'): ?>
                <div class="bg-green-100 text-green-700 p-3 rounded mb-4">Product updated successfully!</div>
            <?php endif; ?>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>
                <div class="bg-green-100 text-green-700 p-3 rounded mb-4">Product deleted successfully.</div>
            <?php endif; ?>
            
            <?php if(empty($products)): ?>
                <div class="bg-white p-8 rounded-lg shadow text-center text-gray-500">
                    <div class="text-5xl mb-3">📦</div>
                    <p>You haven't added any products yet.</p>
                    <a href="add-product.php" class="text-indigo-600 mt-2 inline-block">Add your first product →</a>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead class="bg-gray-800 text-white">
                                <tr>
                                    <th class="px-4 py-3 text-left">Image</th>
                                    <th class="px-4 py-3 text-left">Name</th>
                                    <th class="px-4 py-3 text-left">Price</th>
                                    <th class="px-4 py-3 text-left">Stock</th>
                                    <th class="px-4 py-3 text-left">Status</th>
                                    <th class="px-4 py-3 text-left">Date</th>
                                    <th class="px-4 py-3 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($products as $p): ?>
                                <tr class="border-t hover:bg-gray-50">
                                    <td class="px-4 py-3">
                                        <img src="/assets/uploads/products/<?= $p['image'] ?>" class="h-12 w-12 object-cover rounded">
                                    </td>
                                    <td class="px-4 py-3">
                                        <div class="font-medium"><?= htmlspecialchars($p['name']) ?></div>
                                        <div class="text-xs text-gray-500"><?= htmlspecialchars($p['category'] ?: 'Uncategorized') ?></div>
                                    </td>
                                    <td class="px-4 py-3"><?= formatPrice($p['price']) ?></td>
                                    <td class="px-4 py-3">
                                        <?php if($p['stock'] <= 0): ?>
                                            <span class="text-red-600 font-medium">Out of stock</span>
                                        <?php elseif($p['stock'] < 10): ?>
                                            <span class="text-yellow-600"><?= $p['stock'] ?> left</span>
                                        <?php else: ?>
                                            <span class="text-green-600"><?= $p['stock'] ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3">
                                        <?php if($p['is_active']): ?>
                                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Active</span>
                                        <?php else: ?>
                                            <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">Pending Approval</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3 text-sm"><?= date('d-m-Y', strtotime($p['created_at'])) ?></td>
                                    <td class="px-4 py-3 text-center">
                                        <a href="edit-product.php?id=<?= $p['id'] ?>" class="text-blue-600 hover:text-blue-800 mr-3" title="Edit">
                                            ✏️
                                        </a>
                                        <a href="javascript:void(0)" onclick="confirmDelete(<?= $p['id'] ?>, '<?= addslashes($p['name']) ?>')" class="text-red-600 hover:text-red-800" title="Delete">
                                            🗑️
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function confirmDelete(productId, productName) {
            if(confirm('Are you sure you want to delete "' + productName + '"? This action cannot be undone.')) {
                window.location.href = '?delete=' + productId;
            }
        }
    </script>
</body>
</html>