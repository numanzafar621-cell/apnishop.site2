<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $content = $_POST['content'];
    $category = trim($_POST['category']);
    $tags = trim($_POST['tags']);
    $is_published = isset($_POST['is_published']) ? 1 : 0;
    $slug = createSlug($title);
    
    $existing = db_get_value("SELECT id FROM blogs WHERE user_id = ? AND slug = ?", [$userId, $slug]);
    if($existing) $slug = $slug . '-' . time();
    
    $featured_image = null;
    if(isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['featured_image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp'])) {
            $uploadDir = '../../assets/uploads/blogs/';
            ensureDirectory($uploadDir);
            $featured_image = time() . '_blog_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['featured_image']['tmp_name'], $uploadDir . $featured_image);
        } else {
            $error = 'Only JPG, PNG, WEBP images allowed.';
        }
    }
    
    if(!$error) {
        db_insert('blogs', [
            'user_id' => $userId,
            'title' => $title,
            'slug' => $slug,
            'content' => $content,
            'featured_image' => $featured_image,
            'category' => $category,
            'tags' => $tags,
            'is_published' => $is_published
        ]);
        header('Location: blog.php?msg=added');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Blog Post</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js"></script>
    <script>tinymce.init({selector:'.editor', height:400, plugins:'image code', toolbar:'undo redo | formatselect | bold italic | image code'});</script>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Add New Blog Post</h1>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="mb-3"><label>Title *</label><input type="text" name="title" required class="w-full border rounded px-3 py-2"></div>
                <div class="grid grid-cols-2 gap-4 mb-3"><div><label>Category</label><input type="text" name="category" class="w-full border rounded px-3 py-2"></div><div><label>Tags (comma separated)</label><input type="text" name="tags" class="w-full border rounded px-3 py-2"></div></div>
                <div class="mb-3"><label>Featured Image</label><input type="file" name="featured_image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Content</label><textarea name="content" class="editor w-full"></textarea></div>
                <div class="mb-3"><label><input type="checkbox" name="is_published" value="1"> Publish now</label></div>
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Add Post</button>
                <a href="blog.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>