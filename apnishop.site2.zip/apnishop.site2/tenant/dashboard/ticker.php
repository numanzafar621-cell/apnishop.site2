<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];
$settings = getThemeSettings($userId);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ticker_text = trim($_POST['ticker_text']);
    db_update("theme_settings", ['ticker_text' => $ticker_text], "user_id = ?", [$userId]);
    $success = "Ticker text updated.";
    $settings = getThemeSettings($userId);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ticker (Marquee) Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Ticker (Marquee) Text</h1>
            <?php if(isset($success)): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <div class="bg-white p-6 rounded shadow">
                <form method="POST">
                    <div class="mb-3"><label>Ticker Text (will scroll on top of your website)</label>
                    <input type="text" name="ticker_text" value="<?= htmlspecialchars($settings['ticker_text'] ?? '🔥 Special Offer! Free Shipping 🔥') ?>" class="w-full border rounded px-3 py-2">
                    <p class="text-sm text-gray-500 mt-1">Example: 🔥 20% off on all products! Limited time offer 🔥</p></div>
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Save Ticker</button>
                </form>
                <div class="mt-6 p-3 bg-gray-100 rounded">
                    <p class="font-bold">Preview:</p>
                    <div class="bg-yellow-100 py-2 overflow-hidden whitespace-nowrap">
                        <span class="inline-block animate-marquee"><?= htmlspecialchars($settings['ticker_text'] ?? '🔥 Special Offer! Free Shipping 🔥') ?></span>
                    </div>
                    <style>@keyframes marquee{0%{transform:translateX(100%)}100%{transform:translateX(-100%)}}.animate-marquee{animation:marquee 20s linear infinite;display:inline-block;white-space:nowrap;}</style>
                </div>
            </div>
        </div>
    </div>
</body>
</html>