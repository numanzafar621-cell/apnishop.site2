<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$theme = getThemeSettings($userId);
$store = db_get_row("SELECT * FROM store_settings WHERE user_id = ?", [$userId]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $contact_email = trim($_POST['contact_email']);
    $contact_phone = trim($_POST['contact_phone']);
    $contact_address = trim($_POST['contact_address']);
    $google_maps_link = trim($_POST['google_maps_link']);
    $footer_text = trim($_POST['footer_text']);
    $facebook_link = trim($_POST['facebook_link']);
    $instagram_link = trim($_POST['instagram_link']);
    $twitter_link = trim($_POST['twitter_link']);
    
    db_update("theme_settings", [
        'footer_text' => $footer_text,
        'facebook_link' => $facebook_link,
        'instagram_link' => $instagram_link,
        'twitter_link' => $twitter_link
    ], "user_id = ?", [$userId]);
    
    if($store) {
        db_update("store_settings", [
            'contact_email' => $contact_email,
            'contact_phone' => $contact_phone,
            'contact_address' => $contact_address,
            'google_maps_link' => $google_maps_link
        ], "user_id = ?", [$userId]);
    } else {
        db_insert("store_settings", [
            'user_id' => $userId,
            'contact_email' => $contact_email,
            'contact_phone' => $contact_phone,
            'contact_address' => $contact_address,
            'google_maps_link' => $google_maps_link
        ]);
    }
    $success = "General settings saved.";
    $theme = getThemeSettings($userId);
    $store = db_get_row("SELECT * FROM store_settings WHERE user_id = ?", [$userId]);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Store Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Store General Settings</h1>
            <?php if(isset($success)): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <form method="POST" class="bg-white p-6 rounded shadow">
                <div class="grid grid-cols-2 gap-4">
                    <div><label>Contact Email</label><input type="email" name="contact_email" value="<?= htmlspecialchars($store['contact_email'] ?? $user['email']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Contact Phone</label><input type="text" name="contact_phone" value="<?= htmlspecialchars($store['contact_phone'] ?? $user['phone']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div class="col-span-2"><label>Full Address</label><textarea name="contact_address" rows="2" class="w-full border rounded px-3 py-2"><?= htmlspecialchars($store['contact_address'] ?? '') ?></textarea></div>
                    <div class="col-span-2"><label>Google Maps Link (optional)</label><input type="url" name="google_maps_link" value="<?= htmlspecialchars($store['google_maps_link'] ?? '') ?>" class="w-full border rounded px-3 py-2"></div>
                    <div class="col-span-2"><label>Footer Copyright Text</label><textarea name="footer_text" rows="2" class="w-full border rounded px-3 py-2"><?= htmlspecialchars($theme['footer_text'] ?? '') ?></textarea></div>
                    <div><label>Facebook Link</label><input type="url" name="facebook_link" value="<?= htmlspecialchars($theme['facebook_link'] ?? '') ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Instagram Link</label><input type="url" name="instagram_link" value="<?= htmlspecialchars($theme['instagram_link'] ?? '') ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Twitter Link</label><input type="url" name="twitter_link" value="<?= htmlspecialchars($theme['twitter_link'] ?? '') ?>" class="w-full border rounded px-3 py-2"></div>
                </div>
                <div class="mt-6"><button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Save Settings</button></div>
            </form>
        </div>
    </div>
</body>
</html>