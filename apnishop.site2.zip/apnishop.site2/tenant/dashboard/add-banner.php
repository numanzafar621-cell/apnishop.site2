<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $link = trim($_POST['link']);
    $order_position = intval($_POST['order_position']);
    if($order_position < 0) $order_position = 0;
    if($order_position > 9999) $order_position = 9999;
    
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','webp'];
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $uploadDir = '../../assets/uploads/banners/';
            ensureDirectory($uploadDir);
            $newName = time() . '_banner_' . uniqid() . '.' . $ext;
            if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newName)) {
                db_insert('small_banners', [
                    'user_id' => $userId,
                    'title' => $title,
                    'image' => $newName,
                    'link' => $link,
                    'order_position' => $order_position,
                    'is_active' => 1
                ]);
                header('Location: banners.php?msg=added');
                exit;
            } else {
                $error = 'Failed to upload image.';
            }
        } else {
            $error = 'Only JPG, PNG, WEBP images allowed.';
        }
    } else {
        $error = 'Please select a banner image.';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Small Banner</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Add New Small Banner</h1>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="mb-3"><label>Title (Optional)</label><input type="text" name="title" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Link (URL)</label><input type="url" name="link" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Order Position</label><input type="number" name="order_position" value="0" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Banner Image *</label><input type="file" name="image" accept="image/*" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Add Banner</button>
                <a href="banners.php" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>