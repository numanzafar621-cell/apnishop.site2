<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/middleware.php';

requireUserLogin();
$user = getCurrentUser();
$userId = $user['id'];
$settings = getThemeSettings($userId);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $whatsapp_number = trim($_POST['whatsapp_number']);
    $whatsapp_position = trim($_POST['whatsapp_position']);
    $whatsapp_text = trim($_POST['whatsapp_text']);
    
    db_update("theme_settings", [
        'whatsapp_number' => $whatsapp_number,
        'whatsapp_position' => $whatsapp_position,
        'whatsapp_text' => $whatsapp_text
    ], "user_id = ?", [$userId]);
    
    $success = "WhatsApp settings saved.";
    $settings = getThemeSettings($userId);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>WhatsApp Button Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">WhatsApp Button Settings</h1>
            <?php if(isset($success)): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <div class="bg-white p-6 rounded shadow">
                <form method="POST">
                    <div class="mb-3"><label>WhatsApp Number (International format)</label><input type="text" name="whatsapp_number" value="<?= htmlspecialchars($settings['whatsapp_number']) ?>" placeholder="923001234567" class="w-full border rounded px-3 py-2"><p class="text-sm text-gray-500">Example: 923001234567 (without +)</p></div>
                    <div class="mb-3"><label>Button Position</label><select name="whatsapp_position" class="w-full border rounded px-3 py-2"><option <?= $settings['whatsapp_position']=='bottom-right'?'selected':'' ?>>bottom-right</option><option <?= $settings['whatsapp_position']=='bottom-left'?'selected':'' ?>>bottom-left</option></select></div>
                    <div class="mb-3"><label>Button Text</label><input type="text" name="whatsapp_text" value="<?= htmlspecialchars($settings['whatsapp_text'] ?? 'Chat on WhatsApp') ?>" class="w-full border rounded px-3 py-2"></div>
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Save Settings</button>
                </form>
                <div class="mt-8 p-4 bg-gray-50 rounded"><h3 class="font-bold mb-2">Preview:</h3><div class="relative h-32"><div class="absolute <?= $settings['whatsapp_position'] == 'bottom-right' ? 'bottom-0 right-0' : 'bottom-0 left-0' ?>"><a href="https://wa.me/<?= $settings['whatsapp_number'] ?>" target="_blank" class="bg-green-500 text-white px-4 py-2 rounded-full inline-flex items-center gap-2 shadow-lg">💬 <?= htmlspecialchars($settings['whatsapp_text'] ?? 'WhatsApp') ?></a></div></div></div>
            </div>
        </div>
    </div>
</body>
</html>