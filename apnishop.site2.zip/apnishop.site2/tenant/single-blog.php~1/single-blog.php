<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
if(!$subdomain) {
    die("Invalid request.");
}

$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

// Pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 9;
$offset = ($page - 1) * $limit;

// Filters
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query
$sql = "SELECT * FROM blogs WHERE user_id = ? AND is_published = 1";
$params = [$userId];

if(!empty($category)) {
    $sql .= " AND category = ?";
    $params[] = $category;
}
if(!empty($search)) {
    $sql .= " AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Get total count for pagination
$countSql = str_replace("SELECT *", "SELECT COUNT(*) as total", $sql);
$totalResult = db_get_row($countSql, $params);
$totalBlogs = $totalResult['total'];
$totalPages = ceil($totalBlogs / $limit);

// Add order and limit