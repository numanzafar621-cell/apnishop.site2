<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = $_GET['subdomain'] ?? getCurrentSubdomain();
if(!$subdomain) {
    die("Invalid request.");
}

$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

// Get products for homepage (limit 8)
$products = getActiveProducts($userId, 8);

// Get sliders
$sliders = getSliders($userId);

// Get small banners
$banners = getSmallBanners($userId);

// Get published blog posts for sidebar or footer
$recentBlogs = db_get_all("SELECT id, title, slug, featured_image, created_at FROM blogs WHERE user_id = ? AND is_published = 1 ORDER BY id DESC LIMIT 3", [$userId]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title><?= htmlspecialchars($user['business_name']) ?> - Online Store</title>
    <meta name="description" content="Shop the best products at <?= htmlspecialchars($user['business_name']) ?>. Quality products at affordable prices.">
    <meta name="keywords" content="shop, ecommerce, products, <?= htmlspecialchars($user['business_name']) ?>">
    
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/assets/css/tenant-front.css">
    <link rel="stylesheet" href="/assets/css/common.css">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: <?= $theme['primary_color'] ?? '#4F46E5' ?>;
            --secondary: <?= $theme['secondary_color'] ?? '#F59E0B' ?>;
            --font-family: <?= $theme['font_family'] ?? 'Inter' ?>;
        }
        body {
            font-family: var(--font-family), sans-serif;
        }
        .btn-primary {
            background-color: var(--primary);
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: var(--primary);
            filter: brightness(0.9);
            transform: translateY(-2px);
        }
        .text-primary {
            color: var(--primary);
        }
        .border-primary {
            border-color: var(--primary);
        }
        .product-card {
            transition: all 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.02);
        }
    </style>
</head>
<body class="bg-gray-50">
    
    <!-- Header -->
    <?php getTenantHeader($userId); ?>
    
    <!-- Ticker / Marquee -->
    <?php displayTicker($userId); ?>
    
    <!-- Hero Slider -->
    <?php if(!empty($sliders)): ?>
    <div class="slider-container relative overflow-hidden">
        <div class="slider-wrapper flex transition-transform duration-500 ease-in-out">
            <?php foreach($sliders as $index => $slide): ?>
            <div class="slide min-w-full relative">
                <img src="/assets/uploads/sliders/<?= $slide['image'] ?>" alt="<?= htmlspecialchars($slide['title']) ?>" class="w-full h-64 md:h-96 object-cover">
                <div class="absolute inset-0 bg-black bg-opacity-40 flex flex-col justify-center items-center text-white text-center px-4">
                    <?php if($slide['title']): ?>
                        <h2 class="text-3xl md:text-5xl font-bold mb-2"><?= htmlspecialchars($slide['title']) ?></h2>
                    <?php endif; ?>
                    <?php if($slide['subtitle']): ?>
                        <p class="text-lg md:text-xl mb-4"><?= htmlspecialchars($slide['subtitle']) ?></p>
                    <?php endif; ?>
                    <?php if($slide['button_text'] && $slide['button_link']): ?>
                        <a href="<?= $slide['button_link'] ?>" class="bg-white text-gray-800 px-6 py-2 rounded-full font-semibold hover:bg-gray-100 transition">
                            <?= htmlspecialchars($slide['button_text']) ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Slider Navigation -->
        <?php if(count($sliders) > 1): ?>
        <button class="slider-prev absolute left-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-75 transition z-10">
            <i class="fas fa-chevron-left"></i>
        </button>
        <button class="slider-next absolute right-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-75 transition z-10">
            <i class="fas fa-chevron-right"></i>
        </button>
        
        <!-- Slider Dots -->
        <div class="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-10">
            <?php foreach($sliders as $index => $slide): ?>
                <button class="slider-dot w-3 h-3 rounded-full bg-white bg-opacity-50 hover:bg-opacity-100 transition <?= $index == 0 ? 'bg-opacity-100' : '' ?>" data-index="<?= $index ?>"></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <!-- Features Section -->
    <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div>
                    <div class="text-4xl text-primary mb-3"><i class="fas fa-truck"></i></div>
                    <h3 class="font-bold text-lg mb-1">Free Shipping</h3>
                    <p class="text-gray-500 text-sm">On orders over Rs. 5000</p>
                </div>
                <div>
                    <div class="text-4xl text-primary mb-3"><i class="fas fa-undo-alt"></i></div>
                    <h3 class="font-bold text-lg mb-1">Easy Returns</h3>
                    <p class="text-gray-500 text-sm">30 days return policy</p>
                </div>
                <div>
                    <div class="text-4xl text-primary mb-3"><i class="fas fa-headset"></i></div>
                    <h3 class="font-bold text-lg mb-1">24/7 Support</h3>
                    <p class="text-gray-500 text-sm">Dedicated customer support</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Products Section -->
    <section class="py-12">
        <div class="container mx-auto px-4">
            <div class="text-center mb-10">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800">Featured Products</h2>
                <div class="w-20 h-1 bg-primary mx-auto mt-4 rounded-full"></div>
                <p class="text-gray-500 mt-3">Discover our handpicked collection</p>
            </div>
            
            <?php if(empty($products)): ?>
                <div class="bg-white p-12 rounded-lg shadow text-center">
                    <div class="text-6xl mb-4">🛍️</div>
                    <h3 class="text-xl font-semibold text-gray-700 mb-2">No Products Yet</h3>
                    <p class="text-gray-500">Products will appear here once added.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    <?php foreach($products as $product): ?>
                    <div class="product-card bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300">
                        <a href="product.php?id=<?= $product['id'] ?>" class="block">
                            <div class="relative overflow-hidden h-56">
                                <img src="/assets/uploads/products/<?= $product['image'] ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-full object-cover transition-transform duration-300 hover:scale-105">
                                <?php if($product['compare_price'] && $product['compare_price'] > $product['price']): ?>
                                    <span class="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                                        <?= round((($product['compare_price'] - $product['price']) / $product['compare_price']) * 100) ?>% OFF
                                    </span>
                                <?php endif; ?>
                                <?php if($product['stock'] <= 0): ?>
                                    <div class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                                        <span class="bg-white text-red-600 px-3 py-1 rounded-full font-bold text-sm">Out of Stock</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </a>
                        <div class="p-4">
                            <h3 class="font-bold text-lg mb-1 line-clamp-1">
                                <a href="product.php?id=<?= $product['id'] ?>" class="hover:text-primary transition">
                                    <?= htmlspecialchars($product['name']) ?>
                                </a>
                            </h3>
                            <div class="flex items-center mb-2">
                                <?php $rating = getAverageRating($product['id']); ?>
                                <div class="flex text-yellow-400">
                                    <?php for($i=1; $i<=5; $i++): ?>
                                        <i class="fas fa-star <?= $i <= $rating ? 'text-yellow-400' : 'text-gray-300' ?> text-sm"></i>
                                    <?php endfor; ?>
                                </div>
                                <span class="text-xs text-gray-500 ml-1">(<?= db_get_value("SELECT COUNT(*) FROM reviews WHERE product_id = ? AND is_approved = 1", [$product['id']]) ?>)</span>
                            </div>
                            <div class="flex items-center justify-between mt-2">
                                <div>
                                    <span class="text-xl font-bold text-primary"><?= formatPrice($product['price']) ?></span>
                                    <?php if($product['compare_price']): ?>
                                        <span class="text-sm text-gray-400 line-through ml-1"><?= formatPrice($product['compare_price']) ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php if($product['stock'] > 0): ?>
                                    <button onclick="addToCart(<?= $product['id'] ?>)" class="bg-indigo-600 text-white px-3 py-2 rounded-full text-sm hover:bg-indigo-700 transition">
                                        <i class="fas fa-shopping-cart"></i> Add
                                    </button>
                                <?php else: ?>
                                    <button disabled class="bg-gray-300 text-gray-500 px-3 py-2 rounded-full text-sm cursor-not-allowed">
                                        Out of Stock
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="text-center mt-10">
                    <a href="shop.php" class="inline-block border-2 border-primary text-primary px-6 py-2 rounded-full font-semibold hover:bg-primary hover:text-white transition">
                        View All Products <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Small Banners Section -->
    <?php if(!empty($banners)): ?>
    <section class="py-8 bg-white">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php foreach($banners as $banner): ?>
                    <a href="<?= $banner['link'] ?>" target="_blank" class="block overflow-hidden rounded-lg shadow hover:shadow-lg transition">
                        <img src="/assets/uploads/banners/<?= $banner['image'] ?>" alt="<?= htmlspecialchars($banner['title']) ?>" class="w-full h-32 object-cover">
                        <?php if($banner['title']): ?>
                            <div class="p-2 text-center text-sm font-medium bg-gray-50"><?= htmlspecialchars($banner['title']) ?></div>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Blog Section -->
    <?php if(!empty($recentBlogs)): ?>
    <section class="py-12">
        <div class="container mx-auto px-4">
            <div class="text-center mb-10">
                <h2 class="text-3xl font-bold text-gray-800">Latest from Blog</h2>
                <div class="w-20 h-1 bg-primary mx-auto mt-4 rounded-full"></div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <?php foreach($recentBlogs as $blog): ?>
                <a href="single-blog.php?slug=<?= $blog['slug'] ?>" class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                    <?php if($blog['featured_image']): ?>
                        <img src="/assets/uploads/blogs/<?= $blog['featured_image'] ?>" alt="<?= htmlspecialchars($blog['title']) ?>" class="w-full h-48 object-cover">
                    <?php else: ?>
                        <div class="w-full h-48 bg-gray-200 flex items-center justify-center">
                            <i class="fas fa-newspaper text-4xl text-gray-400"></i>
                        </div>
                    <?php endif; ?>
                    <div class="p-4">
                        <h3 class="font-bold text-lg mb-1 line-clamp-2"><?= htmlspecialchars($blog['title']) ?></h3>
                        <p class="text-gray-500 text-sm"><?= date('M d, Y', strtotime($blog['created_at'])) ?></p>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Newsletter Section -->
    <section class="py-12 bg-primary bg-opacity-10">
        <div class="container mx-auto px-4 text-center">
            <h3 class="text-2xl font-bold text-gray-800 mb-2">Subscribe to Newsletter</h3>
            <p class="text-gray-600 mb-4">Get the latest updates on new products and offers</p>
            <form method="POST" action="subscribe.php" class="max-w-md mx-auto flex flex-col sm:flex-row gap-3">
                <input type="email" name="email" placeholder="Enter your email" required class="flex-1 border rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary">
                <button type="submit" class="bg-primary text-white px-6 py-2 rounded-full hover:brightness-90 transition">Subscribe</button>
            </form>
        </div>
    </section>
    
    <!-- Footer -->
    <?php getTenantFooter($userId); ?>
    
    <!-- Popup Modal -->
    <div id="popupModal" class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
        <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4 relative">
            <button onclick="closePopup()" class="absolute top-2 right-2 text-gray-600 hover:text-gray-800 text-2xl">&times;</button>
            <img id="popupImage" src="" class="w-full h-40 object-cover rounded mb-4" style="display:none;">
            <h3 id="popupTitle" class="text-xl font-bold mb-2"></h3>
            <p id="popupMessage" class="text-gray-700 mb-4"></p>
            <button onclick="closePopup()" class="btn-primary text-white px-4 py-2 rounded w-full">Close</button>
        </div>
    </div>
    
    <!-- WhatsApp Floating Button -->
    <?php if($theme['whatsapp_number']): ?>
    <div class="whatsapp-float <?= $theme['whatsapp_position'] == 'bottom-left' ? 'whatsapp-float-left' : '' ?>">
        <a href="https://wa.me/<?= $theme['whatsapp_number'] ?>?text=Hello! I'm interested in your products." target="_blank">
            <i class="fab fa-whatsapp fa-lg"></i> <?= htmlspecialchars($theme['whatsapp_text'] ?? 'Chat with us') ?>
        </a>
    </div>
    <?php endif; ?>
    
    <!-- Scroll to Top Button -->
    <button id="scrollToTopBtn" class="fixed bottom-6 right-6 bg-primary text-white w-10 h-10 rounded-full shadow-lg hidden items-center justify-center hover:bg-opacity-90 transition z-40">
        <i class="fas fa-arrow-up"></i>
    </button>
    
    <!-- JavaScript Files -->
    <script src="/assets/js/common.js"></script>
    <script src="/assets/js/tenant-front.js"></script>
    
    <script>
        // Add to Cart Function
        function addToCart(productId) {
            const subdomain = window.location.hostname.split('.')[0];
            fetch('/includes/cart-ajax.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=add&product_id=${productId}&subdomain=${subdomain}`
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    showToast('Product added to cart!', 'success');
                    updateCartCount();
                } else {
                    showToast('Error adding product', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Network error', 'error');
            });
        }
        
        // Update Cart Count
        function updateCartCount() {
            const subdomain = window.location.hostname.split('.')[0];
            fetch('/includes/cart-ajax.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_count&subdomain=${subdomain}`
            })
            .then(res => res.json())
            .then(data => {
                const cartBadge = document.querySelector('.cart-count');
                if(cartBadge && data.count !== undefined) {
                    cartBadge.innerText = data.count;
                    if(data.count == 0) cartBadge.classList.add('hidden');
                    else cartBadge.classList.remove('hidden');
                }
            });
        }
        
        // Load Popups
        function loadPopups() {
            const subdomain = window.location.hostname.split('.')[0];
            fetch(`/includes/get-popups.php?subdomain=${subdomain}`)
            .then(res => res.json())
            .then(popups => {
                popups.forEach(popup => {
                    if(popup.show_on_load) {
                        setTimeout(() => showPopup(popup), popup.delay_seconds * 1000);
                    }
                });
                if(popups.some(p => p.show_on_exit)) {
                    let exitShown = false;
                    document.addEventListener('mouseleave', (e) => {
                        if(!exitShown && e.clientY <= 0) {
                            exitShown = true;
                            popups.forEach(popup => {
                                if(popup.show_on_exit) showPopup(popup);
                            });
                        }
                    });
                }
            });
        }
        
        // Show Popup
        function showPopup(popup) {
            const modal = document.getElementById('popupModal');
            if(!modal) return;
            document.getElementById('popupTitle').innerText = popup.title;
            document.getElementById('popupMessage').innerText = popup.message;
            if(popup.image) {
                const img = document.getElementById('popupImage');
                img.src = '/assets/uploads/popups/' + popup.image;
                img.style.display = 'block';
            } else {
                document.getElementById('popupImage').style.display = 'none';
            }
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        // Close Popup
        function closePopup() {
            const modal = document.getElementById('popupModal');
            if(modal) {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            }
        }
        
        // Scroll to Top
        const scrollBtn = document.getElementById('scrollToTopBtn');
        if(scrollBtn) {
            window.addEventListener('scroll', () => {
                if(window.scrollY > 300) {
                    scrollBtn.classList.remove('hidden');
                    scrollBtn.classList.add('flex');
                } else {
                    scrollBtn.classList.add('hidden');
                    scrollBtn.classList.remove('flex');
                }
            });
            scrollBtn.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }
        
        // Initialize on load
        document.addEventListener('DOMContentLoaded', () => {
            updateCartCount();
            loadPopups();
        });
    </script>
</body>
</html>