<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

$subdomain = getCurrentSubdomain();
$error = '';

if(isUserLoggedIn()) {
    header('Location: /tenant/dashboard/index.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if(empty($email) || empty($password)) {
        $error = 'Please enter email and password.';
    } else {
        $loginResult = userLogin($email, $password);
        if($loginResult === true) {
            header('Location: /tenant/dashboard/index.php');
            exit;
        } elseif($loginResult === 'inactive') {
            $error = 'Your account is not activated yet. Please complete CNIC verification.';
        } elseif($loginResult === 'plan_expired') {
            $error = 'Your plan has expired. Please renew your plan.';
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Seller Login - <?= htmlspecialchars($subdomain) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-2">Seller Login</h2>
            <p class="text-center text-gray-500 mb-6"><?= htmlspecialchars($subdomain) ?>.apnishop.site</p>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-4"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-6"><label>Password</label><input type="password" name="password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded">Login</button>
            </form>
            <p class="text-center text-gray-600 mt-4"><a href="/forgot-password.php" class="text-indigo-600">Forgot Password?</a></p>
        </div>
    </div>
</body>
</html>