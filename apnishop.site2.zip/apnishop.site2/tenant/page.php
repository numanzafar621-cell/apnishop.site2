<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

$slug = $_GET['slug'] ?? '';
$page = db_get_row("SELECT * FROM pages WHERE user_id = ? AND slug = ? AND is_active = 1", [$userId, $slug]);
if(!$page) die("Page not found.");
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($page['title']) ?> - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-4xl mx-auto bg-white p-8 rounded shadow">
            <h1 class="text-3xl font-bold mb-4"><?= htmlspecialchars($page['title']) ?></h1>
            <div class="prose max-w-none"><?= htmlspecialchars_decode($page['content']) ?></div>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
</body>
</html>