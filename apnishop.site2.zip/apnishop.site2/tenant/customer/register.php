<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';

$subdomain = getCurrentSubdomain();
$seller = getUserBySubdomain($subdomain);
if(!$seller) die("Invalid store.");

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    
    if(empty($name) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $existing = db_get_row("SELECT id FROM customers WHERE email = ? AND seller_id = ?", [$email, $seller['id']]);
        if($existing) {
            $error = 'Email already registered. Please login.';
        } else {
            $hashed = hashPassword($password);
            db_insert('customers', [
                'seller_id' => $seller['id'],
                'name' => $name,
                'email' => $email,
                'password' => $hashed,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            $success = 'Account created successfully. Please login.';
            header('refresh:2;url=login.php');
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Account - <?= htmlspecialchars($seller['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Create Account</h2>
            <?php if($error): ?><div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-100 text-green-700 p-3 rounded mb-4"><?= $success ?> Redirecting...</div><?php endif; ?>
            <form method="POST">
                <div class="mb-3"><label>Full Name</label><input type="text" name="name" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Password</label><input type="password" name="password" required minlength="6" class="w-full border rounded px-3 py-2"></div>
                <div class="mb-4"><label>Confirm Password</label><input type="password" name="confirm_password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded">Sign Up</button>
            </form>
            <p class="text-center text-gray-600 mt-4">Already have an account? <a href="login.php" class="text-indigo-600">Login</a></p>
        </div>
    </div>
</body>
</html>