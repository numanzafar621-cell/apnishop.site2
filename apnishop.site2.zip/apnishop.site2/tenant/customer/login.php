<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';

$subdomain = getCurrentSubdomain();
$seller = getUserBySubdomain($subdomain);
if(!$seller) die("Invalid store.");

$error = '';

if(isset($_SESSION['customer_logged_in']) && $_SESSION['customer_logged_in'] === true) {
    header('Location: account.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    $customer = db_get_row("SELECT * FROM customers WHERE email = ? AND seller_id = ?", [$email, $seller['id']]);
    if($customer && verifyPassword($password, $customer['password'])) {
        $_SESSION['customer_logged_in'] = true;
        $_SESSION['customer_id'] = $customer['id'];
        $_SESSION['customer_name'] = $customer['name'];
        $_SESSION['customer_email'] = $customer['email'];
        $_SESSION['seller_id'] = $seller['id'];
        header('Location: account.php');
        exit;
    } else {
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Customer Login - <?= htmlspecialchars($seller['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Customer Login</h2>
            <?php if($error): ?><div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-4"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-6"><label>Password</label><input type="password" name="password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded">Login</button>
            </form>
            <p class="text-center text-gray-600 mt-4">New customer? <a href="register.php" class="text-indigo-600">Create Account</a></p>
            <p class="text-center text-gray-500 text-sm mt-2"><a href="forgot-password.php">Forgot Password?</a></p>
        </div>
    </div>
</body>
</html>