<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/tenant-functions.php';

$subdomain = getCurrentSubdomain();
$seller = getUserBySubdomain($subdomain);
if(!$seller) die("Invalid store.");

if(!isset($_SESSION['customer_logged_in']) || $_SESSION['customer_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$orderId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$order = db_get_row("SELECT * FROM orders WHERE id = ? AND customer_id = ? AND user_id = ?", [$orderId, $_SESSION['customer_id'], $seller['id']]);
if(!$order) die("Order not found.");

$items = db_get_all("SELECT oi.*, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?", [$orderId]);
$total = 0;
foreach($items as $item) $total += $item['price'] * $item['quantity'];
$theme = getThemeSettings($seller['id']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order Details #<?= $order['order_number'] ?> - <?= htmlspecialchars($seller['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($seller['id']); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Order #<?= $order['order_number'] ?></h1>
        <div class="bg-white p-6 rounded shadow mb-6">
            <p><strong>Order Date:</strong> <?= date('d-m-Y h:i A', strtotime($order['created_at'])) ?></p>
            <p><strong>Status:</strong> <?= ucfirst($order['status']) ?></p>
            <p><strong>Payment Method:</strong> <?= $order['payment_method'] ?></p>
            <p><strong>Payment Status:</strong> <?= ucfirst($order['payment_status']) ?></p>
            <p><strong>Shipping Address:</strong> <?= nl2br(htmlspecialchars($order['customer_address'])) ?></p>
        </div>
        <div class="bg-white p-6 rounded shadow">
            <h2 class="text-xl font-bold mb-3">Items</h2>
            <table class="min-w-full">
                <thead class="bg-gray-50"><tr><th>Product</th><th>Quantity</th><th>Price</th><th>Subtotal</th></tr></thead>
                <tbody>
                    <?php foreach($items as $item): $sub = $item['price'] * $item['quantity']; ?>
                    <tr class="border-t"><td class="p-2"><?= htmlspecialchars($item['name']) ?></td><td class="p-2"><?= $item['quantity'] ?></td><td class="p-2"><?= formatPrice($item['price']) ?></td><td class="p-2"><?= formatPrice($sub) ?></td></tr>
                    <?php endforeach; ?>
                    <tr class="border-t font-bold"><td colspan="3" class="p-2 text-right">Total:</td><td class="p-2"><?= formatPrice($total) ?></td></tr>
                </tbody>
            </table>
        </div>
        <div class="mt-4"><a href="account.php" class="bg-indigo-600 text-white px-4 py-2 rounded">Back to Account</a></div>
    </div>
    <?php getTenantFooter($seller['id']); ?>
</body>
</html>