<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/mail.php';

$subdomain = getCurrentSubdomain();
$seller = getUserBySubdomain($subdomain);
if(!$seller) die("Invalid store.");

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    if(empty($email)) {
        $error = 'Please enter your email address.';
    } else {
        $customer = db_get_row("SELECT id, name, email FROM customers WHERE email = ? AND seller_id = ?", [$email, $seller['id']]);
        if($customer) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            db_delete("password_resets", "email = ? AND type = 'customer' AND seller_id = ?", [$email, $seller['id']]);
            db_insert("password_resets", [
                'email' => $email,
                'token' => $token,
                'type' => 'customer',
                'seller_id' => $seller['id'],
                'expires_at' => $expires
            ]);
            $resetLink = "http://" . $subdomain . ".apnishop.site/customer/reset-password.php?token=" . $token . "&email=" . urlencode($email);
            // Send email using mail function (can be customized)
            $subject = "Reset Your Password - " . $seller['business_name'];
            $message = "Hello " . $customer['name'] . ",\n\nClick the link below to reset your password:\n" . $resetLink . "\n\nThis link expires in 1 hour.\n\nIf you did not request this, ignore this email.";
            mail($email, $subject, $message, "From: noreply@" . $subdomain . ".apnishop.site");
            $success = "A password reset link has been sent to your email.";
        } else {
            $success = "If this email exists, a reset link has been sent.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password - <?= htmlspecialchars($seller['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Forgot Password?</h2>
            <p class="text-gray-600 text-center mb-4">Enter your email to receive a reset link.</p>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-4"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded">Send Reset Link</button>
            </form>
            <p class="text-center text-gray-600 mt-4"><a href="login.php" class="text-indigo-600">Back to Login</a></p>
        </div>
    </div>
</body>
</html>