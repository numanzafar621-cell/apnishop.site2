<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';
require_once '../../includes/tenant-functions.php';

$subdomain = getCurrentSubdomain();
$seller = getUserBySubdomain($subdomain);
if(!$seller) die("Invalid store.");

if(!isset($_SESSION['customer_logged_in']) || $_SESSION['customer_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$customerId = $_SESSION['customer_id'];
$orders = db_get_all("SELECT * FROM orders WHERE customer_id = ? AND user_id = ? ORDER BY id DESC", [$customerId, $seller['id']]);
$theme = getThemeSettings($seller['id']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Account - <?= htmlspecialchars($seller['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($seller['id']); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-4">My Account</h1>
        <p>Welcome, <?= htmlspecialchars($_SESSION['customer_name']) ?> (<?= $_SESSION['customer_email'] ?>)</p>
        <div class="mt-6">
            <h2 class="text-2xl font-bold mb-3">Order History</h2>
            <?php if(empty($orders)): ?>
                <p>You have no orders yet.</p>
            <?php else: ?>
                <div class="bg-white rounded shadow overflow-hidden">
                    <table class="min-w-full">
                        <thead class="bg-gray-800 text-white">
                            <tr><th class="p-3">Order #</th><th>Date</th><th>Total</th><th>Status</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach($orders as $o): ?>
                            <tr class="border-t">
                                <td class="p-3"><?= $o['order_number'] ?></td>
                                <td class="p-3"><?= date('d-m-Y', strtotime($o['created_at'])) ?></td>
                                <td class="p-3"><?= formatPrice($o['total_amount']) ?></td>
                                <td class="p-3"><?= ucfirst($o['status']) ?></td>
                                <td class="p-3"><a href="order-details.php?id=<?= $o['id'] ?>" class="text-blue-600">View</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        <div class="mt-6">
            <a href="logout.php" class="bg-red-600 text-white px-4 py-2 rounded">Logout</a>
        </div>
    </div>
    <?php getTenantFooter($seller['id']); ?>
</body>
</html>