<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
if(!$subdomain) die("Invalid request.");
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

$productId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$product = db_get_row("SELECT * FROM products WHERE id = ? AND user_id = ? AND is_active = 1", [$productId, $userId]);
if(!$product) die("Product not found.");

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_review'])) {
    $rating = intval($_POST['rating']);
    $comment = trim($_POST['comment']);
    $customer_name = trim($_POST['customer_name']);
    if($rating >= 1 && $rating <= 5 && !empty($comment)) {
        db_insert('reviews', ['product_id'=>$productId, 'user_id'=>$userId, 'customer_name'=>$customer_name, 'rating'=>$rating, 'comment'=>$comment, 'is_approved'=>1]);
        $review_success = "Thank you for your review.";
    }
}
$reviews = db_get_all("SELECT * FROM reviews WHERE product_id = ? AND is_approved = 1 ORDER BY id DESC", [$productId]);
$avgRating = getAverageRating($productId);
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($product['name']) ?> - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <style>:root{--primary:<?= $theme['primary_color'] ?>;}</style>
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <div class="grid md:grid-cols-2 gap-8">
            <div><img src="/assets/uploads/products/<?= $product['image'] ?>" class="w-full rounded shadow"></div>
            <div>
                <h1 class="text-3xl font-bold"><?= htmlspecialchars($product['name']) ?></h1>
                <p class="text-2xl text-indigo-600 mt-2"><?= formatPrice($product['price']) ?></p>
                <?php if($product['compare_price']): ?><p class="text-gray-500 line-through"><?= formatPrice($product['compare_price']) ?></p><?php endif; ?>
                <p class="text-gray-600 mt-4">Stock: <?= $product['stock'] > 0 ? $product['stock'] : 'Out of stock' ?></p>
                <div class="flex items-center my-4"><?php for($i=1;$i<=5;$i++) echo '<span class="text-yellow-400 text-2xl">'.($i<=$avgRating?'★':'☆').'</span>'; ?><span class="ml-2 text-gray-500">(<?= count($reviews) ?> reviews)</span></div>
                <div class="prose max-w-none"><?= nl2br(htmlspecialchars($product['description'])) ?></div>
                <button onclick="addToCart(<?= $product['id'] ?>)" class="bg-indigo-600 text-white px-6 py-2 rounded-full mt-4 w-full">Add to Cart</button>
                <?php if($theme['whatsapp_number']): ?><a href="https://wa.me/<?= $theme['whatsapp_number'] ?>?text=I%20am%20interested%20in%20<?= urlencode($product['name']) ?>" target="_blank" class="bg-green-500 text-white px-6 py-2 rounded-full mt-2 w-full inline-block text-center">💬 Ask on WhatsApp</a><?php endif; ?>
            </div>
        </div>
        <?php if($product['banner_image']): ?><div class="my-8 text-center"><a href="<?= $product['banner_link'] ?>" target="_blank"><img src="/assets/uploads/products/banners/<?= $product['banner_image'] ?>" class="mx-auto rounded shadow"></a></div><?php endif; ?>
        <div class="mt-12"><h2 class="text-2xl font-bold mb-4">Customer Reviews</h2>
            <?php if(isset($review_success)) echo '<div class="bg-green-100 p-2 rounded mb-3">'.$review_success.'</div>'; ?>
            <form method="POST" class="bg-gray-50 p-4 rounded mb-6"><h3 class="font-bold">Write a Review</h3>
                <div class="mb-2"><label>Your Name</label><input type="text" name="customer_name" required class="w-full border rounded px-3 py-1"></div>
                <div class="mb-2"><label>Rating</label><select name="rating" class="border rounded px-3 py-1"><option value="5">★★★★★</option><option value="4">★★★★☆</option><option value="3">★★★☆☆</option><option value="2">★★☆☆☆</option><option value="1">★☆☆☆☆</option></select></div>
                <div class="mb-2"><label>Comment</label><textarea name="comment" rows="3" required class="w-full border rounded px-3 py-1"></textarea></div>
                <button type="submit" name="submit_review" class="bg-indigo-600 text-white px-4 py-2 rounded">Submit Review</button>
            </form>
            <?php foreach($reviews as $r): ?><div class="border-b py-3"><div class="flex items-center"><?php for($i=1;$i<=5;$i++) echo '<span class="text-yellow-400">'.($i<=$r['rating']?'★':'☆').'</span>'; ?><span class="ml-2 font-bold"><?= htmlspecialchars($r['customer_name']) ?></span></div><p class="mt-1"><?= nl2br(htmlspecialchars($r['comment'])) ?></p><p class="text-xs text-gray-400"><?= date('d-m-Y', strtotime($r['created_at'])) ?></p></div><?php endforeach; ?>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
    <script>function addToCart(id){fetch('/includes/cart-ajax.php',{method:'POST',body:'action=add&product_id='+id+'&subdomain=<?= $subdomain ?>',headers:{'Content-Type':'application/x-www-form-urlencoded'}}).then(()=>alert('Added to cart'));}</script>
</body>
</html>