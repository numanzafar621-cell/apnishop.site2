<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';
require_once '../includes/mail.php';

$subdomain = getCurrentSubdomain();
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);
$store = db_get_row("SELECT * FROM store_settings WHERE user_id = ?", [$userId]);

$success = '';
$error = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);
    if($name && $email && $subject && $message) {
        $to = $user['email'];
        $headers = "From: $email\r\nReply-To: $email\r\n";
        mail($to, "[Contact] $subject", $message, $headers);
        $success = "Your message has been sent. We'll contact you soon.";
    } else {
        $error = "Please fill all fields.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Us - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Contact Us</h1>
        <div class="grid md:grid-cols-2 gap-8">
            <div class="bg-white p-6 rounded shadow">
                <?php if($success): ?><div class="bg-green-100 p-2 rounded mb-4"><?= $success ?></div><?php endif; ?>
                <?php if($error): ?><div class="bg-red-100 p-2 rounded mb-4"><?= $error ?></div><?php endif; ?>
                <form method="POST"><div class="mb-3"><label>Your Name</label><input type="text" name="name" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Subject</label><input type="text" name="subject" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-3"><label>Message</label><textarea name="message" rows="5" required class="w-full border rounded px-3 py-2"></textarea></div>
                <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded">Send Message</button></form>
            </div>
            <div class="bg-white p-6 rounded shadow"><h2 class="text-xl font-bold mb-4">Our Contact Info</h2>
                <p><strong>Phone:</strong> <?= $store['contact_phone'] ?? $user['phone'] ?></p>
                <p><strong>Email:</strong> <?= $store['contact_email'] ?? $user['email'] ?></p>
                <p><strong>Address:</strong> <?= nl2br(htmlspecialchars($store['contact_address'] ?? 'No address provided')) ?></p>
                <?php if($store['google_maps_link']): ?><p><strong>Map:</strong> <a href="<?= $store['google_maps_link'] ?>" target="_blank" class="text-blue-600">View on Google Maps</a></p><?php endif; ?>
                <?php if($theme['facebook_link']): ?><p><strong>Facebook:</strong> <a href="<?= $theme['facebook_link'] ?>" target="_blank" class="text-blue-600">Follow us</a></p><?php endif; ?>
            </div>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
</body>
</html>