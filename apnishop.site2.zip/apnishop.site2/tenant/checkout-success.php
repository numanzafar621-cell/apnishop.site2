<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

$order_number = $_GET['order'] ?? '';
$order = db_get_row("SELECT * FROM orders WHERE order_number = ? AND user_id = ?", [$order_number, $userId]);
if(!$order) die("Order not found.");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order Confirmation - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8 text-center">
        <div class="bg-white p-8 rounded shadow max-w-lg mx-auto">
            <div class="text-green-500 text-6xl mb-4">✓</div>
            <h1 class="text-2xl font-bold mb-2">Thank You!</h1>
            <p>Your order has been placed successfully.</p>
            <p class="text-gray-600 mt-2">Order Number: <strong><?= $order['order_number'] ?></strong></p>
            <p>We will contact you soon.</p>
            <a href="shop.php" class="inline-block mt-6 bg-indigo-600 text-white px-6 py-2 rounded">Continue Shopping</a>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
</body>
</html>