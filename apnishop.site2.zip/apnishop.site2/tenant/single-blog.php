<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/tenant-functions.php';
require_once '../includes/middleware.php';

$subdomain = getCurrentSubdomain();
$user = checkTenantWebsiteStatus($subdomain);
$userId = $user['id'];
$theme = getThemeSettings($userId);

$slug = $_GET['slug'] ?? '';
$blog = db_get_row("SELECT * FROM blogs WHERE user_id = ? AND slug = ? AND is_published = 1", [$userId, $slug]);
if(!$blog) die("Blog post not found.");

$related = db_get_all("SELECT id, title, slug, featured_image FROM blogs WHERE user_id = ? AND category = ? AND id != ? AND is_published = 1 LIMIT 3", [$userId, $blog['category'], $blog['id']]);
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($blog['title']) ?> - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <?php getTenantHeader($userId); ?>
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-3xl mx-auto">
            <?php if($blog['featured_image']): ?><img src="/assets/uploads/blogs/<?= $blog['featured_image'] ?>" class="w-full rounded-lg shadow mb-6"><?php endif; ?>
            <h1 class="text-3xl font-bold mb-2"><?= htmlspecialchars($blog['title']) ?></h1>
            <p class="text-gray-500 mb-6"><?= date('d-m-Y', strtotime($blog['created_at'])) ?> | <?= $blog['category'] ?> | Tags: <?= htmlspecialchars($blog['tags']) ?></p>
            <div class="prose max-w-none bg-white p-6 rounded shadow"><?= htmlspecialchars_decode($blog['content']) ?></div>
            <?php if(!empty($related)): ?><div class="mt-12"><h3 class="text-xl font-bold mb-4">Related Posts</h3><div class="grid md:grid-cols-3 gap-4"><?php foreach($related as $r): ?><a href="single-blog.php?slug=<?= $r['slug'] ?>" class="bg-white p-3 rounded shadow hover:shadow-md"><?php if($r['featured_image']): ?><img src="/assets/uploads/blogs/<?= $r['featured_image'] ?>" class="h-32 w-full object-cover rounded"><?php endif; ?><p class="font-bold mt-2"><?= htmlspecialchars($r['title']) ?></p></a><?php endforeach; ?></div></div><?php endif; ?>
        </div>
    </div>
    <?php getTenantFooter($userId); ?>
</body>
</html>