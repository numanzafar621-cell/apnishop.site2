<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/mail.php';

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    
    if(empty($email)) {
        $error = 'Please enter your email address.';
    } else {
        $user = db_get_row("SELECT id, first_name, email FROM users WHERE email = ?", [$email]);
        if($user) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            db_delete("password_resets", "email = ? AND type = 'seller'", [$email]);
            db_insert("password_resets", [
                'email' => $email,
                'token' => $token,
                'type' => 'seller',
                'expires_at' => $expires
            ]);
            $resetLink = BASE_URL . "/reset-password.php?token=" . $token . "&email=" . urlencode($email) . "&type=seller";
            sendResetEmail($email, $user['first_name'], $resetLink);
            $success = "A password reset link has been sent to your email address.";
        } else {
            $success = "If this email exists, a reset link has been sent.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password - ApniShop</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6">Forgot Password?</h2>
            <p class="text-gray-600 text-center mb-4">Enter your email and we'll send you a reset link.</p>
            <?php if($error): ?><div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-100 text-green-700 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-4"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded">Send Reset Link</button>
            </form>
            <p class="text-center text-gray-600 mt-4"><a href="login.php" class="text-indigo-600">Back to Login</a></p>
        </div>
    </div>
</body>
</html>