<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function adminLogin($email, $password) {
    $admin = db_get_row("SELECT * FROM main_admins WHERE email = ?", [$email]);
    if($admin && verifyPassword($password, $admin['password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['username'];
        return true;
    }
    return false;
}

function adminLogout() {
    unset($_SESSION['admin_logged_in']);
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_name']);
    session_destroy();
}

function isUserLoggedIn() {
    return isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true;
}

function userLogin($email, $password) {
    $user = db_get_row("SELECT * FROM users WHERE email = ?", [$email]);
    if($user && verifyPassword($password, $user['password'])) {
        if($user['is_active'] != 1) return 'inactive';
        if($user['plan_expiry'] && strtotime($user['plan_expiry']) < time()) return 'plan_expired';
        $_SESSION['user_logged_in'] = true;
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['user_subdomain'] = $user['subdomain'];
        return true;
    }
    return false;
}

function userLogout() {
    unset($_SESSION['user_logged_in']);
    unset($_SESSION['user_id']);
    unset($_SESSION['user_name']);
    unset($_SESSION['user_subdomain']);
    session_destroy();
}

function getCurrentUser() {
    if(isUserLoggedIn()) return getUserById($_SESSION['user_id']);
    return null;
}

function getCurrentAdmin() {
    if(isAdminLoggedIn()) return db_get_row("SELECT * FROM main_admins WHERE id = ?", [$_SESSION['admin_id']]);
    return null;
}

function requireUserLogin() {
    if(!isUserLoggedIn()) { header('Location: /login.php'); exit; }
}

function requireAdminLogin() {
    if(!isAdminLoggedIn()) { header('Location: /admin/login.php'); exit; }
}
?>