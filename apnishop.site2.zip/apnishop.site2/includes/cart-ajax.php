<?php
session_start();
require_once 'config.php';
require_once 'db.php';
require_once 'functions.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? '';
$product_id = intval($_POST['product_id'] ?? 0);
$subdomain = $_POST['subdomain'] ?? getCurrentSubdomain();

if(!$subdomain) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$user = db_get_row("SELECT id FROM users WHERE subdomain = ? AND is_active = 1", [$subdomain]);
if(!$user) {
    echo json_encode(['success' => false, 'message' => 'Store not found']);
    exit;
}

$user_id = $user['id'];
$session_id = session_id();

if($action == 'add' && $product_id) {
    $existing = db_get_row("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ? AND session_id = ?", [$user_id, $product_id, $session_id]);
    if($existing) {
        $newQty = $existing['quantity'] + 1;
        db_update("cart", ['quantity' => $newQty], "id = ?", [$existing['id']]);
    } else {
        db_insert("cart", ['user_id' => $user_id, 'product_id' => $product_id, 'quantity' => 1, 'session_id' => $session_id]);
    }
    echo json_encode(['success' => true, 'message' => 'Product added to cart']);
    exit;
}

if($action == 'remove' && $product_id) {
    db_delete("cart", "user_id = ? AND product_id = ? AND session_id = ?", [$user_id, $product_id, $session_id]);
    echo json_encode(['success' => true, 'message' => 'Product removed']);
    exit;
}

if($action == 'get_count') {
    $count = db_get_value("SELECT SUM(quantity) FROM cart WHERE user_id = ? AND session_id = ?", [$user_id, $session_id]);
    echo json_encode(['count' => (int)$count]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>