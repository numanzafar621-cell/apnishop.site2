<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'multitenant_ecommerce');

define('BASE_URL', 'https://apnishop.site');
define('ADMIN_URL', BASE_URL . '/admin');
define('ASSETS_URL', BASE_URL . '/assets');

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4");
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

function getCurrentSubdomain() {
    $host = $_SERVER['HTTP_HOST'];
    if($host == 'localhost' || $host == '127.0.0.1') return null;
    $parts = explode('.', $host);
    if(count($parts) >= 3 && $parts[0] != 'www' && $parts[0] != 'admin') {
        return $parts[0];
    }
    return null;
}

date_default_timezone_set('Asia/Karachi');
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>