<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

function getTenantHeader($user_id) {
    $theme = getThemeSettings($user_id);
    $user = getUserById($user_id);
    $pages = db_get_all("SELECT * FROM pages WHERE user_id = ? AND show_in_menu = 1 AND is_active = 1", [$user_id]);
    $cartCount = getCartItemCount($user_id);
    ?>
    <header class="shadow-md sticky top-0 bg-white z-50">
        <div class="container mx-auto px-4 py-3 flex flex-wrap justify-between items-center">
            <div class="text-2xl font-bold" style="color: <?= $theme['primary_color'] ?>">
                <?php if($theme['logo']): ?>
                    <img src="/assets/uploads/<?= $theme['logo'] ?>" class="h-10" alt="logo">
                <?php else: ?>
                    <?= htmlspecialchars($user['business_name']) ?>
                <?php endif; ?>
            </div>
            <div class="hidden md:flex space-x-6">
                <a href="/" class="hover:text-primary">Home</a>
                <a href="/shop.php" class="hover:text-primary">Shop</a>
                <?php foreach($pages as $page): ?>
                    <a href="/page.php?slug=<?= $page['slug'] ?>" class="hover:text-primary"><?= htmlspecialchars($page['title']) ?></a>
                <?php endforeach; ?>
                <a href="/blog.php" class="hover:text-primary">Blog</a>
                <a href="/contact.php" class="hover:text-primary">Contact</a>
            </div>
            <div class="flex items-center space-x-4">
                <form action="/shop.php" method="GET" class="hidden md:block"><input type="text" name="search" placeholder="Search..." class="border rounded-full px-4 py-1"></form>
                <a href="/cart.php" class="relative">🛒 <span class="absolute -top-2 -right-3 bg-red-500 text-white text-xs rounded-full px-1"><?= $cartCount ?></span></a>
            </div>
        </div>
    </header>
    <?php
}

function getTenantFooter($user_id) {
    $theme = getThemeSettings($user_id);
    ?>
    <footer class="bg-gray-900 text-white py-8 mt-12">
        <div class="container mx-auto px-4 text-center">
            <p><?= htmlspecialchars($theme['footer_text'] ?? '© 2025 - All rights reserved') ?></p>
            <div class="flex justify-center space-x-4 mt-4">
                <?php if($theme['facebook_link']): ?><a href="<?= $theme['facebook_link'] ?>" target="_blank" class="hover:text-blue-400">Facebook</a><?php endif; ?>
                <?php if($theme['instagram_link']): ?><a href="<?= $theme['instagram_link'] ?>" target="_blank" class="hover:text-pink-400">Instagram</a><?php endif; ?>
                <?php if($theme['twitter_link']): ?><a href="<?= $theme['twitter_link'] ?>" target="_blank" class="hover:text-blue-300">Twitter</a><?php endif; ?>
            </div>
        </div>
    </footer>
    <?php
}

function getCartItemCount($user_id) {
    $session_id = session_id();
    $count = db_get_value("SELECT SUM(quantity) FROM cart WHERE user_id = ? AND session_id = ?", [$user_id, $session_id]);
    return $count ?: 0;
}

function displaySmallBanners($user_id) {
    $banners = getSmallBanners($user_id);
    if(empty($banners)) return;
    ?>
    <div class="small-banners flex flex-wrap justify-center gap-4 my-8">
        <?php foreach($banners as $b): ?>
            <a href="<?= $b['link'] ?>" target="_blank" class="transition hover:scale-105"><img src="/assets/uploads/banners/<?= $b['image'] ?>" class="h-24 w-auto rounded shadow"><?php if($b['title']): ?><p class="text-center text-sm mt-1"><?= htmlspecialchars($b['title']) ?></p><?php endif; ?></a>
        <?php endforeach; ?>
    </div>
    <?php
}

function displaySliders($user_id) {
    $sliders = getSliders($user_id);
    if(empty($sliders)) return;
    ?>
    <div class="slider-container relative overflow-hidden rounded-xl mb-8">
        <div class="slider-wrapper flex transition-transform duration-500">
            <?php foreach($sliders as $s): ?>
            <div class="slide min-w-full relative"><img src="/assets/uploads/sliders/<?= $s['image'] ?>" class="w-full h-64 md:h-96 object-cover"><div class="absolute inset-0 bg-black bg-opacity-40 flex flex-col justify-center items-center text-white text-center"><h2 class="text-3xl md:text-5xl font-bold"><?= htmlspecialchars($s['title']) ?></h2><p class="text-lg md:text-xl mt-2"><?= htmlspecialchars($s['subtitle']) ?></p><?php if($s['button_text'] && $s['button_link']): ?><a href="<?= $s['button_link'] ?>" class="mt-4 bg-white text-gray-800 px-6 py-2 rounded-full font-semibold"><?= $s['button_text'] ?></a><?php endif; ?></div></div>
            <?php endforeach; ?>
        </div>
        <button class="slider-prev absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 rounded-full">&lt;</button>
        <button class="slider-next absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 rounded-full">&gt;</button>
    </div>
    <?php
}

function displayTicker($user_id) {
    $theme = getThemeSettings($user_id);
    $ticker = $theme['ticker_text'] ?? '🔥 Special Offer! Free Shipping 🔥';
    if(!$ticker) return;
    ?>
    <div class="bg-yellow-100 py-2 overflow-hidden whitespace-nowrap"><span class="inline-block animate-marquee"><?= htmlspecialchars($ticker) ?></span></div>
    <style>@keyframes marquee{0%{transform:translateX(100%)}100%{transform:translateX(-100%)}}.animate-marquee{animation:marquee 20s linear infinite;}</style>
    <?php
}
?>