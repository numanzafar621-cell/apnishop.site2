<?php
require_once __DIR__ . '/config.php';

function db_get_row($sql, $params = []) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function db_get_all($sql, $params = []) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function db_get_value($sql, $params = []) {
    $row = db_get_row($sql, $params);
    return $row ? array_values($row)[0] : null;
}

function db_insert($table, $data) {
    global $pdo;
    $columns = implode(', ', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    return $pdo->lastInsertId();
}

function db_update($table, $data, $where, $whereParams = []) {
    global $pdo;
    $set = [];
    $params = [];
    foreach($data as $key => $value) {
        $set[] = "$key = ?";
        $params[] = $value;
    }
    $sql = "UPDATE $table SET " . implode(', ', $set) . " WHERE $where";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge($params, $whereParams));
    return $stmt->rowCount();
}

function db_delete($table, $where, $params = []) {
    global $pdo;
    $sql = "DELETE FROM $table WHERE $where";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->rowCount();
}
?>