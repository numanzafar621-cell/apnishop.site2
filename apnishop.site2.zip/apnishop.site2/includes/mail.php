<?php
// Simple mail function using PHP mail()
function sendResetEmail($to, $name, $resetLink) {
    $subject = "Reset Your Password - ApniShop";
    $message = "
    <html>
    <head><title>Reset Your Password</title></head>
    <body>
        <h2>Hello $name,</h2>
        <p>You requested to reset your password. Click the link below to reset it:</p>
        <p><a href='$resetLink' style='background:#4F46E5; color:white; padding:10px 20px; text-decoration:none; border-radius:5px;'>Reset Password</a></p>
        <p>This link will expire in 1 hour.</p>
        <p>If you did not request this, please ignore this email.</p>
        <br>
        <p>Regards,<br>ApniShop Team</p>
    </body>
    </html>
    ";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@apnishop.site" . "\r\n";
    
    return mail($to, $subject, $message, $headers);
}

// Send contact form email to seller
function sendContactEmail($sellerEmail, $sellerName, $customerName, $customerEmail, $subject, $message) {
    $fullMessage = "Name: $customerName\nEmail: $customerEmail\n\nMessage:\n$message";
    $headers = "From: $customerEmail\r\nReply-To: $customerEmail\r\n";
    return mail($sellerEmail, "[Contact] $subject", $fullMessage, $headers);
}
?>