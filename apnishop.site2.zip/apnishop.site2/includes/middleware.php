<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

function checkUserPlanAndActive($user_id) {
    $user = getUserById($user_id);
    if(!$user) return false;
    if($user['plan_expiry'] && strtotime($user['plan_expiry']) < time()) return false;
    if(!$user['cnic_front'] || !$user['cnic_back']) return false;
    if($user['is_active'] != 1) return false;
    return true;
}

function checkTenantWebsiteStatus($subdomain) {
    $user = getUserBySubdomain($subdomain);
    if(!$user) die("Store not found.");
    if($user['is_active'] != 1) die("This store is currently inactive. Please contact admin.");
    if($user['plan_expiry'] && strtotime($user['plan_expiry']) < time()) die("This store's plan has expired. Please renew.");
    return $user;
}

function requireCnicVerification() {
    $user = getCurrentUser();
    if($user && (!$user['cnic_front'] || !$user['cnic_back'])) {
        header('Location: /tenant/dashboard/verification.php');
        exit;
    }
}

function requireActivePlan() {
    $user = getCurrentUser();
    if($user && $user['plan_expiry'] && strtotime($user['plan_expiry']) < time()) {
        header('Location: /tenant/dashboard/plan.php?expired=1');
        exit;
    }
}
?>