<?php
session_start();
require_once 'config.php';
require_once 'db.php';
require_once 'functions.php';
require_once 'auth.php';

header('Content-Type: application/json');

$isAdmin = isAdminLoggedIn();
$isUser = isUserLoggedIn();

if(!$isAdmin && !$isUser) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_POST['action'] ?? '';
$message = trim($_POST['message'] ?? '');
$to_user_id = intval($_POST['to_user_id'] ?? 0);

if($action == 'send' && $message && $to_user_id) {
    if($isAdmin) {
        db_insert('live_chat', [
            'from_user_id' => $to_user_id,
            'to_user_id' => $to_user_id,
            'from_admin' => 1,
            'message' => $message,
            'is_read' => 0
        ]);
    } elseif($isUser) {
        $userId = $_SESSION['user_id'];
        db_insert('live_chat', [
            'from_user_id' => $userId,
            'to_user_id' => $userId,
            'from_admin' => 0,
            'message' => $message,
            'is_read' => 0
        ]);
    }
    echo json_encode(['success' => true]);
    exit;
}

if($action == 'fetch' && $to_user_id) {
    if($isAdmin) {
        $messages = db_get_all("SELECT * FROM live_chat WHERE to_user_id = ? OR from_user_id = ? ORDER BY created_at ASC", [$to_user_id, $to_user_id]);
    } elseif($isUser) {
        $userId = $_SESSION['user_id'];
        $messages = db_get_all("SELECT * FROM live_chat WHERE (from_user_id = ? AND from_admin = 0) OR (to_user_id = ? AND from_admin = 1) ORDER BY created_at ASC", [$userId, $userId]);
    }
    echo json_encode(['success' => true, 'messages' => $messages]);
    exit;
}

echo json_encode(['success' => false]);
?>