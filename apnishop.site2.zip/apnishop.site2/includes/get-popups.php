<?php
require_once 'config.php';
require_once 'db.php';
require_once 'functions.php';

header('Content-Type: application/json');

$subdomain = $_GET['subdomain'] ?? null;
if(!$subdomain) {
    echo json_encode([]);
    exit;
}

$user = db_get_row("SELECT id FROM users WHERE subdomain = ? AND is_active = 1", [$subdomain]);
if(!$user) {
    echo json_encode([]);
    exit;
}

$popups = db_get_all("SELECT id, title, message, image, show_on_load, show_on_exit, delay_seconds FROM popups WHERE user_id = ? AND is_active = 1", [$user['id']]);

foreach($popups as &$p) {
    if($p['image']) {
        $p['image'] = $p['image'];
    }
}
echo json_encode($popups);
?>