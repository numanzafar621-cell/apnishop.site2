<?php
require_once __DIR__ . '/db.php';

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function getUserById($id) {
    return db_get_row("SELECT * FROM users WHERE id = ?", [$id]);
}

function getUserBySubdomain($subdomain) {
    return db_get_row("SELECT * FROM users WHERE subdomain = ?", [$subdomain]);
}

function isUserActive($user_id) {
    $user = getUserById($user_id);
    if(!$user || $user['is_active'] != 1) return false;
    if($user['plan_expiry'] && strtotime($user['plan_expiry']) < time()) return false;
    return true;
}

function createSlug($string) {
    $string = strtolower($string);
    $string = preg_replace('/[^a-z0-9-]/', '-', $string);
    $string = preg_replace('/-+/', '-', $string);
    return trim($string, '-');
}

function formatPrice($price) {
    return 'Rs. ' . number_format($price, 2);
}

function excerpt($text, $length = 100) {
    if(strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}

function getThemeSettings($user_id) {
    $settings = db_get_row("SELECT * FROM theme_settings WHERE user_id = ?", [$user_id]);
    if(!$settings) {
        $id = db_insert('theme_settings', [
            'user_id' => $user_id,
            'primary_color' => '#4F46E5',
            'secondary_color' => '#F59E0B',
            'footer_text' => '© 2025 - All rights reserved'
        ]);
        $settings = db_get_row("SELECT * FROM theme_settings WHERE id = ?", [$id]);
    }
    return $settings;
}

function getSmallBanners($user_id) {
    return db_get_all("SELECT * FROM small_banners WHERE user_id = ? AND is_active = 1 ORDER BY order_position ASC", [$user_id]);
}

function getActivePopups($user_id) {
    return db_get_all("SELECT * FROM popups WHERE user_id = ? AND is_active = 1", [$user_id]);
}

function getSliders($user_id) {
    return db_get_all("SELECT * FROM sliders WHERE user_id = ? AND is_active = 1 ORDER BY order_position ASC", [$user_id]);
}

function getActiveProducts($user_id, $limit = null) {
    $sql = "SELECT * FROM products WHERE user_id = ? AND is_active = 1 ORDER BY id DESC";
    if($limit) $sql .= " LIMIT $limit";
    return db_get_all($sql, [$user_id]);
}

function getAverageRating($product_id) {
    $avg = db_get_value("SELECT AVG(rating) FROM reviews WHERE product_id = ? AND is_approved = 1", [$product_id]);
    return round($avg ?: 0, 1);
}

function isCnicVerified($user_id) {
    $user = getUserById($user_id);
    return ($user['cnic_front'] && $user['cnic_back'] && $user['is_active'] == 1);
}

function generateOrderNumber() {
    return 'ORD-' . strtoupper(uniqid());
}

function ensureDirectory($path) {
    if(!file_exists($path)) {
        mkdir($path, 0777, true);
    }
}
?>