<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();

// Send message
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $to_user_id = intval($_POST['to_user_id']);
    $message = trim($_POST['message']);
    if($message && $to_user_id) {
        db_insert('live_chat', [
            'from_user_id' => $to_user_id,
            'to_user_id' => $to_user_id,
            'from_admin' => 1,
            'message' => $message,
            'is_read' => 0
        ]);
        header("Location: live-chat.php?user=$to_user_id");
        exit;
    }
}

$selected_user = isset($_GET['user']) ? intval($_GET['user']) : 0;
$users = db_get_all("SELECT id, business_name, first_name, last_name, email FROM users ORDER BY id DESC");
$messages = [];
if($selected_user) {
    $messages = db_get_all("SELECT * FROM live_chat WHERE (to_user_id = ? AND from_admin = 1) OR (from_user_id = ? AND from_admin = 0) ORDER BY created_at ASC", [$selected_user, $selected_user]);
    db_update("live_chat", ['is_read' => 1], "to_user_id = ? AND from_admin = 0", [$selected_user]);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Live Chat - Super Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <meta http-equiv="refresh" content="5">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold">Super Admin</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700">📊 Dashboard</a></li>
                <li><a href="users.php" class="block py-2 px-4 hover:bg-indigo-700">👥 Users</a></li>
                <li><a href="verify-cnic.php" class="block py-2 px-4 hover:bg-indigo-700">✅ CNIC Verification</a></li>
                <li><a href="approve-product.php" class="block py-2 px-4 hover:bg-indigo-700">🛍️ Approve Products</a></li>
                <li><a href="plans.php" class="block py-2 px-4 hover:bg-indigo-700">💰 Plans</a></li>
                <li><a href="payment-gateways.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateways</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 bg-indigo-900">💬 Live Chat</a></li>
                <li><a href="settings.php" class="block py-2 px-4 hover:bg-indigo-700">⚙️ Settings</a></li>
                <li><a href="logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        <div class="flex-1 flex">
            <div class="w-64 bg-white border-r overflow-y-auto">
                <div class="p-3 font-bold border-b">Users</div>
                <?php foreach($users as $u): ?>
                <a href="?user=<?= $u['id'] ?>" class="block p-3 border-b hover:bg-gray-50 <?= $selected_user==$u['id']?'bg-indigo-50':'' ?>">
                    <div class="font-bold"><?= htmlspecialchars($u['business_name']) ?></div>
                    <div class="text-sm text-gray-600"><?= $u['first_name'] ?> <?= $u['last_name'] ?></div>
                    <?php $unread = db_get_value("SELECT COUNT(*) FROM live_chat WHERE to_user_id = ? AND from_admin = 0 AND is_read = 0", [$u['id']]); ?>
                    <?php if($unread): ?><span class="bg-red-500 text-white text-xs px-1 rounded"><?= $unread ?></span><?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
            <div class="flex-1 flex flex-col">
                <?php if($selected_user): $user = db_get_row("SELECT * FROM users WHERE id = ?", [$selected_user]); ?>
                <div class="bg-white p-3 border-b font-bold">Chat with: <?= htmlspecialchars($user['business_name']) ?> (<?= $user['email'] ?>)</div>
                <div class="flex-1 overflow-y-auto p-4 space-y-2" id="chatMessages">
                    <?php foreach($messages as $msg): ?>
                    <div class="<?= $msg['from_admin'] ? 'text-right' : 'text-left' ?>">
                        <div class="inline-block p-2 rounded <?= $msg['from_admin'] ? 'bg-indigo-600 text-white' : 'bg-gray-200' ?>">
                            <?= nl2br(htmlspecialchars($msg['message'])) ?>
                        </div>
                        <div class="text-xs text-gray-400 mt-1"><?= date('h:i A', strtotime($msg['created_at'])) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <form method="POST" class="bg-white p-3 border-t flex gap-2">
                    <input type="hidden" name="to_user_id" value="<?= $selected_user ?>">
                    <input type="text" name="message" required class="flex-1 border rounded px-3 py-2" placeholder="Type your message...">
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Send</button>
                </form>
                <script>setInterval(()=>location.reload(),5000);</script>
                <?php else: ?>
                <div class="flex-1 flex items-center justify-center text-gray-500">Select a user from the left to start chatting.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>