<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
requireAdminLogin();

$userId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user = db_get_row("SELECT * FROM users WHERE id = ?", [$userId]);
if(!$user) die("User not found.");

$products = db_get_all("SELECT * FROM products WHERE user_id = ? ORDER BY id DESC", [$userId]);
$orders = db_get_all("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 10", [$userId]);
$plan = db_get_row("SELECT * FROM plans WHERE id = ?", [$user['plan_id']]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Details - <?= htmlspecialchars($user['business_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen"><div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
    <div class="flex-1 p-6">
        <h1 class="text-3xl font-bold mb-6"><?= htmlspecialchars($user['business_name']) ?></h1>
        <div class="grid md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white p-4 rounded shadow"><h2 class="text-xl font-bold mb-3">Personal Info</h2><p><strong>Business:</strong> <?= htmlspecialchars($user['business_name']) ?></p><p><strong>Owner:</strong> <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></p><p><strong>Email:</strong> <?= $user['email'] ?></p><p><strong>Phone:</strong> <?= $user['phone'] ?></p><p><strong>Subdomain:</strong> <?= $user['subdomain'] ?>.apnishop.site</p><p><strong>Registered:</strong> <?= date('d-m-Y', strtotime($user['created_at'])) ?></p></div>
            <div class="bg-white p-4 rounded shadow"><h2 class="text-xl font-bold mb-3">Account Status</h2><p><strong>Status:</strong> <?= $user['is_active'] ? '<span class="text-green-600">Active</span>' : '<span class="text-red-600">Inactive</span>' ?></p><p><strong>Plan:</strong> <?= $plan ? $plan['name'] : 'Free' ?></p><p><strong>Plan Expiry:</strong> <?= $user['plan_expiry'] ? date('d-m-Y', strtotime($user['plan_expiry'])) : 'Lifetime' ?></p><p><strong>CNIC:</strong> <?= $user['cnic_number'] ?? 'Not provided' ?></p></div>
        </div>
        <div class="bg-white p-4 rounded shadow mb-8"><h2 class="text-xl font-bold mb-3">Products (<?= count($products) ?>)</h2><div class="grid grid-cols-4 gap-3"><?php foreach(array_slice($products,0,8) as $p): ?><div class="border rounded p-2"><img src="/assets/uploads/products/<?= $p['image'] ?>" class="h-20 w-full object-cover"><p class="text-sm font-bold"><?= htmlspecialchars($p['name']) ?></p><p class="text-xs"><?= formatPrice($p['price']) ?></p><p class="text-xs">Status: <?= $p['is_active'] ? 'Active' : 'Pending' ?></p></div><?php endforeach; ?></div></div>
        <div class="bg-white p-4 rounded shadow"><h2 class="text-xl font-bold mb-3">Recent Orders</h2><table class="min-w-full"><thead><tr><th>Order #</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr></thead><tbody><?php foreach($orders as $o): ?><tr><td><?= $o['order_number'] ?></td><td><?= htmlspecialchars($o['customer_name']) ?></td><td><?= formatPrice($o['total_amount']) ?></td><td><?= $o['status'] ?></td><td><?= date('d-m-Y', strtotime($o['created_at'])) ?></td></tr><?php endforeach; ?></tbody></table></div>
    </div></div>
</body>
</html>