<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();
$admin = getCurrentAdmin();

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $updateData = [];
    if($username) $updateData['username'] = $username;
    if($email) $updateData['email'] = $email;
    
    if(isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','webp'])) {
            $uploadDir = '../assets/uploads/profiles/';
            ensureDirectory($uploadDir);
            $newName = time() . '_admin_' . $admin['id'] . '.' . $ext;
            move_uploaded_file($_FILES['profile_image']['tmp_name'], $uploadDir . $newName);
            if($admin['profile_image'] && file_exists($uploadDir . $admin['profile_image'])) {
                unlink($uploadDir . $admin['profile_image']);
            }
            $updateData['profile_image'] = $newName;
        }
    }
    
    if(!empty($new_password)) {
        if(!verifyPassword($current_password, $admin['password'])) {
            $error = 'Current password is incorrect.';
        } elseif(strlen($new_password) < 6) {
            $error = 'New password must be at least 6 characters.';
        } elseif($new_password !== $confirm_password) {
            $error = 'New passwords do not match.';
        } else {
            $updateData['password'] = hashPassword($new_password);
        }
    }
    
    if(!$error && !empty($updateData)) {
        db_update("main_admins", $updateData, "id = ?", [$admin['id']]);
        $success = 'Settings updated successfully.';
        $admin = getCurrentAdmin();
        $_SESSION['admin_name'] = $admin['username'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Settings - Super Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold">Super Admin</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700">📊 Dashboard</a></li>
                <li><a href="users.php" class="block py-2 px-4 hover:bg-indigo-700">👥 Users</a></li>
                <li><a href="verify-cnic.php" class="block py-2 px-4 hover:bg-indigo-700">✅ CNIC Verification</a></li>
                <li><a href="approve-product.php" class="block py-2 px-4 hover:bg-indigo-700">🛍️ Approve Products</a></li>
                <li><a href="plans.php" class="block py-2 px-4 hover:bg-indigo-700">💰 Plans</a></li>
                <li><a href="payment-gateways.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateways</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 hover:bg-indigo-700">💬 Live Chat</a></li>
                <li><a href="settings.php" class="block py-2 px-4 bg-indigo-900">⚙️ Settings</a></li>
                <li><a href="logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Admin Settings</h1>
            <?php if($error): ?><div class="bg-red-100 p-3 rounded mb-4"><?= $error ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
                <div class="grid grid-cols-2 gap-4">
                    <div><label>Username</label><input type="text" name="username" value="<?= htmlspecialchars($admin['username']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Email</label><input type="email" name="email" value="<?= htmlspecialchars($admin['email']) ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label>Profile Image</label><?php if($admin['profile_image']): ?><img src="/assets/uploads/profiles/<?= $admin['profile_image'] ?>" class="h-16 mb-2"><?php endif; ?><input type="file" name="profile_image" accept="image/*" class="w-full border rounded px-3 py-2"></div>
                </div>
                <div class="border-t mt-6 pt-6"><h3 class="text-xl font-bold mb-4">Change Password</h3>
                    <div class="grid grid-cols-3 gap-4">
                        <div><label>Current Password</label><input type="password" name="current_password" class="w-full border rounded px-3 py-2"></div>
                        <div><label>New Password</label><input type="password" name="new_password" class="w-full border rounded px-3 py-2"></div>
                        <div><label>Confirm New Password</label><input type="password" name="confirm_password" class="w-full border rounded px-3 py-2"></div>
                    </div>
                </div>
                <button type="submit" class="mt-6 bg-indigo-600 text-white px-4 py-2 rounded">Save Settings</button>
            </form>
        </div>
    </div>
</body>
</html>