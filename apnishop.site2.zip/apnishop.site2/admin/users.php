<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();

// Delete user
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $userId = $_GET['delete'];
    db_delete("users", "id = ?", [$userId]);
    header('Location: users.php?msg=deleted');
    exit;
}

// Toggle active status
if(isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $userId = $_GET['toggle'];
    $user = db_get_row("SELECT is_active FROM users WHERE id = ?", [$userId]);
    if($user) {
        $new = $user['is_active'] ? 0 : 1;
        db_update("users", ['is_active' => $new], "id = ?", [$userId]);
    }
    header('Location: users.php');
    exit;
}

$search = $_GET['search'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$where = "";
$params = [];
if($search) {
    $where = "WHERE business_name LIKE ? OR email LIKE ? OR subdomain LIKE ?";
    $params = ["%$search%", "%$search%", "%$search%"];
}

$totalUsers = db_get_value("SELECT COUNT(*) FROM users $where", $params);
$users = db_get_all("SELECT * FROM users $where ORDER BY id DESC LIMIT $limit OFFSET $offset", $params);
$totalPages = ceil($totalUsers / $limit);
$pendingCnic = db_get_value("SELECT COUNT(*) FROM users WHERE is_active = 0 AND (cnic_front IS NOT NULL OR cnic_back IS NOT NULL)");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Users Management - Super Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold border-b border-indigo-700">ApniShop Admin</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700">📊 Dashboard</a></li>
                <li><a href="users.php" class="block py-2 px-4 hover:bg-indigo-700 bg-indigo-900">👥 Users</a></li>
                <li><a href="verify-cnic.php" class="block py-2 px-4 hover:bg-indigo-700">✅ CNIC Verification <?php if($pendingCnic > 0): ?><span class="bg-red-500 text-white px-1 rounded-full ml-1"><?= $pendingCnic ?></span><?php endif; ?></a></li>
                <li><a href="approve-product.php" class="block py-2 px-4 hover:bg-indigo-700">🛍️ Approve Products</a></li>
                <li><a href="plans.php" class="block py-2 px-4 hover:bg-indigo-700">💰 Plans</a></li>
                <li><a href="payment-gateways.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateways</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 hover:bg-indigo-700">💬 Live Chat</a></li>
                <li><a href="settings.php" class="block py-2 px-4 hover:bg-indigo-700">⚙️ Settings</a></li>
                <li><a href="logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        <div class="flex-1 overflow-y-auto p-6">
            <h1 class="text-3xl font-bold mb-6">Users Management</h1>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?><div class="bg-green-100 p-3 rounded mb-4">User deleted successfully.</div><?php endif; ?>
            <form method="GET" class="mb-4 flex gap-2">
                <input type="text" name="search" placeholder="Search by business, email or subdomain..." value="<?= htmlspecialchars($search) ?>" class="flex-1 border rounded px-3 py-2">
                <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Search</button>
                <?php if($search): ?><a href="users.php" class="bg-gray-500 text-white px-4 py-2 rounded">Clear</a><?php endif; ?>
            </form>
            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full">
                    <thead class="bg-gray-800 text-white">
                        <tr><th class="px-4 py-3">ID</th><th>Business</th><th>Owner</th><th>Subdomain</th><th>Phone</th><th>CNIC</th><th>Status</th><th>Plan Expiry</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($users as $u): ?>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-4 py-3"><?= $u['id'] ?></td>
                            <td class="px-4 py-3"><?= htmlspecialchars($u['business_name']) ?></td>
                            <td class="px-4 py-3"><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?></td>
                            <td class="px-4 py-3"><a href="http://<?= $u['subdomain'] ?>.apnishop.site" target="_blank" class="text-blue-600"><?= $u['subdomain'] ?>.apnishop.site</a></td>
                            <td class="px-4 py-3"><?= $u['phone'] ?></td>
                            <td class="px-4 py-3"><?php if($u['cnic_front'] && $u['cnic_back']): ?><a href="javascript:void(0)" onclick="showCnic('<?= $u['cnic_front'] ?>','<?= $u['cnic_back'] ?>')" class="text-green-600">View</a><?php else: ?>❌<?php endif; ?></td>
                            <td class="px-4 py-3"><?= $u['is_active'] ? '<span class="bg-green-100 text-green-800 px-2 py-1 rounded">Active</span>' : '<span class="bg-red-100 text-red-800 px-2 py-1 rounded">Inactive</span>' ?></td>
                            <td class="px-4 py-3"><?= $u['plan_expiry'] ? date('d-m-Y', strtotime($u['plan_expiry'])) : 'Lifetime' ?></td>
                            <td class="px-4 py-3"><a href="user-details.php?id=<?= $u['id'] ?>" class="text-blue-600 mr-2">🔍</a><a href="?toggle=<?= $u['id'] ?>" class="text-green-600 mr-2" onclick="return confirm('Toggle user status?')">✔️</a><a href="?delete=<?= $u['id'] ?>" class="text-red-600" onclick="return confirm('Delete user? All data will be lost!')">🗑️</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if($totalPages > 1): ?>
            <div class="flex justify-center mt-4 gap-2"><?php for($i=1;$i<=$totalPages;$i++): ?><a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>" class="px-3 py-1 border rounded <?= $i==$page?'bg-indigo-600 text-white':'bg-white' ?>"><?= $i ?></a><?php endfor; ?></div>
            <?php endif; ?>
        </div>
    </div>
    <div id="cnicModal" class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50"><div class="bg-white p-6 rounded-lg max-w-2xl"><h3 class="text-xl font-bold mb-4">CNIC Images</h3><div class="flex gap-4"><div><p>Front</p><img id="cnicFront" src="" class="max-h-64"></div><div><p>Back</p><img id="cnicBack" src="" class="max-h-64"></div></div><button onclick="closeCnicModal()" class="mt-4 bg-gray-600 text-white px-4 py-2 rounded">Close</button></div></div>
    <script>function showCnic(f,b){document.getElementById('cnicFront').src='/assets/uploads/cnic/'+f;document.getElementById('cnicBack').src='/assets/uploads/cnic/'+b;document.getElementById('cnicModal').classList.remove('hidden');}function closeCnicModal(){document.getElementById('cnicModal').classList.add('hidden');}</script>
</body>
</html>