<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

if(isset($_SESSION['impersonating'])) {
    // Restore admin session
    $_SESSION['admin_id'] = $_SESSION['impersonating'];
    $_SESSION['admin_logged_in'] = true;
    unset($_SESSION['impersonating']);
    unset($_SESSION['user_logged_in']);
    unset($_SESSION['user_id']);
    unset($_SESSION['user_name']);
    unset($_SESSION['user_subdomain']);
    header('Location: /admin/index.php');
} else {
    header('Location: /admin/index.php');
}
exit;
?>