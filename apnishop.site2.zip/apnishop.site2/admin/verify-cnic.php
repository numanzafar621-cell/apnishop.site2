<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();

if(isset($_GET['approve']) && is_numeric($_GET['approve'])) {
    $userId = $_GET['approve'];
    db_update("users", ['is_active' => 1], "id = ?", [$userId]);
    header('Location: verify-cnic.php?msg=approved');
    exit;
}
if(isset($_GET['reject']) && is_numeric($_GET['reject'])) {
    $userId = $_GET['reject'];
    db_update("users", ['cnic_front' => null, 'cnic_back' => null, 'is_active' => 0], "id = ?", [$userId]);
    header('Location: verify-cnic.php?msg=rejected');
    exit;
}
$pendingUsers = db_get_all("SELECT * FROM users WHERE is_active = 0 AND (cnic_front IS NOT NULL OR cnic_back IS NOT NULL) ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CNIC Verification - Super Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0"><div class="p-4 text-xl font-bold">ApniShop Admin</div><ul><?php /* sidebar same as users */ ?></ul></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">CNIC Verification Requests</h1>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'approved'): ?><div class="bg-green-100 p-3 rounded mb-4">User activated successfully.</div><?php endif; ?>
            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'rejected'): ?><div class="bg-red-100 p-3 rounded mb-4">Request rejected.</div><?php endif; ?>
            <?php if(empty($pendingUsers)): ?><div class="bg-white p-6 rounded shadow text-center">No pending verification requests.</div><?php else: ?>
                <div class="grid gap-6"><?php foreach($pendingUsers as $u): ?>
                    <div class="bg-white rounded shadow p-6"><div class="flex justify-between"><div><h2 class="text-xl font-bold"><?= htmlspecialchars($u['business_name']) ?></h2><p><strong>Owner:</strong> <?= htmlspecialchars($u['first_name'].' '.$u['last_name']) ?></p><p><strong>Email:</strong> <?= $u['email'] ?></p><p><strong>Phone:</strong> <?= $u['phone'] ?></p><p><strong>CNIC:</strong> <?= $u['cnic_number'] ?></p><p><strong>Subdomain:</strong> <?= $u['subdomain'] ?>.apnishop.site</p></div><div><a href="?approve=<?= $u['id'] ?>" class="bg-green-600 text-white px-4 py-2 rounded inline-block mr-2">✅ Approve</a><a href="?reject=<?= $u['id'] ?>" class="bg-red-600 text-white px-4 py-2 rounded inline-block">❌ Reject</a></div></div><div class="mt-4 grid grid-cols-2 gap-4"><div><p class="font-bold">CNIC Front</p><img src="/assets/uploads/cnic/<?= $u['cnic_front'] ?>" class="max-h-64 border rounded"></div><div><p class="font-bold">CNIC Back</p><img src="/assets/uploads/cnic/<?= $u['cnic_back'] ?>" class="max-h-64 border rounded"></div></div></div>
                <?php endforeach; ?></div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>