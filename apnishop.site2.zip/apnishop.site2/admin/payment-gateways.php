<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireAdminLogin();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach(['stripe','easypaisa','jazzcash'] as $gw) {
        $api_key = trim($_POST[$gw.'_api_key'] ?? '');
        $secret = trim($_POST[$gw.'_secret'] ?? '');
        $is_active = isset($_POST[$gw.'_active']) ? 1 : 0;
        $existing = db_get_row("SELECT id FROM payment_gateways WHERE user_id = 0 AND gateway_name = ?", [$gw]);
        if($existing) {
            db_update("payment_gateways", ['api_key'=>$api_key, 'secret_key'=>$secret, 'is_active'=>$is_active], "id = ?", [$existing['id']]);
        } else {
            db_insert("payment_gateways", ['user_id'=>0, 'gateway_name'=>$gw, 'api_key'=>$api_key, 'secret_key'=>$secret, 'is_active'=>$is_active]);
        }
    }
    $success = "Global payment gateway settings saved.";
}
$stripe = db_get_row("SELECT * FROM payment_gateways WHERE user_id = 0 AND gateway_name = 'stripe'");
$easypaisa = db_get_row("SELECT * FROM payment_gateways WHERE user_id = 0 AND gateway_name = 'easypaisa'");
$jazzcash = db_get_row("SELECT * FROM payment_gateways WHERE user_id = 0 AND gateway_name = 'jazzcash'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Global Payment Gateways</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
        <div class="flex-1 p-6">
            <h1 class="text-3xl font-bold mb-6">Global Payment Gateways</h1>
            <?php if(isset($success)): ?><div class="bg-green-100 p-3 rounded mb-4"><?= $success ?></div><?php endif; ?>
            <form method="POST" class="bg-white p-6 rounded shadow">
                <div class="border-b pb-4 mb-4"><h2 class="text-xl font-bold">Stripe</h2><div class="grid grid-cols-2 gap-4"><div><label>Publishable Key</label><input type="text" name="stripe_api_key" value="<?= htmlspecialchars($stripe['api_key']??'') ?>" class="w-full border rounded px-3 py-2"></div><div><label>Secret Key</label><input type="text" name="stripe_secret" value="<?= htmlspecialchars($stripe['secret_key']??'') ?>" class="w-full border rounded px-3 py-2"></div></div><label><input type="checkbox" name="stripe_active" value="1" <?= ($stripe['is_active']??0)?'checked':'' ?>> Enable</label></div>
                <div class="border-b pb-4 mb-4"><h2 class="text-xl font-bold">Easypaisa</h2><div class="grid grid-cols-2 gap-4"><div><label>Store ID</label><input type="text" name="easypaisa_api_key" value="<?= htmlspecialchars($easypaisa['api_key']??'') ?>" class="w-full border rounded px-3 py-2"></div><div><label>Hash Key</label><input type="text" name="easypaisa_secret" value="<?= htmlspecialchars($easypaisa['secret_key']??'') ?>" class="w-full border rounded px-3 py-2"></div></div><label><input type="checkbox" name="easypaisa_active" value="1" <?= ($easypaisa['is_active']??0)?'checked':'' ?>> Enable</label></div>
                <div class="border-b pb-4 mb-4"><h2 class="text-xl font-bold">JazzCash</h2><div class="grid grid-cols-2 gap-4"><div><label>Merchant ID</label><input type="text" name="jazzcash_api_key" value="<?= htmlspecialchars($jazzcash['api_key']??'') ?>" class="w-full border rounded px-3 py-2"></div><div><label>Password</label><input type="text" name="jazzcash_secret" value="<?= htmlspecialchars($jazzcash['secret_key']??'') ?>" class="w-full border rounded px-3 py-2"></div></div><label><input type="checkbox" name="jazzcash_active" value="1" <?= ($jazzcash['is_active']??0)?'checked':'' ?>> Enable</label></div>
                <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded">Save Settings</button>
            </form>
        </div>
    </div>
</body>
</html>