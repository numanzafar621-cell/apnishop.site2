<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();

$userId = isset($_GET['user']) ? intval($_GET['user']) : 0;
if(!$userId) die("Invalid request.");

$user = db_get_row("SELECT * FROM users WHERE id = ?", [$userId]);
if(!$user) die("User not found.");

// Store original admin id in session to return later
$_SESSION['impersonating'] = $_SESSION['admin_id'];
$_SESSION['admin_logged_in'] = false;
$_SESSION['user_logged_in'] = true;
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
$_SESSION['user_subdomain'] = $user['subdomain'];

// Redirect to user's dashboard
header("Location: /tenant/dashboard/index.php");
exit;
?>