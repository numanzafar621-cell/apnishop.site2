<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

$error = '';

if(isAdminLoggedIn()) {
    header('Location: index.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if(empty($email) || empty($password)) {
        $error = 'Please enter email and password.';
    } else {
        if(adminLogin($email, $password)) {
            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - ApniShop</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-900">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-2">Super Admin Panel</h2>
            <p class="text-center text-gray-600 mb-6">Please login to continue</p>
            <?php if($error): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4"><?= $error ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-4"><label>Email</label><input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
                <div class="mb-6"><label>Password</label><input type="password" name="password" required class="w-full border rounded px-3 py-2"></div>
                <button type="submit" class="w-full bg-indigo-800 text-white py-2 rounded hover:bg-indigo-900">Login</button>
            </form>
            <p class="text-center text-gray-500 mt-4"><a href="/login.php" class="text-indigo-600">Seller Login</a></p>
        </div>
    </div>
</body>
</html>