<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();

// Statistics
$totalUsers = db_get_value("SELECT COUNT(*) FROM users");
$activeUsers = db_get_value("SELECT COUNT(*) FROM users WHERE is_active = 1");
$pendingVerification = db_get_value("SELECT COUNT(*) FROM users WHERE is_active = 0 AND (cnic_front IS NOT NULL OR cnic_back IS NOT NULL)");
$totalProducts = db_get_value("SELECT COUNT(*) FROM products");
$totalOrders = db_get_value("SELECT COUNT(*) FROM orders");

$recentUsers = db_get_all("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/admin.css">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="w-64 bg-indigo-800 text-white flex-shrink-0">
            <div class="p-4 text-xl font-bold border-b border-indigo-700">ApniShop Admin</div>
            <ul class="mt-4">
                <li><a href="index.php" class="block py-2 px-4 hover:bg-indigo-700 bg-indigo-900">📊 Dashboard</a></li>
                <li><a href="users.php" class="block py-2 px-4 hover:bg-indigo-700">👥 Users</a></li>
                <li><a href="verify-cnic.php" class="block py-2 px-4 hover:bg-indigo-700">✅ CNIC Verification</a></li>
                <li><a href="approve-product.php" class="block py-2 px-4 hover:bg-indigo-700">🛍️ Approve Products</a></li>
                <li><a href="plans.php" class="block py-2 px-4 hover:bg-indigo-700">💰 Plans</a></li>
                <li><a href="payment-gateways.php" class="block py-2 px-4 hover:bg-indigo-700">💳 Payment Gateways</a></li>
                <li><a href="live-chat.php" class="block py-2 px-4 hover:bg-indigo-700">💬 Live Chat</a></li>
                <li><a href="settings.php" class="block py-2 px-4 hover:bg-indigo-700">⚙️ Settings</a></li>
                <li><a href="logout.php" class="block py-2 px-4 hover:bg-red-700 mt-8">🚪 Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 overflow-y-auto p-6">
            <h1 class="text-3xl font-bold mb-2">Welcome, <?= htmlspecialchars($_SESSION['admin_name']) ?></h1>
            <p class="text-gray-600 mb-6">Manage all users, products, and orders from here.</p>
            
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white p-4 rounded-lg shadow"><div class="text-gray-500">Total Users</div><div class="text-3xl font-bold"><?= $totalUsers ?></div></div>
                <div class="bg-white p-4 rounded-lg shadow"><div class="text-gray-500">Active Users</div><div class="text-3xl font-bold text-green-600"><?= $activeUsers ?></div></div>
                <div class="bg-white p-4 rounded-lg shadow"><div class="text-gray-500">Pending CNIC</div><div class="text-3xl font-bold text-yellow-600"><?= $pendingVerification ?></div></div>
                <div class="bg-white p-4 rounded-lg shadow"><div class="text-gray-500">Total Products</div><div class="text-3xl font-bold"><?= $totalProducts ?></div></div>
            </div>
            
            <!-- Recent Users Table -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="px-6 py-4 border-b font-bold text-lg">Recent Signups</div>
                <table class="min-w-full">
                    <thead class="bg-gray-50"><?php echo "<tr><th class='px-6 py-3 text-left'>Business</th><th>Subdomain</th><th>Date</th><th>Status</th><th>Action</th></tr>"; ?></thead>
                    <tbody>
                        <?php foreach($recentUsers as $user): ?>
                        <tr class="border-t"><td class="px-6 py-3"><?= htmlspecialchars($user['business_name']) ?></td>
                        <td class="px-6 py-3"><?= $user['subdomain'] ?>.apnishop.site</td>
                        <td class="px-6 py-3"><?= date('d-m-Y', strtotime($user['created_at'])) ?></td>
                        <td class="px-6 py-3"><?= $user['is_active'] ? '<span class="bg-green-100 text-green-800 px-2 py-1 rounded">Active</span>' : '<span class="bg-red-100 text-red-800 px-2 py-1 rounded">Inactive</span>' ?></td>
                        <td class="px-6 py-3"><a href="user-details.php?id=<?= $user['id'] ?>" class="text-blue-600">View</a></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>