<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();

if(isset($_GET['approve']) && is_numeric($_GET['approve'])) {
    $productId = $_GET['approve'];
    db_update("products", ['is_active' => 1], "id = ?", [$productId]);
    header('Location: approve-product.php?msg=approved');
    exit;
}
if(isset($_GET['disapprove']) && is_numeric($_GET['disapprove'])) {
    $productId = $_GET['disapprove'];
    db_update("products", ['is_active' => 0], "id = ?", [$productId]);
    header('Location: approve-product.php?msg=disapproved');
    exit;
}
$pendingProducts = db_get_all("SELECT p.*, u.business_name, u.subdomain FROM products p JOIN users u ON p.user_id = u.id WHERE p.is_active = 0 ORDER BY p.id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Approve Products - Super Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen"><div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
    <div class="flex-1 p-6">
        <h1 class="text-3xl font-bold mb-6">Pending Product Approvals</h1>
        <?php if(isset($_GET['msg']) && $_GET['msg'] == 'approved'): ?><div class="bg-green-100 p-3 rounded mb-4">Product approved.</div><?php endif; ?>
        <?php if(empty($pendingProducts)): ?><div class="bg-white p-6 rounded shadow text-center">No pending products.</div><?php else: ?>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach($pendingProducts as $p): ?>
            <div class="bg-white rounded shadow overflow-hidden"><img src="/assets/uploads/products/<?= $p['image'] ?>" class="h-48 w-full object-cover"><div class="p-4"><h2 class="text-xl font-bold"><?= htmlspecialchars($p['name']) ?></h2><p><?= formatPrice($p['price']) ?></p><p class="text-sm text-gray-500">Store: <?= htmlspecialchars($p['business_name']) ?> (<?= $p['subdomain'] ?>.apnishop.site)</p><div class="flex gap-2 mt-4"><a href="?approve=<?= $p['id'] ?>" class="bg-green-600 text-white px-3 py-1 rounded">✅ Approve</a><a href="?disapprove=<?= $p['id'] ?>" class="bg-red-600 text-white px-3 py-1 rounded">❌ Disapprove</a><a href="../tenant/product.php?id=<?= $p['id'] ?>&preview=1" target="_blank" class="bg-blue-600 text-white px-3 py-1 rounded">🔍 View</a></div></div></div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div></div>
</body>
</html>