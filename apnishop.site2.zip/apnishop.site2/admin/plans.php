<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireAdminLogin();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $duration_days = intval($_POST['duration_days']);
    $features = trim($_POST['features']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    if($id) {
        db_update("plans", ['name'=>$name,'price'=>$price,'duration_days'=>$duration_days,'features'=>$features,'is_active'=>$is_active], "id = ?", [$id]);
        header('Location: plans.php?msg=updated');
    } else {
        db_insert("plans", ['name'=>$name,'price'=>$price,'duration_days'=>$duration_days,'features'=>$features,'is_active'=>$is_active]);
        header('Location: plans.php?msg=added');
    }
    exit;
}
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    db_delete("plans", "id = ?", [$_GET['delete']]);
    header('Location: plans.php?msg=deleted');
    exit;
}
$plans = db_get_all("SELECT * FROM plans ORDER BY price ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Plans Management - Super Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen"><div class="w-64 bg-indigo-800 text-white"><?php /* sidebar */ ?></div>
    <div class="flex-1 p-6">
        <h1 class="text-3xl font-bold mb-6">Plans Management</h1>
        <?php if(isset($_GET['msg'])) echo '<div class="bg-green-100 p-3 rounded mb-4">Plan '.$_GET['msg'].'.</div>'; ?>
        <div class="bg-white p-6 rounded shadow mb-8"><h2 class="text-xl font-bold mb-4">Add New Plan</h2>
            <form method="POST"><input type="hidden" name="id" value="0"><div class="grid grid-cols-2 gap-4"><div><label>Plan Name</label><input type="text" name="name" required class="w-full border rounded px-3 py-2"></div><div><label>Price (Rs.)</label><input type="number" step="0.01" name="price" required class="w-full border rounded px-3 py-2"></div><div><label>Duration (days)</label><input type="number" name="duration_days" required class="w-full border rounded px-3 py-2"></div><div><label><input type="checkbox" name="is_active" value="1"> Active</label></div><div class="col-span-2"><label>Features</label><textarea name="features" rows="3" class="w-full border rounded px-3 py-2"></textarea></div></div><button type="submit" class="mt-4 bg-indigo-600 text-white px-4 py-2 rounded">Add Plan</button></form>
        </div>
        <div class="grid md:grid-cols-3 gap-6"><?php foreach($plans as $p): ?><div class="bg-white rounded shadow p-4"><h3 class="text-xl font-bold"><?= htmlspecialchars($p['name']) ?></h3><p class="text-2xl text-indigo-600"><?= formatPrice($p['price']) ?></p><p>Duration: <?= $p['duration_days'] ?> days</p><p class="text-sm"><?= nl2br(htmlspecialchars($p['features'])) ?></p><div class="flex gap-2 mt-4"><button onclick="editPlan(<?= htmlspecialchars(json_encode($p)) ?>)" class="bg-blue-600 text-white px-3 py-1 rounded">Edit</button><a href="?delete=<?= $p['id'] ?>" class="bg-red-600 text-white px-3 py-1 rounded" onclick="return confirm('Delete plan?')">Delete</a></div></div><?php endforeach; ?></div>
    </div></div>
    <div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center"><div class="bg-white p-6 rounded max-w-md"><h3 class="text-xl font-bold mb-4">Edit Plan</h3><form method="POST" id="editForm"><input type="hidden" name="id" id="edit_id"><div class="mb-2"><label>Name</label><input type="text" name="name" id="edit_name" class="w-full border rounded px-2 py-1"></div><div class="mb-2"><label>Price</label><input type="number" step="0.01" name="price" id="edit_price" class="w-full border rounded px-2 py-1"></div><div class="mb-2"><label>Duration (days)</label><input type="number" name="duration_days" id="edit_duration" class="w-full border rounded px-2 py-1"></div><div class="mb-2"><label>Features</label><textarea name="features" id="edit_features" rows="3" class="w-full border rounded px-2 py-1"></textarea></div><div class="mb-2"><label><input type="checkbox" name="is_active" value="1" id="edit_active"> Active</label></div><div class="flex gap-2"><button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">Update</button><button type="button" onclick="closeModal()" class="bg-gray-600 text-white px-4 py-2 rounded">Cancel</button></div></form></div></div>
    <script>function editPlan(p){document.getElementById('edit_id').value=p.id;document.getElementById('edit_name').value=p.name;document.getElementById('edit_price').value=p.price;document.getElementById('edit_duration').value=p.duration_days;document.getElementById('edit_features').value=p.features;document.getElementById('edit_active').checked=p.is_active==1;document.getElementById('editModal').classList.remove('hidden');}function closeModal(){document.getElementById('editModal').classList.add('hidden');}</script>
</body>
</html>