<?php
$email = isset($_GET['email']) ? htmlspecialchars($_GET['email']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setting Up Your Store - ApniShop</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .loader {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4F46E5;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .progress-bar {
            width: 0%;
            height: 4px;
            background: linear-gradient(90deg, #4F46E5, #F59E0B);
            transition: width 0.3s ease;
        }
    </style>
    <meta http-equiv="refresh" content="3;url=login.php?msg=verify">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-md text-center max-w-md w-full fade-in">
        <div class="loader"></div>
        <div class="progress-bar w-0 h-1 bg-indigo-600 rounded-full mb-4" id="progressBar"></div>
        <h2 class="text-2xl font-bold text-indigo-600 mb-2">Almost There!</h2>
        <p class="text-gray-600 mb-4">We are setting up your store...</p>
        <div class="bg-blue-50 p-4 rounded-lg text-left mt-4">
            <p class="text-sm text-blue-800 font-semibold">Next Steps:</p>
            <ul class="text-sm text-blue-700 list-disc list-inside mt-2 space-y-1">
                <li>You will be redirected to login page in a moment.</li>
                <li>After login, you must complete CNIC verification.</li>
                <li>Admin will review and activate your account.</li>
            </ul>
        </div>
        <p class="text-gray-500 text-xs mt-6">Redirecting to login...</p>
    </div>
    <script>
        let width = 0;
        const interval = setInterval(() => {
            if (width >= 100) clearInterval(interval);
            else {
                width += 2;
                document.getElementById('progressBar').style.width = width + '%';
            }
        }, 60);
    </script>
</body>
</html>